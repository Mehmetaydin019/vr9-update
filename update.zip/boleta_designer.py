from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import qrcode
import barcode
from barcode.writer import ImageWriter

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QComboBox, QSpinBox, QLineEdit,
    QFrame, QPushButton, QFileDialog, QCheckBox, QMessageBox, QScrollArea,
    QFormLayout, QGroupBox, QGridLayout
)

CONFIG_FILE = Path(__file__).resolve().parent / "boleta_designer_config.json"


class BoletaDesigner(QWidget):
    def __init__(self):
        super().__init__()

        self._building = False

        root = QHBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        # -----------------------------
        # SOL PANEL (SETTINGS)
        # -----------------------------
        left_wrap = QWidget()
        self.left_layout = QVBoxLayout(left_wrap)
        self.left_layout.setContentsMargins(0, 0, 0, 0)
        self.left_layout.setSpacing(10)

        title = QLabel("Ajustes · Diseño de Boleta")
        title.setStyleSheet("font-size:24px;font-weight:900;")
        self.left_layout.addWidget(title)

        desc = QLabel("Configura la boleta en vivo. Cambia valores y verás la vista previa a la derecha.")
        desc.setWordWrap(True)
        desc.setStyleSheet("color:#64748b;")
        self.left_layout.addWidget(desc)

        self.left_layout.addWidget(self._paper_group())
        self.left_layout.addWidget(self._logo_group())
        self.left_layout.addWidget(self._empresa_group())
        self.left_layout.addWidget(self._documento_group())
        self.left_layout.addWidget(self._local_group())
        self.left_layout.addWidget(self._cliente_group())
        self.left_layout.addWidget(self._operacion_group())
        self.left_layout.addWidget(self._detalle_group())
        self.left_layout.addWidget(self._totales_group())
        self.left_layout.addWidget(self._footer_group())
        self.left_layout.addWidget(self._codes_group())

        btn_row = QHBoxLayout()
        self.btn_guardar = QPushButton("💾 Guardar")
        self.btn_guardar.clicked.connect(self.save_config)

        self.btn_cargar = QPushButton("🔄 Cargar")
        self.btn_cargar.clicked.connect(self.load_config)

        self.btn_prueba = QPushButton("🖨 Imprimir prueba")
        self.btn_prueba.clicked.connect(self.test_print)

        btn_row.addWidget(self.btn_guardar)
        btn_row.addWidget(self.btn_cargar)
        btn_row.addWidget(self.btn_prueba)
        self.left_layout.addLayout(btn_row)
        self.left_layout.addStretch(1)

        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setWidget(left_wrap)

        # -----------------------------
        # SAĞ PANEL (PREVIEW)
        # -----------------------------
        right_wrap = QWidget()
        right_layout = QVBoxLayout(right_wrap)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)

        preview_title = QLabel("Vista previa")
        preview_title.setStyleSheet("font-size:20px;font-weight:900;")
        right_layout.addWidget(preview_title)

        self.preview_scroll = QScrollArea()
        self.preview_scroll.setWidgetResizable(True)

        self.preview = QFrame()
        self.preview.setObjectName("PreviewPaper")
        self.preview_layout = QVBoxLayout(self.preview)
        self.preview_layout.setContentsMargins(16, 16, 16, 16)
        self.preview_layout.setSpacing(6)

        # logo
        self.logo_label = QLabel()
        self.logo_label.setAlignment(Qt.AlignCenter)
        self.preview_layout.addWidget(self.logo_label)

        # empresa
        self.lbl_header = QLabel()
        self.preview_layout.addWidget(self.lbl_header)

        self._add_sep()

        self.lbl_razon = QLabel()
        self.preview_layout.addWidget(self.lbl_razon)

        self.lbl_rut = QLabel()
        self.preview_layout.addWidget(self.lbl_rut)

        self.lbl_giro = QLabel()
        self.lbl_giro.setWordWrap(True)
        self.preview_layout.addWidget(self.lbl_giro)

        self._add_sep()

        # documento
        self.lbl_doc = QLabel()
        self.preview_layout.addWidget(self.lbl_doc)

        self.lbl_fecha = QLabel()
        self.preview_layout.addWidget(self.lbl_fecha)

        self._add_sep()

        # local
        self.lbl_casa_title = QLabel()
        self.preview_layout.addWidget(self.lbl_casa_title)

        self.lbl_casa = QLabel()
        self.lbl_casa.setWordWrap(True)
        self.preview_layout.addWidget(self.lbl_casa)

        self.lbl_sucursal_title = QLabel()
        self.preview_layout.addWidget(self.lbl_sucursal_title)

        self.lbl_sucursal = QLabel()
        self.lbl_sucursal.setWordWrap(True)
        self.preview_layout.addWidget(self.lbl_sucursal)

        self.lbl_contacto = QLabel()
        self.lbl_contacto.setWordWrap(True)
        self.preview_layout.addWidget(self.lbl_contacto)

        self._add_sep()

        # cliente
        self.lbl_cliente_title = QLabel()
        self.preview_layout.addWidget(self.lbl_cliente_title)

        self.lbl_cliente_razon = QLabel()
        self.preview_layout.addWidget(self.lbl_cliente_razon)

        self.lbl_cliente_rut = QLabel()
        self.preview_layout.addWidget(self.lbl_cliente_rut)

        self.lbl_cliente_dir = QLabel()
        self.preview_layout.addWidget(self.lbl_cliente_dir)

        self.lbl_cliente_comuna = QLabel()
        self.preview_layout.addWidget(self.lbl_cliente_comuna)

        self._add_sep()

        # operacion
        self.lbl_oper = QLabel()
        self.lbl_oper.setWordWrap(True)
        self.preview_layout.addWidget(self.lbl_oper)

        self._add_sep()

        # detalle table
        self.detalle_title = QLabel()
        self.preview_layout.addWidget(self.detalle_title)

        self.detalle_line = QFrame()
        self.detalle_line.setFrameShape(QFrame.HLine)
        self.preview_layout.addWidget(self.detalle_line)

        self.total_line = QFrame()
        self.total_line.setFrameShape(QFrame.HLine)
        self.preview_layout.addWidget(self.total_line)

        self.tbl = QGridLayout()
        self.tbl.setHorizontalSpacing(10)
        self.tbl.setVerticalSpacing(6)

        self.tbl_h_desc = QLabel("Descripción")
        self.tbl_h_cant = QLabel("Cant.")
        self.tbl_h_total = QLabel("Total")

        self.tbl.addWidget(self.tbl_h_desc, 0, 0)
        self.tbl.addWidget(self.tbl_h_cant, 0, 1, alignment=Qt.AlignRight)
        self.tbl.addWidget(self.tbl_h_total, 0, 2, alignment=Qt.AlignRight)

        self.row1_desc = QLabel("Bolsa Chica-14")
        self.row1_cant = QLabel("10")
        self.row1_total = QLabel("1.000")
        self.row1_barcode = QLabel("COD: 7800000000014")

        self.row2_desc = QLabel("Jeans Azul")
        self.row2_cant = QLabel("1")
        self.row2_total = QLabel("19.990")
        self.row2_barcode = QLabel("COD: 7800000000015")

        self.tbl.addWidget(self.row1_desc, 1, 0)
        self.tbl.addWidget(self.row1_cant, 1, 1, alignment=Qt.AlignRight)
        self.tbl.addWidget(self.row1_total, 1, 2, alignment=Qt.AlignRight)

        self.tbl.addWidget(self.row1_barcode, 2, 0, 1, 3)

        self.tbl.addWidget(self.row2_desc, 3, 0)
        self.tbl.addWidget(self.row2_cant, 3, 1, alignment=Qt.AlignRight)
        self.tbl.addWidget(self.row2_total, 3, 2, alignment=Qt.AlignRight)

        self.tbl.addWidget(self.row2_barcode, 4, 0, 1, 3)

        tbl_wrap = QWidget()
        tbl_wrap.setLayout(self.tbl)
        self.preview_layout.addWidget(tbl_wrap)

        self._add_sep()

        # totales
        self.lbl_subtotal = QLabel()
        self.preview_layout.addWidget(self.lbl_subtotal)

        self.lbl_descuento = QLabel()
        self.preview_layout.addWidget(self.lbl_descuento)

        self.lbl_iva = QLabel()
        self.preview_layout.addWidget(self.lbl_iva)

        self.lbl_total = QLabel()
        self.preview_layout.addWidget(self.lbl_total)

        self._add_sep()

        # footer legal
        self.lbl_footer1 = QLabel()
        self.lbl_footer2 = QLabel()
        self.lbl_footer3 = QLabel()

        self.preview_layout.addWidget(self.lbl_footer1)
        self.preview_layout.addWidget(self.lbl_footer2)
        self.preview_layout.addWidget(self.lbl_footer3)

        self._add_sep()

        # barcode
        self.barcode_label = QLabel()
        self.barcode_label.setAlignment(Qt.AlignCenter)
        self.preview_layout.addWidget(self.barcode_label)

        # qr
        self.qr_label = QLabel()
        self.qr_label.setAlignment(Qt.AlignCenter)
        self.preview_layout.addWidget(self.qr_label)

        self.lbl_codes_note = QLabel()
        self.lbl_codes_note.setWordWrap(True)
        self.lbl_codes_note.setAlignment(Qt.AlignCenter)
        self.preview_layout.addWidget(self.lbl_codes_note)

        self.preview_scroll.setWidget(self.preview)
        right_layout.addWidget(self.preview_scroll)

        root.addWidget(left_scroll, 1)
        root.addWidget(right_wrap, 2)

        self.setStyleSheet("""
            QGroupBox {
                border:1px solid #e2e8f0;
                border-radius:12px;
                margin-top:8px;
                padding:10px;
                background:#ffffff;
                font-weight:900;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding:0 6px;
            }
            QLineEdit, QComboBox, QSpinBox {
                min-height:34px;
                border-radius:8px;
                border:1px solid #cbd5e1;
                padding:4px 8px;
                background:#ffffff;
            }
            QPushButton {
                min-height:36px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                padding:6px 12px;
                font-weight:800;
            }
            QFrame#PreviewPaper {
                background:#ffffff;
                border:1px solid #9ca3af;
                border-radius:8px;
            }
        """)

        self._connect_all()
        self.load_config()
        self.update_preview()

    # ------------------------------------------------------------------
    # GROUPS
    # ------------------------------------------------------------------
    def _paper_group(self):
        box = QGroupBox("Papel")
        f = QFormLayout(box)

        self.paper_width = QComboBox()
        self.paper_width.addItems(["58mm", "80mm"])

        self.margin_left = QSpinBox()
        self.margin_left.setRange(0, 40)
        self.margin_left.setValue(10)

        self.margin_right = QSpinBox()
        self.margin_right.setRange(0, 40)
        self.margin_right.setValue(10)

        self.line_spacing = QSpinBox()
        self.line_spacing.setRange(0, 20)
        self.line_spacing.setValue(4)

        self.show_lines = QCheckBox("Mostrar líneas separadoras")
        self.show_lines.setChecked(True)

        f.addRow("Ancho papel:", self.paper_width)
        f.addRow("Margen izquierdo:", self.margin_left)
        f.addRow("Margen derecho:", self.margin_right)
        f.addRow("Espaciado líneas:", self.line_spacing)
        f.addRow("", self.show_lines)
        return box

    def _logo_group(self):
        box = QGroupBox("Logo")
        f = QFormLayout(box)

        self.show_logo = QCheckBox("Mostrar logo")
        self.logo_path = QLineEdit()
        self.logo_width = QSpinBox()
        self.logo_width.setRange(40, 300)
        self.logo_width.setValue(140)

        self.btn_logo = QPushButton("Seleccionar logo")
        self.btn_logo.clicked.connect(self.pick_logo)

        f.addRow("", self.show_logo)
        f.addRow("Ruta logo:", self.logo_path)
        f.addRow("Ancho logo:", self.logo_width)
        f.addRow("", self.btn_logo)
        return box

    def _empresa_group(self):
        box = QGroupBox("Empresa")
        f = QFormLayout(box)

        self.header_text = QLineEdit("GALATA TREND")
        self.header_size = QSpinBox()
        self.header_size.setRange(8, 42)
        self.header_size.setValue(24)
        self.header_bold = QCheckBox("Bold")
        self.header_align = QComboBox()
        self.header_align.addItems(["left", "center", "right"])

        self.razon_text = QLineEdit("Importadora Galata SpA")
        self.razon_size = QSpinBox()
        self.razon_size.setRange(8, 28)
        self.razon_size.setValue(14)
        self.razon_bold = QCheckBox("Bold")

        self.rut_text = QLineEdit("RUT: 78.325.343-7")
        self.rut_size = QSpinBox()
        self.rut_size.setRange(8, 22)
        self.rut_size.setValue(10)
        self.rut_bold = QCheckBox("Bold")

        self.giro_text = QLineEdit("VENTA DE PRODUCTOS TEXTILES Y CALZADO AL POR MENOR Y MAYOR")
        self.giro_size = QSpinBox()
        self.giro_size.setRange(8, 18)
        self.giro_size.setValue(9)
        self.giro_bold = QCheckBox("Bold")

        f.addRow("Nombre fantasía:", self.header_text)
        f.addRow("Header size:", self.header_size)
        f.addRow("Header align:", self.header_align)
        f.addRow("", self.header_bold)

        f.addRow("Razón social:", self.razon_text)
        f.addRow("Razón size:", self.razon_size)
        f.addRow("", self.razon_bold)

        f.addRow("RUT:", self.rut_text)
        f.addRow("RUT size:", self.rut_size)
        f.addRow("", self.rut_bold)

        f.addRow("Giro:", self.giro_text)
        f.addRow("Giro size:", self.giro_size)
        f.addRow("", self.giro_bold)
        return box

    def _documento_group(self):
        box = QGroupBox("Documento")
        f = QFormLayout(box)

        self.doc_text = QLineEdit("BOLETA AFECTA ELECTRÓNICA : #3504270")
        self.doc_size = QSpinBox()
        self.doc_size.setRange(8, 22)
        self.doc_size.setValue(12)
        self.doc_bold = QCheckBox("Bold")
        self.doc_align = QComboBox()
        self.doc_align.addItems(["left", "center", "right"])

        self.fecha_text = QLineEdit("Fecha: 09/03/2026 12:12:01")
        self.fecha_size = QSpinBox()
        self.fecha_size.setRange(8, 20)
        self.fecha_size.setValue(11)
        self.fecha_bold = QCheckBox("Bold")

        f.addRow("Texto documento:", self.doc_text)
        f.addRow("Doc size:", self.doc_size)
        f.addRow("Doc align:", self.doc_align)
        f.addRow("", self.doc_bold)

        f.addRow("Fecha / hora:", self.fecha_text)
        f.addRow("Fecha size:", self.fecha_size)
        f.addRow("", self.fecha_bold)
        return box

    def _local_group(self):
        box = QGroupBox("Casa Matriz / Sucursal")
        f = QFormLayout(box)

        self.show_local = QCheckBox("Mostrar bloque local")
        self.show_local.setChecked(True)

        self.casa_title = QLineEdit("CASA MATRIZ")
        self.casa_text = QLineEdit("BARROS ARANA 724 AL 746")
        self.sucursal_title = QLineEdit("SUCURSAL")
        self.sucursal_text = QLineEdit("San Martin 886 Temuco · Independencia 777 Rancagua")
        self.contacto_text = QLineEdit("FONO 58 41 2467877 · E-mail: berlintxx@eastwestchile.cl")

        self.local_title_size = QSpinBox()
        self.local_title_size.setRange(8, 22)
        self.local_title_size.setValue(12)
        self.local_data_size = QSpinBox()
        self.local_data_size.setRange(8, 18)
        self.local_data_size.setValue(10)

        f.addRow("", self.show_local)
        f.addRow("Casa matriz título:", self.casa_title)
        f.addRow("Casa matriz texto:", self.casa_text)
        f.addRow("Sucursal título:", self.sucursal_title)
        f.addRow("Sucursal texto:", self.sucursal_text)
        f.addRow("Contacto:", self.contacto_text)
        f.addRow("Title size:", self.local_title_size)
        f.addRow("Data size:", self.local_data_size)
        return box

    def _cliente_group(self):
        box = QGroupBox("Datos de Cliente")
        f = QFormLayout(box)

        self.show_cliente = QCheckBox("Mostrar cliente")
        self.show_cliente.setChecked(True)

        self.cliente_title_text = QLineEdit("Razón Social / Datos de Cliente")
        self.cliente_title_size = QSpinBox()
        self.cliente_title_size.setRange(8, 22)
        self.cliente_title_size.setValue(12)
        self.cliente_title_bold = QCheckBox("Bold")

        self.cliente_data_size = QSpinBox()
        self.cliente_data_size.setRange(8, 18)
        self.cliente_data_size.setValue(10)

        self.cliente_razon = QLineEdit("Razón Social: ")
        self.cliente_rut = QLineEdit("R.U.T.: ")
        self.cliente_dir = QLineEdit("DIRECCIÓN: ")
        self.cliente_comuna = QLineEdit("Comuna: ")

        f.addRow("", self.show_cliente)
        f.addRow("Título cliente:", self.cliente_title_text)
        f.addRow("Title size:", self.cliente_title_size)
        f.addRow("", self.cliente_title_bold)
        f.addRow("Data size:", self.cliente_data_size)
        f.addRow("Razón social:", self.cliente_razon)
        f.addRow("RUT:", self.cliente_rut)
        f.addRow("Dirección:", self.cliente_dir)
        f.addRow("Comuna:", self.cliente_comuna)
        return box

    def _operacion_group(self):
        box = QGroupBox("Operación")
        f = QFormLayout(box)

        self.show_oper = QCheckBox("Mostrar bloque operación")
        self.show_oper.setChecked(True)

        self.oper_text = QLineEdit("Cajero : BRS11          R.No. 1745444\nPagar : Efectivo")
        self.oper_size = QSpinBox()
        self.oper_size.setRange(8, 18)
        self.oper_size.setValue(11)
        self.oper_bold = QCheckBox("Bold")

        f.addRow("", self.show_oper)
        f.addRow("Texto operación:", self.oper_text)
        f.addRow("Oper size:", self.oper_size)
        f.addRow("", self.oper_bold)
        return box

    def _detalle_group(self):
        box = QGroupBox("Detalle")
        f = QFormLayout(box)

        self.detalle_title_text = QLineEdit("Descripción        Cant.    P.Unit    Total")
        self.detalle_title_size = QSpinBox()
        self.detalle_title_size.setRange(8, 18)
        self.detalle_title_size.setValue(11)
        self.detalle_title_bold = QCheckBox("Bold")
        self.product_size = QSpinBox()
        self.product_size.setRange(8, 18)
        self.product_size.setValue(11)
        self.desc_col_width = QSpinBox()
        self.desc_col_width.setRange(120, 500)
        self.desc_col_width.setValue(220)

        self.qty_col_width = QSpinBox()
        self.qty_col_width.setRange(40, 120)
        self.qty_col_width.setValue(50)

        self.total_col_width = QSpinBox()
        self.total_col_width.setRange(60, 180)
        self.total_col_width.setValue(90)

        self.show_item_barcodes = QCheckBox("Mostrar barcode en items")
        self.show_item_barcodes.setChecked(True)

        f.addRow("Desc width:", self.desc_col_width)
        f.addRow("Qty width:", self.qty_col_width)
        f.addRow("Total width:", self.total_col_width)
        f.addRow("", self.show_item_barcodes)
        f.addRow("Header detalle:", self.detalle_title_text)
        f.addRow("Header size:", self.detalle_title_size)
        f.addRow("", self.detalle_title_bold)
        f.addRow("Product size:", self.product_size)
        return box

    def _totales_group(self):
        box = QGroupBox("Totales")
        f = QFormLayout(box)

        self.show_subtotal = QCheckBox("Mostrar subtotal")
        self.show_subtotal.setChecked(True)

        self.show_descuento = QCheckBox("Mostrar descuento")
        self.show_descuento.setChecked(True)

        self.show_iva = QCheckBox("Mostrar IVA")
        self.show_iva.setChecked(True)

        self.total_size = QSpinBox()
        self.total_size.setRange(10, 28)
        self.total_size.setValue(16)
        self.total_bold = QCheckBox("Total bold")
        self.total_bold.setChecked(True)
        self.total_align = QComboBox()
        self.total_align.addItems(["left", "center", "right"])
        self.total_label_text = QLineEdit("TOTAL                               1.000")
        f.addRow("Total text:", self.total_label_text)

        f.addRow("", self.show_subtotal)
        f.addRow("", self.show_descuento)
        f.addRow("", self.show_iva)
        f.addRow("Total size:", self.total_size)
        f.addRow("Total align:", self.total_align)
        f.addRow("", self.total_bold)
        return box

    def _footer_group(self):
        box = QGroupBox("Footer Legal")
        f = QFormLayout(box)

        self.footer1 = QLineEdit("NO SE ACEPTAN CAMBIOS NI DEVOLUCIONES")
        self.footer2 = QLineEdit("ART 14 LEY 19.496")
        self.footer3 = QLineEdit("")

        self.footer_size = QSpinBox()
        self.footer_size.setRange(8, 20)
        self.footer_size.setValue(11)
        self.footer_bold = QCheckBox("Footer bold")

        self.footer_align = QComboBox()
        self.footer_align.addItems(["left", "center", "right"])

        f.addRow("Msg 1:", self.footer1)
        f.addRow("Msg 2:", self.footer2)
        f.addRow("Msg 3:", self.footer3)
        f.addRow("Footer size:", self.footer_size)
        f.addRow("Footer align:", self.footer_align)
        f.addRow("", self.footer_bold)
        return box

    def _codes_group(self):
        box = QGroupBox("Barcode / QR / SII")
        f = QFormLayout(box)

        self.show_barcode = QCheckBox("Mostrar barcode")
        self.show_barcode.setChecked(True)

        self.barcode_value = QLineEdit("3504270-76.600.643-4")
        self.barcode_height = QSpinBox()
        self.barcode_height.setRange(40, 180)
        self.barcode_height.setValue(90)

        self.show_qr = QCheckBox("Mostrar QR")
        self.show_qr.setChecked(True)

        self.qr_value = QLineEdit("https://www.sii.cl")
        self.qr_size = QSpinBox()
        self.qr_size.setRange(60, 180)
        self.qr_size.setValue(100)

        self.codes_note = QLineEdit("Timbre Electrónico SII · Verifique este documento en www.sii.cl")

        f.addRow("", self.show_barcode)
        f.addRow("Barcode text:", self.barcode_value)
        f.addRow("Barcode height:", self.barcode_height)
        f.addRow("", self.show_qr)
        f.addRow("QR text:", self.qr_value)
        f.addRow("QR size:", self.qr_size)
        f.addRow("Nota inferior:", self.codes_note)
        return box

    # ------------------------------------------------------------------
    # HELPERS
    # ------------------------------------------------------------------
    def _add_sep(self):
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setObjectName("PreviewLine")
        self.preview_layout.addWidget(line)

    def _connect_all(self):
        for w in self.findChildren(QLineEdit):
            w.textChanged.connect(self.update_preview)

        for w in self.findChildren(QComboBox):
            w.currentTextChanged.connect(self.update_preview)

        for w in self.findChildren(QSpinBox):
            w.valueChanged.connect(self.update_preview)

        for w in self.findChildren(QCheckBox):
            w.stateChanged.connect(self.update_preview)

    def _align(self, text):
        return {
            "left": Qt.AlignLeft,
            "center": Qt.AlignCenter,
            "right": Qt.AlignRight
        }.get(text, Qt.AlignLeft)

    def _apply_font(self, label: QLabel, size: int, bold: bool, align: str):
        font = QFont()
        font.setPointSize(size)
        font.setBold(bold)
        label.setFont(font)
        label.setAlignment(self._align(align))

    def _show_widget(self, widget, state: bool):
        widget.setVisible(state)

    def pick_logo(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar logo",
            "",
            "Imagen (*.png *.jpg *.jpeg *.webp *.bmp)"
        )
        if path:
            self.logo_path.setText(path)

    def _make_qr(self, text: str) -> QPixmap | None:
        if not text.strip():
            return None
        tmp = os.path.join(tempfile.gettempdir(), "vr9_qr_temp.png")
        img = qrcode.make(text)
        img.save(tmp)
        return QPixmap(tmp)

    def _make_barcode(self, text: str) -> QPixmap | None:
        if not text.strip():
            return None
        try:
            tmp_base = os.path.join(tempfile.gettempdir(), "vr9_barcode_temp")
            code = barcode.get("code128", text, writer=ImageWriter())
            saved = code.save(
                tmp_base,
                options={
                    "write_text": False,
                    "module_height": 18.0,
                    "module_width": 0.22,
                    "quiet_zone": 1.5
                }
            )
            return QPixmap(saved)
        except Exception:
            return None

    # ------------------------------------------------------------------
    # PREVIEW
    # ------------------------------------------------------------------
    def update_preview(self):
        if self._building:
            return

        # paper
        if self.paper_width.currentText() == "58mm":
            self.preview.setFixedWidth(260)
        else:
            self.preview.setFixedWidth(360)

        ml = self.margin_left.value()
        mr = self.margin_right.value()
        top = 16
        bottom = 16
        self.preview_layout.setContentsMargins(ml, top, mr, bottom)
        self.preview_layout.setSpacing(self.line_spacing.value())

        # lines
        for line in self.preview.findChildren(QFrame, "PreviewLine"):
            line.setVisible(self.show_lines.isChecked())

        # logo
        self._show_widget(self.logo_label, self.show_logo.isChecked() and bool(self.logo_path.text().strip()))
        if self.show_logo.isChecked() and self.logo_path.text().strip() and Path(self.logo_path.text()).exists():
            pix = QPixmap(self.logo_path.text()).scaledToWidth(
                self.logo_width.value(),
                Qt.SmoothTransformation
            )
            self.logo_label.setPixmap(pix)
        else:
            self.logo_label.clear()

        # empresa
        self.lbl_header.setText(self.header_text.text())
        self._apply_font(self.lbl_header, self.header_size.value(), self.header_bold.isChecked(), self.header_align.currentText())

        self.lbl_razon.setText(self.razon_text.text())
        self._apply_font(self.lbl_razon, self.razon_size.value(), self.razon_bold.isChecked(), self.header_align.currentText())

        self.lbl_rut.setText(self.rut_text.text())
        self._apply_font(self.lbl_rut, self.rut_size.value(), self.rut_bold.isChecked(), self.header_align.currentText())

        self.lbl_giro.setText(self.giro_text.text())
        self._apply_font(self.lbl_giro, self.giro_size.value(), self.giro_bold.isChecked(), self.header_align.currentText())

        # documento
        self.lbl_doc.setText(self.doc_text.text())
        self._apply_font(self.lbl_doc, self.doc_size.value(), self.doc_bold.isChecked(), self.doc_align.currentText())

        self.lbl_fecha.setText(self.fecha_text.text())
        self._apply_font(self.lbl_fecha, self.fecha_size.value(), self.fecha_bold.isChecked(), self.doc_align.currentText())

        # local
        show_local = self.show_local.isChecked()
        for w in [self.lbl_casa_title, self.lbl_casa, self.lbl_sucursal_title, self.lbl_sucursal, self.lbl_contacto]:
            self._show_widget(w, show_local)

        self.lbl_casa_title.setText(self.casa_title.text())
        self._apply_font(self.lbl_casa_title, self.local_title_size.value(), True, "left")

        self.lbl_casa.setText(self.casa_text.text())
        self._apply_font(self.lbl_casa, self.local_data_size.value(), False, "left")

        self.lbl_sucursal_title.setText(self.sucursal_title.text())
        self._apply_font(self.lbl_sucursal_title, self.local_title_size.value(), True, "left")

        self.lbl_sucursal.setText(self.sucursal_text.text())
        self._apply_font(self.lbl_sucursal, self.local_data_size.value(), False, "left")

        self.lbl_contacto.setText(self.contacto_text.text())
        self._apply_font(self.lbl_contacto, self.local_data_size.value(), False, "left")

        # cliente
        show_cliente = self.show_cliente.isChecked()
        for w in [self.lbl_cliente_title, self.lbl_cliente_razon, self.lbl_cliente_rut, self.lbl_cliente_dir, self.lbl_cliente_comuna]:
            self._show_widget(w, show_cliente)

        self.lbl_cliente_title.setText(self.cliente_title_text.text())
        self._apply_font(self.lbl_cliente_title, self.cliente_title_size.value(), self.cliente_title_bold.isChecked(), "left")

        self.lbl_cliente_razon.setText(self.cliente_razon.text())
        self._apply_font(self.lbl_cliente_razon, self.cliente_data_size.value(), False, "left")

        self.lbl_cliente_rut.setText(self.cliente_rut.text())
        self._apply_font(self.lbl_cliente_rut, self.cliente_data_size.value(), False, "left")

        self.lbl_cliente_dir.setText(self.cliente_dir.text())
        self._apply_font(self.lbl_cliente_dir, self.cliente_data_size.value(), False, "left")

        self.lbl_cliente_comuna.setText(self.cliente_comuna.text())
        self._apply_font(self.lbl_cliente_comuna, self.cliente_data_size.value(), False, "left")

        # oper
        self._show_widget(self.lbl_oper, self.show_oper.isChecked())
        self.lbl_oper.setText(self.oper_text.text())
        self._apply_font(self.lbl_oper, self.oper_size.value(), self.oper_bold.isChecked(), "left")

        # detalle
        self.detalle_title.setText(self.detalle_title_text.text())
        self._apply_font(self.detalle_title, self.detalle_title_size.value(), self.detalle_title_bold.isChecked(), "left")

        self.detalle_line.setVisible(self.show_lines.isChecked())

        item_labels = [
            self.tbl_h_desc, self.tbl_h_cant, self.tbl_h_total,
            self.row1_desc, self.row1_cant, self.row1_total, self.row1_barcode,
            self.row2_desc, self.row2_cant, self.row2_total, self.row2_barcode,
        ]

        self.tbl_h_cant.setFixedWidth(self.qty_col_width.value())
        self.row1_cant.setFixedWidth(self.qty_col_width.value())
        self.row2_cant.setFixedWidth(self.qty_col_width.value())

        self.tbl_h_total.setFixedWidth(self.total_col_width.value())
        self.row1_total.setFixedWidth(self.total_col_width.value())
        self.row2_total.setFixedWidth(self.total_col_width.value())
        
        for lab in item_labels:
            f = QFont()
            f.setPointSize(self.product_size.value())
            lab.setFont(f)
        
        barcode_font = QFont()
        barcode_font.setPointSize(max(8, self.product_size.value() - 1))

        self.row1_barcode.setFont(barcode_font)
        self.row2_barcode.setFont(barcode_font)

        self.row1_barcode.setStyleSheet("color:#555;")
        self.row2_barcode.setStyleSheet("color:#555;")          

        self.total_line.setVisible(self.show_lines.isChecked())

        # totales
        self._show_widget(self.lbl_subtotal, self.show_subtotal.isChecked())
        self._show_widget(self.lbl_descuento, self.show_descuento.isChecked())
        self._show_widget(self.lbl_iva, self.show_iva.isChecked())

        self.lbl_subtotal.setText("Subtotal                               840")
        self.lbl_descuento.setText("Descuento                              0")
        self.lbl_iva.setText("IVA                                   160")
        self.lbl_total.setText(self.total_label_text.text())

        for lab in [self.lbl_subtotal, self.lbl_descuento, self.lbl_iva]:
            self._apply_font(
                lab,
                11,
                True,
                self.total_align.currentText()
            )

        self._apply_font(
            self.lbl_total,
            self.total_size.value(),
            self.total_bold.isChecked(),
            self.total_align.currentText()
        )
        self.lbl_total.setStyleSheet("padding-top:6px;padding-bottom:6px;")
        

        # footer
        self.lbl_footer1.setText(self.footer1.text())
        self.lbl_footer2.setText(self.footer2.text())
        self.lbl_footer3.setText(self.footer3.text())

        self._apply_font(self.lbl_footer1, self.footer_size.value(), self.footer_bold.isChecked(), self.footer_align.currentText())
        self._apply_font(self.lbl_footer2, self.footer_size.value(), self.footer_bold.isChecked(), self.footer_align.currentText())
        self._apply_font(self.lbl_footer3, self.footer_size.value(), self.footer_bold.isChecked(), self.footer_align.currentText())
        self._show_widget(self.lbl_footer3, bool(self.footer3.text().strip()))

        # barcode
        self._show_widget(self.barcode_label, self.show_barcode.isChecked())
        if self.show_barcode.isChecked():
            bpix = self._make_barcode(self.barcode_value.text())
            if bpix:
                scaled = bpix.scaledToHeight(self.barcode_height.value(), Qt.SmoothTransformation)
                self.barcode_label.setPixmap(scaled)
            else:
                self.barcode_label.clear()
        else:
            self.barcode_label.clear()

        # qr
        self._show_widget(self.qr_label, self.show_qr.isChecked())
        if self.show_qr.isChecked():
            qpix = self._make_qr(self.qr_value.text())
            if qpix:
                scaled = qpix.scaled(self.qr_size.value(), self.qr_size.value(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
                self.qr_label.setPixmap(scaled)
            else:
                self.qr_label.clear()
        else:
            self.qr_label.clear()

        self.lbl_codes_note.setText(self.codes_note.text())
        self._show_widget(self.lbl_codes_note, bool(self.codes_note.text().strip()))

    # ------------------------------------------------------------------
    # SAVE / LOAD
    # ------------------------------------------------------------------
    def _collect_config(self):
        return {
            "paper_width": self.paper_width.currentText(),
            "margin_left": self.margin_left.value(),
            "margin_right": self.margin_right.value(),
            "line_spacing": self.line_spacing.value(),
            "show_lines": self.show_lines.isChecked(),

            "show_logo": self.show_logo.isChecked(),
            "logo_path": self.logo_path.text(),
            "logo_width": self.logo_width.value(),

            "header_text": self.header_text.text(),
            "header_size": self.header_size.value(),
            "header_bold": self.header_bold.isChecked(),
            "header_align": self.header_align.currentText(),

            "razon_text": self.razon_text.text(),
            "razon_size": self.razon_size.value(),
            "razon_bold": self.razon_bold.isChecked(),

            "rut_text": self.rut_text.text(),
            "rut_size": self.rut_size.value(),
            "rut_bold": self.rut_bold.isChecked(),

            "giro_text": self.giro_text.text(),
            "giro_size": self.giro_size.value(),
            "giro_bold": self.giro_bold.isChecked(),

            "doc_text": self.doc_text.text(),
            "doc_size": self.doc_size.value(),
            "doc_bold": self.doc_bold.isChecked(),
            "doc_align": self.doc_align.currentText(),

            "fecha_text": self.fecha_text.text(),
            "fecha_size": self.fecha_size.value(),
            "fecha_bold": self.fecha_bold.isChecked(),

            "show_local": self.show_local.isChecked(),
            "casa_title": self.casa_title.text(),
            "casa_text": self.casa_text.text(),
            "sucursal_title": self.sucursal_title.text(),
            "sucursal_text": self.sucursal_text.text(),
            "contacto_text": self.contacto_text.text(),
            "local_title_size": self.local_title_size.value(),
            "local_data_size": self.local_data_size.value(),

            "show_cliente": self.show_cliente.isChecked(),
            "cliente_title_text": self.cliente_title_text.text(),
            "cliente_title_size": self.cliente_title_size.value(),
            "cliente_title_bold": self.cliente_title_bold.isChecked(),
            "cliente_data_size": self.cliente_data_size.value(),
            "cliente_razon": self.cliente_razon.text(),
            "cliente_rut": self.cliente_rut.text(),
            "cliente_dir": self.cliente_dir.text(),
            "cliente_comuna": self.cliente_comuna.text(),

            "show_oper": self.show_oper.isChecked(),
            "oper_text": self.oper_text.text(),
            "oper_size": self.oper_size.value(),
            "oper_bold": self.oper_bold.isChecked(),

            "detalle_title_text": self.detalle_title_text.text(),
            "detalle_title_size": self.detalle_title_size.value(),
            "detalle_title_bold": self.detalle_title_bold.isChecked(),
            "product_size": self.product_size.value(),

            "desc_col_width": self.desc_col_width.value(),
            "qty_col_width": self.qty_col_width.value(),
            "total_col_width": self.total_col_width.value(),
            "show_item_barcodes": self.show_item_barcodes.isChecked(),
            "total_label_text": self.total_label_text.text(),

            "show_subtotal": self.show_subtotal.isChecked(),
            "show_descuento": self.show_descuento.isChecked(),
            "show_iva": self.show_iva.isChecked(),
            "total_size": self.total_size.value(),
            "total_bold": self.total_bold.isChecked(),

            "footer1": self.footer1.text(),
            "footer2": self.footer2.text(),
            "footer3": self.footer3.text(),
            "footer_size": self.footer_size.value(),
            "footer_bold": self.footer_bold.isChecked(),
            "footer_align": self.footer_align.currentText(),

            "show_barcode": self.show_barcode.isChecked(),
            "barcode_value": self.barcode_value.text(),
            "barcode_height": self.barcode_height.value(),
            "show_qr": self.show_qr.isChecked(),
            "qr_value": self.qr_value.text(),
            "qr_size": self.qr_size.value(),
            "codes_note": self.codes_note.text(),
        }

    def save_config(self):
        try:
            data = self._collect_config()
            CONFIG_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            QMessageBox.information(self, "OK", "Configuración guardada ✅")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def load_config(self):
        if not CONFIG_FILE.exists():
            return
        try:
            self._building = True
            data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))

            # paper
            self.paper_width.setCurrentText(data.get("paper_width", "58mm"))
            self.margin_left.setValue(data.get("margin_left", 10))
            self.margin_right.setValue(data.get("margin_right", 10))
            self.line_spacing.setValue(data.get("line_spacing", 4))
            self.show_lines.setChecked(data.get("show_lines", True))

            # logo
            self.show_logo.setChecked(data.get("show_logo", False))
            self.logo_path.setText(data.get("logo_path", ""))
            self.logo_width.setValue(data.get("logo_width", 140))

            # empresa
            self.header_text.setText(data.get("header_text", "GALATA TREND"))
            self.header_size.setValue(data.get("header_size", 24))
            self.header_bold.setChecked(data.get("header_bold", True))
            self.header_align.setCurrentText(data.get("header_align", "center"))

            self.razon_text.setText(data.get("razon_text", "Importadora Galata SpA"))
            self.razon_size.setValue(data.get("razon_size", 14))
            self.razon_bold.setChecked(data.get("razon_bold", False))

            self.rut_text.setText(data.get("rut_text", "RUT: 78.325.343-7"))
            self.rut_size.setValue(data.get("rut_size", 10))
            self.rut_bold.setChecked(data.get("rut_bold", False))

            self.giro_text.setText(data.get("giro_text", "VENTA DE PRODUCTOS TEXTILES Y CALZADO AL POR MENOR Y MAYOR"))
            self.giro_size.setValue(data.get("giro_size", 9))
            self.giro_bold.setChecked(data.get("giro_bold", False))

            # documento
            self.doc_text.setText(data.get("doc_text", "BOLETA AFECTA ELECTRÓNICA : #3504270"))
            self.doc_size.setValue(data.get("doc_size", 12))
            self.doc_bold.setChecked(data.get("doc_bold", True))
            self.doc_align.setCurrentText(data.get("doc_align", "center"))

            self.fecha_text.setText(data.get("fecha_text", "Fecha: 09/03/2026 12:12:01"))
            self.fecha_size.setValue(data.get("fecha_size", 11))
            self.fecha_bold.setChecked(data.get("fecha_bold", True))

            # local
            self.show_local.setChecked(data.get("show_local", True))
            self.casa_title.setText(data.get("casa_title", "CASA MATRIZ"))
            self.casa_text.setText(data.get("casa_text", "BARROS ARANA 724 AL 746"))
            self.sucursal_title.setText(data.get("sucursal_title", "SUCURSAL"))
            self.sucursal_text.setText(data.get("sucursal_text", "San Martin 886 Temuco · Independencia 777 Rancagua"))
            self.contacto_text.setText(data.get("contacto_text", "FONO 58 41 2467877 · E-mail: berlintxx@eastwestchile.cl"))
            self.local_title_size.setValue(data.get("local_title_size", 12))
            self.local_data_size.setValue(data.get("local_data_size", 10))

            # cliente
            self.show_cliente.setChecked(data.get("show_cliente", True))
            self.cliente_title_text.setText(data.get("cliente_title_text", "Razón Social / Datos de Cliente"))
            self.cliente_title_size.setValue(data.get("cliente_title_size", 12))
            self.cliente_title_bold.setChecked(data.get("cliente_title_bold", True))
            self.cliente_data_size.setValue(data.get("cliente_data_size", 10))
            self.cliente_razon.setText(data.get("cliente_razon", "Razón Social: "))
            self.cliente_rut.setText(data.get("cliente_rut", "R.U.T.: "))
            self.cliente_dir.setText(data.get("cliente_dir", "DIRECCIÓN: "))
            self.cliente_comuna.setText(data.get("cliente_comuna", "Comuna: "))

            # oper
            self.show_oper.setChecked(data.get("show_oper", True))
            self.oper_text.setText(data.get("oper_text", "Cajero : BRS11          R.No. 1745444\nPagar : Efectivo"))
            self.oper_size.setValue(data.get("oper_size", 11))
            self.oper_bold.setChecked(data.get("oper_bold", True))

            # detalle
            self.detalle_title_text.setText(data.get("detalle_title_text", "Descripción        Cant.    P.Unit    Total"))
            self.detalle_title_size.setValue(data.get("detalle_title_size", 11))
            self.detalle_title_bold.setChecked(data.get("detalle_title_bold", True))
            self.product_size.setValue(data.get("product_size", 11))

            self.desc_col_width.setValue(data.get("desc_col_width", 220))
            self.qty_col_width.setValue(data.get("qty_col_width", 50))
            self.total_col_width.setValue(data.get("total_col_width", 90))
            self.show_item_barcodes.setChecked(data.get("show_item_barcodes", True))
            self.total_label_text.setText(data.get("total_label_text", "TOTAL                               1.000"))

            self.detalle_line = QFrame()
            self.detalle_line.setFrameShape(QFrame.HLine)
            self.preview_layout.addWidget(self.detalle_line)

            # totales
            self.show_subtotal.setChecked(data.get("show_subtotal", True))
            self.show_descuento.setChecked(data.get("show_descuento", True))
            self.show_iva.setChecked(data.get("show_iva", True))
            self.total_size.setValue(data.get("total_size", 16))
            self.total_bold.setChecked(data.get("total_bold", True))

            # footer
            self.footer1.setText(data.get("footer1", "NO SE ACEPTAN CAMBIOS NI DEVOLUCIONES"))
            self.footer2.setText(data.get("footer2", "ART 14 LEY 19.496"))
            self.footer3.setText(data.get("footer3", ""))
            self.footer_size.setValue(data.get("footer_size", 11))
            self.footer_bold.setChecked(data.get("footer_bold", False))
            self.footer_align.setCurrentText(data.get("footer_align", "center"))

            # codes
            self.show_barcode.setChecked(data.get("show_barcode", True))
            self.barcode_value.setText(data.get("barcode_value", "3504270-76.600.643-4"))
            self.barcode_height.setValue(data.get("barcode_height", 90))
            self.show_qr.setChecked(data.get("show_qr", True))
            self.qr_value.setText(data.get("qr_value", "https://www.sii.cl"))
            self.qr_size.setValue(data.get("qr_size", 100))
            self.codes_note.setText(data.get("codes_note", "Timbre Electrónico SII · Verifique este documento en www.sii.cl"))

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo cargar configuración:\n{e}")
        finally:
            self._building = False
            self.update_preview()

    # ------------------------------------------------------------------
    # TEST PRINT
    # ------------------------------------------------------------------
    def test_print(self):
        try:
            from print_boleta import print_boleta

            venta = {
                "id": 3504270,
                "fecha": "2026-03-09 12:12:01",
                "doc": "BOLETA",
                "caja": "BRS11",
                "medio_pago": "Efectivo",
            }

            items = [
                {"codigo": "BOL14", "descripcion": "Bolsa Chica-14", "valor": 1000, "precio": 100, "cantidad": 10},
                {"codigo": "JNS01", "descripcion": "Jeans Azul", "valor": 19990, "precio": 19990, "cantidad": 1},
            ]

            print_boleta(venta, items)
            QMessageBox.information(self, "OK", "Boleta de prueba enviada a impresora ✅")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))