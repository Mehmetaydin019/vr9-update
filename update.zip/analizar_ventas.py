# analizar_ventas.py
from __future__ import annotations

from typing import Dict, List, Any

from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QDialog,
    QFormLayout, QComboBox, QDateEdit, QMessageBox, QToolButton
)

import db


def _money(n: int) -> str:
    try:
        return f"{int(n):,}".replace(",", ".")
    except Exception:
        return str(n)


class FiltrosDialog(QDialog):
    def __init__(self, parent=None, current_filters: Dict[str, Any] | None = None):
        super().__init__(parent)
        self.setWindowTitle("Filtros")
        self.setFixedSize(520, 420)

        current_filters = current_filters or {}

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        title = QLabel("Filtro de Informe")
        title.setFont(QFont("Segoe UI", 14, 800))
        root.addWidget(title)

        form = QFormLayout()
        form.setSpacing(10)

        self.dt_desde = QDateEdit()
        self.dt_desde.setCalendarPopup(True)
        self.dt_desde.setDisplayFormat("dd.MM.yyyy")
        self.dt_desde.setDate(current_filters.get("desde", QDate.currentDate()))

        self.dt_hasta = QDateEdit()
        self.dt_hasta.setCalendarPopup(True)
        self.dt_hasta.setDisplayFormat("dd.MM.yyyy")
        self.dt_hasta.setDate(current_filters.get("hasta", QDate.currentDate()))

        self.cb_sucursal = QComboBox()
        self.cb_saco = QComboBox()
        self.cb_producto = QComboBox()
        self.cb_genero = QComboBox()

        self._load_filters(current_filters)

        form.addRow("Desde:", self.dt_desde)
        form.addRow("Hasta:", self.dt_hasta)
        form.addRow("Sucursal:", self.cb_sucursal)
        form.addRow("Saco:", self.cb_saco)
        form.addRow("Producto:", self.cb_producto)
        form.addRow("Género:", self.cb_genero)

        root.addLayout(form)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)

        self.btn_cancel = QPushButton("Cancelar")
        self.btn_ok = QPushButton("Informar")
        self.btn_ok.setObjectName("Primary")

        self.btn_cancel.clicked.connect(self.reject)
        self.btn_ok.clicked.connect(self.accept)

        btn_row.addWidget(self.btn_cancel)
        btn_row.addWidget(self.btn_ok)
        root.addLayout(btn_row)

        self.setStyleSheet("""
            QDialog { background:#ffffff; }
            QDateEdit, QComboBox {
                min-height:36px;
                border:1px solid #cbd5e1;
                border-radius:10px;
                padding:6px 8px;
                background:#ffffff;
                font-weight:700;
            }
            QPushButton {
                min-height:38px;
                padding:8px 12px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:800;
            }
            QPushButton#Primary {
                background:#2563eb;
                color:#ffffff;
                border:1px solid #2563eb;
            }
        """)

    def _load_filters(self, current_filters: Dict[str, Any]):
        try:
            vals = db.fetch_analizar_filter_values()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"Filtros yüklenemedi:\n{e}")
            vals = {
                "sucursales": [],
                "sacos": [],
                "productos": [],
                "generos": [],
            }

        self.cb_sucursal.addItem("TODAS")
        for x in vals.get("sucursales", []):
            self.cb_sucursal.addItem(str(x))

        self.cb_saco.addItem("TODOS")
        for x in vals.get("sacos", []):
            self.cb_saco.addItem(str(x))

        self.cb_producto.addItem("TODOS")
        for x in vals.get("productos", []):
            self.cb_producto.addItem(str(x))

        self.cb_genero.addItem("TODOS")
        for x in vals.get("generos", []):
            self.cb_genero.addItem(str(x))

        def set_combo(cb: QComboBox, value: str):
            idx = cb.findText(value)
            if idx >= 0:
                cb.setCurrentIndex(idx)

        set_combo(self.cb_sucursal, current_filters.get("sucursal", "TODAS"))
        set_combo(self.cb_saco, current_filters.get("saco", "TODOS"))
        set_combo(self.cb_producto, current_filters.get("producto", "TODOS"))
        set_combo(self.cb_genero, current_filters.get("genero", "TODOS"))

    def get_filters(self) -> Dict[str, Any]:
        return {
            "desde": self.dt_desde.date(),
            "hasta": self.dt_hasta.date(),
            "sucursal": self.cb_sucursal.currentText().strip(),
            "saco": self.cb_saco.currentText().strip(),
            "producto": self.cb_producto.currentText().strip(),
            "genero": self.cb_genero.currentText().strip(),
        }


class AnalizarVentasScreen(QWidget):
    def __init__(self):
        super().__init__()

        self.current_filters: Dict[str, Any] = {
            "desde": QDate.currentDate(),
            "hasta": QDate.currentDate(),
            "sucursal": "TODAS",
            "saco": "TODOS",
            "producto": "TODOS",
            "genero": "TODOS",
        }

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 22, 22, 22)
        root.setSpacing(12)

        top = QHBoxLayout()

        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(8)

        top.addStretch(1)

        self.btn_filtros = QPushButton("🔍")
        self.btn_filtros.setFixedSize(42, 36)
        self.btn_filtros.setToolTip("Filtros")
        self.btn_filtros.setObjectName("FilterBtn")
        self.btn_filtros.clicked.connect(self.open_filters)
        top.addWidget(self.btn_filtros)

        root.addLayout(top)

        self.lbl_info = QLabel("")
        self.lbl_info.setStyleSheet("color:#64748b; font-size:12px; font-weight:700;")
        root.addWidget(self.lbl_info)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels([
            "Sucursal",
            "Saco",
            "Cantidad",
            "Kg Total",
            "Precio x Und",
            "Procio x Kg",
            "Total"
        ])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(self.table.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(self.table.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(self.table.SelectionMode.SingleSelection)

        hh = self.table.horizontalHeader()
        for i in range(7):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)

        root.addWidget(self.table, 1)

        self.lbl_totals = QLabel("Cantidad total: 0   |   Total general: 0")
        self.lbl_totals.setStyleSheet("font-size:14px; font-weight:900;")
        root.addWidget(self.lbl_totals)

        self.setStyleSheet("""
            QWidget { background:#ffffff; }
            QTableWidget {
                background:#ffffff;
                border:1px solid #e2e8f0;
                border-radius:12px;
                font-size:14px;
                font-weight:700;
            }
            QHeaderView::section {
                background:#f8fafc;
                padding:8px;
                font-weight:900;
                border:0px;
                border-bottom:1px solid #e2e8f0;
            }
            QPushButton {
                min-height:34px;
                padding:6px 12px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:800;
            }

            QPushButton#FilterBtn {
                background:#ffffff;
                color:#0f172a;
                border:1px solid #cbd5e1;
                font-size:16px;
                font-weight:900;
            }
           
            QPushButton#FilterBtn:hover {
                background:#f8fafc;
                border:1px solid #94a3b8;
            }
        """)

    def open_filters(self):
        dlg = FiltrosDialog(self, self.current_filters)
        if dlg.exec() != QDialog.Accepted:
            return

        self.current_filters = dlg.get_filters()
        self.run_report()

    def apply_external_filters(self, filters: dict):
        try:
            fecha_desde = filters.get("fecha_desde") or filters.get("desde")
            fecha_hasta = filters.get("fecha_hasta") or filters.get("hasta")

            if isinstance(fecha_desde, str) and fecha_desde:
                self.current_filters["desde"] = QDate.fromString(fecha_desde, "yyyy-MM-dd")
            elif isinstance(fecha_desde, QDate):
                self.current_filters["desde"] = fecha_desde

            if isinstance(fecha_hasta, str) and fecha_hasta:
                self.current_filters["hasta"] = QDate.fromString(fecha_hasta, "yyyy-MM-dd")
            elif isinstance(fecha_hasta, QDate):
                self.current_filters["hasta"] = fecha_hasta

            self.current_filters["sucursal"] = (filters.get("sucursal") or "TODAS").strip() or "TODAS"
            self.current_filters["saco"] = (filters.get("saco") or "TODOS").strip() or "TODOS"
            self.current_filters["producto"] = (filters.get("producto") or "TODOS").strip() or "TODOS"
            self.current_filters["genero"] = (filters.get("genero") or "TODOS").strip() or "TODOS"

            self.run_report()

        except Exception as e:
            QMessageBox.critical(self, "Filtros", f"No se pudieron aplicar los filtros externos:\n{e}")

    def run_report(self):
        try:
            rows = db.fetch_analizar_ventas(
                desde=self.current_filters["desde"].toString("yyyy-MM-dd"),
                hasta=self.current_filters["hasta"].toString("yyyy-MM-dd"),
                sucursal=self.current_filters["sucursal"],
                saco=self.current_filters["saco"],
                producto=self.current_filters["producto"],
                genero=self.current_filters["genero"],
            )
        except Exception as e:
            QMessageBox.critical(self, "DB", f"Informe oluşturulamadı:\n{e}")
            return

        self.table.setRowCount(0)

        total_cantidad = 0
        total_kg = 0.0
        total_general = 0

        for i, r in enumerate(rows):
            self.table.insertRow(i)

            sucursal = str(r.get("sucursal", "") or "")
            saco = str(r.get("saco", "") or "")
            producto = str(r.get("producto", "") or "")
            cantidad = int(r.get("cantidad", 0) or 0)
            kg_total = float(r.get("kg_total", 0) or 0)
            precio_prom = int(r.get("precio_promedio", 0) or 0)
            precio_por_kg = int(r.get("precio_por_kg", 0) or 0)
            total = int(r.get("total", 0) or 0)

            self.table.setItem(i, 0, QTableWidgetItem(sucursal))
            self.table.setItem(i, 1, QTableWidgetItem(saco))
            self.table.setItem(i, 2, QTableWidgetItem(str(cantidad)))
            self.table.setItem(i, 3, QTableWidgetItem(f"{kg_total:.2f}"))
            self.table.setItem(i, 4, QTableWidgetItem(_money(precio_prom)))
            self.table.setItem(i, 5, QTableWidgetItem(_money(precio_por_kg)))
            self.table.setItem(i, 6, QTableWidgetItem(_money(total)))

            for col in (2, 3, 4, 5, 6):
                item = self.table.item(i, col)
                if item:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

            total_cantidad += cantidad
            total_kg += kg_total
            total_general += total

        for row in range(self.table.rowCount()):
            for col in (2, 3, 4, 5, 6):
                it = self.table.item(row, col)
                if it:
                    it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)

        self.lbl_totals.setText(
            f"Cantidad total: {_money(total_cantidad)}   |   Kg total: {total_kg:.2f}   |   Total general: {_money(total_general)}"
        )

    def set_embedded_mode(self, enabled=True):
        if not enabled:
            return

        # genel margin/spaceleri küçült
        if self.layout():
            self.layout().setContentsMargins(0, 0, 0, 0)
            self.layout().setSpacing(0)

        # Üstteki filtre/büyüteç butonlarını gizlemeye çalış
        for btn in self.findChildren(QPushButton):
            txt = (btn.text() or "").lower()
            if "filtro" in txt or "filtrar" in txt or "buscar" in txt or "🔎" in txt:
                btn.hide()

        for btn in self.findChildren(QToolButton):
            txt = (btn.text() or "").lower()
            if "filtro" in txt or "filtrar" in txt or "buscar" in txt or "🔎" in txt:
                btn.hide()

        # Boşluk yapan üst widget/container varsa onları da daralt
        for w in self.findChildren(QWidget):
            name = w.objectName().lower() if w.objectName() else ""
            if "filter" in name or "toolbar" in name or "topbar" in name:
                w.hide()

if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = AnalizarVentasScreen()
    window.show()
    sys.exit(app.exec())