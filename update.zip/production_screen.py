from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from datetime import datetime

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QStackedWidget, QLineEdit,
    QSpinBox, QMessageBox, QFrame
)

import db
from barcode import EAN13
from barcode.writer import ImageWriter
from label_print import LabelRow, build_labels_pdf


def _today_ddmmyyyy() -> str:
    return datetime.now().strftime("%d/%m/%Y")


def _build_descripcion(categoria: str, producto: str, genero: str) -> str:
    cat = (categoria or "").strip().lower()
    prod = (producto or "").strip()
    gen = (genero or "").strip()

    # Kural: ropa/calzado/accesorios => "S.Hand" + Producto + Genero
    if cat in ("ropa", "calzado", "accesorios"):
        return f"S.Hand {prod} {gen}".strip()

    # Kural: hogar => "Retorno" + Producto
    if cat == "hogar":
        return f"Retorno {prod}".strip()

    # fallback
    return f"{prod} {gen}".strip()


class ProductionScreen(QWidget):
    """
    Wizard Flow:
      1) Saco seç (checkbox list) -> Abrir saco
      2) Género seç -> Continuar
      3) Categoría seç -> Continuar
      4) Producto seç -> Continuar
      5) Talla seç -> Continuar
      6) Precio + Cantidad -> Generar (DB + barcode PNG + PDF)
    """

    def __init__(self):
        super().__init__()
        self.setObjectName("ProductionScreen")

        self.data = {
            "saco": None,
            "saco_kg": 0,
            "genero": None,
            "categoria": None,
            "producto": None,
            "talla": None,
        }

        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(10)

        title = QLabel("Producción (Wizard)")
        title.setStyleSheet("font-size:22px;font-weight:700;")
        root.addWidget(title)

        self.subtitle = QLabel("Paso 1/6 — Selecciona Saco")
        self.subtitle.setStyleSheet("font-size:14px;color:#666;")
        root.addWidget(self.subtitle)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        root.addWidget(line)

        self.stack = QStackedWidget()
        root.addWidget(self.stack, 1)

        # Bottom nav
        nav = QHBoxLayout()
        self.btn_back = QPushButton("◀ Atrás")
        self.btn_back.clicked.connect(self.go_back)

        self.btn_next = QPushButton("Continuar ▶")
        self.btn_next.clicked.connect(self.go_next)

        self.btn_back.setMinimumHeight(40)
        self.btn_next.setMinimumHeight(40)

        nav.addWidget(self.btn_back)
        nav.addStretch(1)
        nav.addWidget(self.btn_next)
        root.addLayout(nav)

        # Pages
        self.page_saco = self._page_saco()
        self.page_genero = self._page_genero()
        self.page_categoria = self._page_categoria()
        self.page_producto = self._page_producto()
        self.page_talla = self._page_talla()
        self.page_precio_qty = self._page_precio_qty()

        self.stack.addWidget(self.page_saco)        # 0
        self.stack.addWidget(self.page_genero)      # 1
        self.stack.addWidget(self.page_categoria)   # 2
        self.stack.addWidget(self.page_producto)    # 3
        self.stack.addWidget(self.page_talla)       # 4
        self.stack.addWidget(self.page_precio_qty)  # 5

        self._refresh_sacos()
        self._refresh_generos()
        self._refresh_categorias()

        self._update_nav()

    # ---------------- UI Pages ----------------

    def _page_saco(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        info = QLabel("Elige un Saco (checkbox). Luego 'Continuar'.")
        info.setStyleSheet("font-size:14px;")
        v.addWidget(info)

        self.saco_list = QListWidget()
        self.saco_list.setStyleSheet("font-size:16px;")
        v.addWidget(self.saco_list, 1)

        return w

    def _page_genero(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        info = QLabel("Selecciona Género:")
        info.setStyleSheet("font-size:14px;")
        v.addWidget(info)

        self.genero_list = QListWidget()
        self.genero_list.setStyleSheet("font-size:16px;")
        v.addWidget(self.genero_list, 1)

        return w

    def _page_categoria(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        info = QLabel("Selecciona Categoría:")
        info.setStyleSheet("font-size:14px;")
        v.addWidget(info)

        self.categoria_list = QListWidget()
        self.categoria_list.setStyleSheet("font-size:16px;")
        v.addWidget(self.categoria_list, 1)

        return w

    def _page_producto(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        info = QLabel("Selecciona Producto (filtrado por Categoría):")
        info.setStyleSheet("font-size:14px;")
        v.addWidget(info)

        self.producto_list = QListWidget()
        self.producto_list.setStyleSheet("font-size:16px;")
        v.addWidget(self.producto_list, 1)

        return w

    def _page_talla(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(8)

        info = QLabel("Selecciona Talla (si aplica):")
        info.setStyleSheet("font-size:14px;")
        v.addWidget(info)

        self.talla_list = QListWidget()
        self.talla_list.setStyleSheet("font-size:16px;")
        v.addWidget(self.talla_list, 1)

        hint = QLabel("Hogar gibi ürünlerde talla '-' olabilir.")
        hint.setStyleSheet("color:#777;")
        v.addWidget(hint)

        return w

    def _page_precio_qty(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        v.setSpacing(10)

        info = QLabel("Precio y Cantidad:")
        info.setStyleSheet("font-size:14px;")
        v.addWidget(info)

        self.precio_input = QLineEdit()
        self.precio_input.setPlaceholderText("Precio (ej: 2499)")
        self.precio_input.setStyleSheet("font-size:18px;padding:8px;")
        v.addWidget(self.precio_input)

        row = QHBoxLayout()
        lbl_qty = QLabel("Cantidad:")
        lbl_qty.setStyleSheet("font-size:14px;")
        row.addWidget(lbl_qty)

        self.qty_input = QSpinBox()
        self.qty_input.setRange(1, 1000)
        self.qty_input.setValue(1)
        self.qty_input.setStyleSheet("font-size:18px;padding:6px;")
        row.addWidget(self.qty_input, 1)

        v.addLayout(row)

        self.btn_generate = QPushButton("✅ Generar (DB + PNG + PDF)")
        self.btn_generate.setMinimumHeight(46)
        self.btn_generate.clicked.connect(self.generate_labels)
        v.addWidget(self.btn_generate)

        self.summary = QLabel("")
        self.summary.setStyleSheet("color:#444;")
        self.summary.setWordWrap(True)
        v.addWidget(self.summary)

        v.addStretch(1)
        return w

    # ---------------- Data refresh ----------------

    def _refresh_sacos(self):
        self.saco_list.clear()
        sacos = db.list_sacos()  # beklenen: [{"id":..,"codigo":"QBMC","kg":25}, ...] veya benzeri
        for s in sacos:
            codigo = s.get("codigo") or s.get("saco") or s.get("nombre") or ""
            kg = s.get("kg") or s.get("saco_kg") or 0
            text = f"{codigo}  (kg:{kg})"
            it = QListWidgetItem(text)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Unchecked)
            it.setData(Qt.UserRole, {"codigo": codigo, "kg": kg})
            self.saco_list.addItem(it)

    def _refresh_generos(self):
        self.genero_list.clear()
        for g in db.list_generos():  # [{"id":1,"nombre":"Hombre"}, ...]
            nombre = g.get("nombre") or g.get("name") or ""
            self.genero_list.addItem(nombre)

    def _refresh_categorias(self):
        self.categoria_list.clear()
        for c in db.list_categorias():  # ["ropa","calzado","hogar","accesorios"] veya dict listesi
            if isinstance(c, dict):
                nombre = c.get("nombre") or c.get("name") or ""
            else:
                nombre = str(c)
            self.categoria_list.addItem(nombre)

    def _refresh_productos(self):
        self.producto_list.clear()
        cat = self.data.get("categoria")
        productos = db.list_productos_by_categoria(cat)  # örn ["Blusa","Calcetin","Funda..."]
        for p in productos:
            if isinstance(p, dict):
                nombre = p.get("nombre") or p.get("name") or ""
            else:
                nombre = str(p)
            self.producto_list.addItem(nombre)

    def _refresh_tallas(self):
        self.talla_list.clear()
        cat = (self.data.get("categoria") or "").strip().lower()

        # hogar ise talla '-' tek seçenek
        if cat == "hogar":
            self.talla_list.addItem("-")
            return

        for t in db.list_tallas():  # ["XS","S","M","L",...]
            self.talla_list.addItem(str(t))

    # ---------------- Wizard nav ----------------

    def _update_nav(self):
        idx = self.stack.currentIndex()
        steps = 6
        self.subtitle.setText(f"Paso {idx+1}/{steps}")

        self.btn_back.setEnabled(idx > 0)

        # son sayfada Next kapat, Generate var
        if idx == 5:
            self.btn_next.setEnabled(False)
        else:
            self.btn_next.setEnabled(True)

        # Özet
        self.summary.setText(
            f"Saco: {self.data.get('saco') or '-'} | "
            f"Género: {self.data.get('genero') or '-'} | "
            f"Categoría: {self.data.get('categoria') or '-'} | "
            f"Producto: {self.data.get('producto') or '-'} | "
            f"Talla: {self.data.get('talla') or '-'}"
        )

    def go_back(self):
        idx = self.stack.currentIndex()
        if idx <= 0:
            return
        self.stack.setCurrentIndex(idx - 1)
        self._update_nav()

    def go_next(self):
        idx = self.stack.currentIndex()

        # Validate each step
        if idx == 0:
            checked = []
            for i in range(self.saco_list.count()):
                it = self.saco_list.item(i)
                if it.checkState() == Qt.Checked:
                    checked.append(it)
            if not checked:
                QMessageBox.warning(self, "Error", "Saco seçmelisin (checkbox).")
                return
            if len(checked) > 1:
                QMessageBox.warning(self, "Error", "Şimdilik 1 saco seçelim.")
                return
            data = checked[0].data(Qt.UserRole)
            self.data["saco"] = data["codigo"]
            self.data["saco_kg"] = int(data.get("kg") or 0)

        elif idx == 1:
            it = self.genero_list.currentItem()
            if not it:
                QMessageBox.warning(self, "Error", "Género seçmelisin.")
                return
            self.data["genero"] = it.text()

        elif idx == 2:
            it = self.categoria_list.currentItem()
            if not it:
                QMessageBox.warning(self, "Error", "Categoría seçmelisin.")
                return
            self.data["categoria"] = it.text()
            self._refresh_productos()

        elif idx == 3:
            it = self.producto_list.currentItem()
            if not it:
                QMessageBox.warning(self, "Error", "Producto seçmelisin.")
                return
            self.data["producto"] = it.text()
            self._refresh_tallas()

        elif idx == 4:
            it = self.talla_list.currentItem()
            if not it:
                QMessageBox.warning(self, "Error", "Talla seçmelisin.")
                return
            self.data["talla"] = it.text()

        # Go next
        if idx < 5:
            self.stack.setCurrentIndex(idx + 1)
            self._update_nav()

    # ---------------- Generate ----------------

    def generate_labels(self):
        # final validation
        for k in ("saco", "genero", "categoria", "producto", "talla"):
            if not self.data.get(k):
                QMessageBox.warning(self, "Error", f"Eksik seçim: {k}")
                return

        try:
            precio = int(self.precio_input.text().strip())
        except:
            QMessageBox.warning(self, "Error", "Precio geçersiz.")
            return

        qty = int(self.qty_input.value())
        categoria = self.data["categoria"]
        producto = self.data["producto"]
        genero = self.data["genero"]
        talla = self.data["talla"] or "-"

        descripcion_final = _build_descripcion(categoria, producto, genero)

        # 1) DB + barkod listesi
        barcodes = db.bulk_generate_labels(
            qty=qty,
            descripcion=descripcion_final,
            precio=precio,
            saco_codigo=self.data["saco"],
            saco_kg=self.data.get("saco_kg") or 0,
            genero=genero,
            categoria=categoria,
            producto=producto,
            talla=talla,
            prefix="990"
        )

        # 2) Barkod PNG üret
        out_dir = Path("tickets") / "barcodes"
        out_dir.mkdir(parents=True, exist_ok=True)

        rows = []
        fecha = _today_ddmmyyyy()

        for bc in barcodes:
            ean = EAN13(bc, writer=ImageWriter())
            saved = ean.save(str(out_dir / bc))  # returns path without extension sometimes
            barcode_path = Path(saved)
            if barcode_path.suffix.lower() != ".png":
                barcode_path = barcode_path.with_suffix(".png")

            rows.append(
                LabelRow(
                    barcode=bc,
                    saco=self.data["saco"],
                    fecha=fecha,
                    descripcion=descripcion_final,
                    talla=talla if talla else "-",
                    precio=precio,
                    barcode_png=barcode_path
                )
            )

        # 3) PDF üret (etiket: 45mm x 105mm)
        pdf_path = build_labels_pdf(rows, Path("tickets") / "labels.pdf")

        QMessageBox.information(
            self, "OK",
            f"Generado!\n\nCantidad: {qty}\nPDF: {pdf_path}\n\n"
            f"Descripción: {descripcion_final}"
        )

        # İstersen işlem bitince başa dön
        self.stack.setCurrentIndex(0)
        self._update_nav()