# ventas_report.py
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import db
from datetime import datetime

DB_NAME = str(db.DB_PATH)


def db_connect():
    return sqlite3.connect(DB_NAME)


def money(n: int) -> str:
    try:
        return f"{int(n):,}".replace(",", ".")
    except Exception:
        return str(n)


def ensure_tables():
    con = db_connect()
    cur = con.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ventas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            caja TEXT NOT NULL,
            doc TEXT NOT NULL,
            rut TEXT,
            razon TEXT,
            total INTEGER NOT NULL,
            promo INTEGER NOT NULL DEFAULT 0,
            medio_pago TEXT NOT NULL
        )
    """)
    con.commit()
    con.close()


def query_cierre(fecha_yyyy_mm_dd: str, caja: str):
    ensure_tables()
    con = db_connect()
    cur = con.cursor()

    start = f"{fecha_yyyy_mm_dd} 00:00:00"
    end = f"{fecha_yyyy_mm_dd} 23:59:59"

    cur.execute("""
        SELECT
            medio_pago,
            COUNT(*) as n,
            COALESCE(SUM(total), 0) as total_sum,
            COALESCE(SUM(promo), 0) as promo_sum
        FROM ventas
        WHERE caja = ? AND fecha BETWEEN ? AND ?
        GROUP BY medio_pago
    """, (caja, start, end))
    rows = cur.fetchall()

    cur.execute("""
        SELECT
            COUNT(*) as n,
            COALESCE(SUM(total), 0) as total_sum,
            COALESCE(SUM(promo), 0) as promo_sum
        FROM ventas
        WHERE caja = ? AND fecha BETWEEN ? AND ?
    """, (caja, start, end))
    overall = cur.fetchone()

    con.close()
    return rows, overall


# ✅ ÖNEMLİ: main burayı çağıracak → parent almalı
def open_cierre_caja(parent):
    return open_ventas_report(parent)


def open_ventas_report(parent=None):
    root = tk.Tk()
    root.withdraw()

    win = tk.Toplevel(root)
    def _on_close():
        try:
            win.destroy()
        finally:
            if root is not None:
                root.destroy()
    win.protocol('WM_DELETE_WINDOW', _on_close)
    win.title("VR9 - Cierre de Caja (Resumen)")
    win.geometry("900x540")
    win.minsize(820, 480)

    header = tk.Frame(win, bg="#111827")
    header.pack(fill="x")
    tk.Label(header, text="CIERRE DE CAJA - RESUMEN", bg="#111827", fg="white",
             font=("Segoe UI", 16, "bold")).pack(side="left", padx=16, pady=12)
    tk.Label(header, text=f"DB: {DB_NAME}", bg="#111827", fg="#94a3b8",
             font=("Segoe UI", 10)).pack(side="left", padx=10)

    body = tk.Frame(win)
    body.pack(fill="both", expand=True, padx=16, pady=16)

    filters = tk.Frame(body)
    filters.pack(fill="x", pady=(0, 10))

    # tkcalendar varsa DateEntry kullan
    use_calendar = False
    try:
        from tkcalendar import DateEntry  # type: ignore
        use_calendar = True
    except Exception:
        use_calendar = False
        DateEntry = None  # noqa

    tk.Label(filters, text="Fecha:", font=("Segoe UI", 10, "bold")).grid(row=0, column=0, sticky="w")

    if use_calendar:
        date_var = tk.StringVar()
        date_entry = DateEntry(filters, textvariable=date_var, date_pattern="yyyy-mm-dd")
        date_entry.grid(row=1, column=0, padx=(0, 12), sticky="w")
        date_var.set(datetime.now().strftime("%Y-%m-%d"))
    else:
        date_var = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        date_entry = tk.Entry(filters, textvariable=date_var, width=14)
        date_entry.grid(row=1, column=0, padx=(0, 12), sticky="w")
        tk.Label(filters, text="(yyyy-mm-dd)", fg="#6b7280").grid(row=2, column=0, sticky="w")

    tk.Label(filters, text="Caja:", font=("Segoe UI", 10, "bold")).grid(row=0, column=1, sticky="w")
    caja_var = tk.StringVar(value="Caja01")
    caja_combo = ttk.Combobox(filters, textvariable=caja_var,
                              values=["Caja01", "Caja02", "Caja03"],
                              width=10, state="readonly")
    caja_combo.grid(row=1, column=1, sticky="w")

    summary = tk.Frame(body)
    summary.pack(fill="x", pady=(8, 10))

    lbl_total = tk.Label(summary, text="Total: 0 CLP", font=("Segoe UI", 12, "bold"))
    lbl_total.pack(side="left")

    lbl_promo = tk.Label(summary, text="Promo: 0 CLP", font=("Segoe UI", 11))
    lbl_promo.pack(side="left", padx=18)

    lbl_count = tk.Label(summary, text="Ventas: 0", font=("Segoe UI", 11))
    lbl_count.pack(side="left", padx=18)

    cols = ("medio", "ventas", "total", "promo")
    tree = ttk.Treeview(body, columns=cols, show="headings")
    tree.pack(fill="both", expand=True)

    tree.heading("medio", text="Medio de pago")
    tree.heading("ventas", text="Ventas (#)")
    tree.heading("total", text="Total (CLP)")
    tree.heading("promo", text="Promo (CLP)")

    tree.column("medio", width=160, anchor="w")
    tree.column("ventas", width=100, anchor="center")
    tree.column("total", width=140, anchor="e")
    tree.column("promo", width=140, anchor="e")

    btns = tk.Frame(body)
    btns.pack(fill="x", pady=(10, 0))

    def load():
        fecha = date_var.get().strip()
        caja = caja_var.get().strip()

        try:
            datetime.strptime(fecha, "%Y-%m-%d")
        except Exception:
            messagebox.showerror("Error", "Fecha inválida. Formato: yyyy-mm-dd")
            return

        rows, overall = query_cierre(fecha, caja)

        tree.delete(*tree.get_children())
        for medio, n, total_sum, promo_sum in rows:
            tree.insert("", "end", values=(medio, n, money(total_sum), money(promo_sum)))

        n_all, total_all, promo_all = overall
        lbl_total.config(text=f"Total: {money(total_all)} CLP")
        lbl_promo.config(text=f"Promo: {money(promo_all)} CLP")
        lbl_count.config(text=f"Ventas: {n_all}")

        if n_all == 0:
            messagebox.showinfo("Info", "No hay ventas registradas para ese día/caja.")

    tk.Button(btns, text="Actualizar", padx=14, pady=8, command=load).pack(side="right")
    tk.Button(btns, text="Cerrar", padx=14, pady=8, command=win.destroy).pack(side="right", padx=10)

    win.after(100, load)
    root.mainloop()
    return win

if __name__ == "__main__":
    open_ventas_report()