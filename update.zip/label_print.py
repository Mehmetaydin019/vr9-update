# label_print.py
# VR9 - 45mm x 105mm label design (ReportLab)
# Usage:
#   from label_print import LabelRow, build_labels_pdf
#   build_labels_pdf(rows, "tickets/labels.pdf")

from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import List, Union, Optional

from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib import colors

from reportlab.graphics.barcode.eanbc import Ean13BarcodeWidget
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF


@dataclass
class LabelRow:
    barcode: str
    saco: str
    fecha: str            # "dd/mm/yyyy"
    descripcion: str
    talla: str
    precio: int


def _fmt_clp(n: int) -> str:
    try:
        n = int(n)
    except Exception:
        n = 0
    return f"{n:,}".replace(",", ".")


def _safe_ean13(code: str) -> str:
    # EAN13 widget needs 12 or 13 digits; if 13 includes checksum
    s = "".join(ch for ch in str(code) if ch.isdigit())
    if len(s) == 12:
        return s
    if len(s) >= 13:
        return s[:13]
    # fallback pad (not ideal, but avoids crash)
    return (s + "0" * 12)[:12]


def build_labels_pdf(
    rows: List[LabelRow],
    out_path: Union[str, Path],
    *,
    label_w_mm: float = 45.0,
    label_h_mm: float = 105.0,
    margin_mm: float = 2.0,
    gap_mm: float = 0.0,
    draw_border: bool = True,
) -> str:
    out_path = str(out_path)
    W = label_w_mm * mm
    H = label_h_mm * mm
    M = margin_mm * mm
    GAP = gap_mm * mm

    c = canvas.Canvas(out_path, pagesize=(W, H))

    for r in rows:
        _draw_one_label(c, r, W, H, M, draw_border=draw_border)
        c.showPage()

    c.save()
    return out_path


def _draw_one_label(c: canvas.Canvas, r: LabelRow, W: float, H: float, M: float, *, draw_border: bool):
    # ---- frame
    if draw_border:
        c.setStrokeColor(colors.black)
        c.setLineWidth(1)
        c.rect(M, M, W - 2 * M, H - 2 * M, stroke=1, fill=0)

    # ---- layout anchors
    x0 = M
    y0 = M
    innerW = W - 2 * M
    innerH = H - 2 * M

    # ---- header (left)
    # SACO big
    c.setFont("Helvetica-Bold", 14)
    c.drawString(x0 + 2, y0 + innerH - 18, (r.saco or "").strip()[:12])

    # date under saco
    c.setFont("Helvetica-Bold", 12)
    c.drawString(x0 + 2, y0 + innerH - 34, (r.fecha or "").strip()[:12])

    # ---- talla box (top-right)
    box_w = 22 * mm
    box_h = 14 * mm
    box_x = x0 + innerW - box_w - 2
    box_y = y0 + innerH - 40

    c.setFont("Helvetica", 11)
    c.drawRightString(x0 + innerW - 2, y0 + innerH - 22, "Talla:")

    c.setLineWidth(1)
    c.rect(box_x, box_y, box_w, box_h, stroke=1, fill=0)

    c.setFont("Helvetica-Bold", 16)
    talla_txt = (r.talla or "-").strip()
    c.drawCentredString(box_x + box_w / 2, box_y + box_h / 2 - 6, talla_txt[:6])

    # ---- separator line
    sep_y = y0 + innerH - 44
    c.setLineWidth(1)
    c.line(x0 + 1, sep_y, x0 + innerW - 1, sep_y)

    # ---- description line (one line like sample)
    c.setFont("Helvetica-Bold", 12)
    desc = (r.descripcion or "").strip()
    # keep it short for one line
    if len(desc) > 28:
        desc = desc[:28].rstrip()
    c.drawString(x0 + 2, sep_y - 16, desc)

    # ---- barcode (vertical)
    # We draw an EAN13 and rotate 90° so it becomes vertical.
    ean_code = _safe_ean13(r.barcode)

    bw = 28 * mm   # "length" when horizontal (will become vertical height)
    bh = 18 * mm   # "barHeight" when horizontal (will become width)

    bc = Ean13BarcodeWidget(ean_code)
    bc.barHeight = bh
    bc.barWidth = 0.33 * mm  # thickness
    bc.quiet = True

    # Put widget into drawing sized to desired width
    d = Drawing(bw, bh)
    d.add(bc)

    # where to place vertical barcode (left-middle like sample)
    # After rotation, width/height swap visually.
    # We'll rotate around an anchor point.
    bar_left = x0 + 6 * mm
    bar_bottom = y0 + 22 * mm  # leave room for big price at bottom

    c.saveState()
    # rotate 90 degrees around (bar_left, bar_bottom)
    c.translate(bar_left, bar_bottom)
    c.rotate(90)
    # after rotate, draw horizontally but it appears vertical
    renderPDF.draw(d, c, 0, 0)
    c.restoreState()

    # ---- price bottom center
    c.setFont("Helvetica-Bold", 28)
    c.drawCentredString(x0 + innerW / 2, y0 + 10 * mm, _fmt_clp(r.precio))