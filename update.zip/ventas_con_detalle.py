# ventas_con_detalle.py
# -*- coding: utf-8 -*-

from __future__ import annotations

from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal
from typing import Any, Dict, List, Optional

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QFrame,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QMessageBox,
    QSizePolicy,
)

# db.py içindeki get_conn kullanılacak
try:
    from db import connect as get_conn
except Exception:
    get_conn = None


# ============================================================
# Yardımcılar
# ============================================================

def _to_float(v: Any, default: float = 0.0) -> float:
    if v is None:
        return default
    try:
        if isinstance(v, Decimal):
            return float(v)
        return float(v)
    except Exception:
        return default


def _to_int(v: Any, default: int = 0) -> int:
    if v is None:
        return default
    try:
        return int(round(float(v)))
    except Exception:
        return default


def _fmt_int(v: Any) -> str:
    try:
        return f"{int(round(float(v))):,}".replace(",", ".")
    except Exception:
        return "0"


def _fmt_money(v: Any) -> str:
    try:
        return f"{int(round(float(v))):,}".replace(",", ".")
    except Exception:
        return "0"


def _safe_strip(v: Any) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _normalize_category(cat: str) -> str:
    c = (cat or "").strip().lower()

    # İstersen bunları kendi sistemine göre genişlet
    if c in ("ropa", "giyim", "gi̇yi̇m", "vestuario", "textil", "giyım"):
        return "Ropa"
    if c in ("calzado", "ayakkabı", "ayakkabi", "zapato", "zapatos"):
        return "Ayakkabı"
    if c in ("hogar", "ev tekstili", "ev tekstil", "home"):
        return "Hogar"
    if c in ("accesorio", "accesorios", "aksesuar", "accessory"):
        return "Aksesuar"
    if c in ("bolsa", "bolsas"):
        return "Bolsa"
    if c in ("ic giyim", "iç giyim", "içgiyim", "ropa interior", "underwear"):
        return "İç Giyim"

    return cat.strip().title() if cat else "Sin Categoría"


def _extract_hour(value: Any) -> int:
    """
    fecha alanı datetime/string olabilir.
    Saat bilgisini güvenli şekilde alır.
    """
    if value is None:
        return 0

    if isinstance(value, datetime):
        return value.hour

    s = str(value).strip()
    if not s:
        return 0

    patterns = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M",
    ]

    for p in patterns:
        try:
            return datetime.strptime(s, p).hour
        except Exception:
            pass

    # son çare: metinden saat parçalamaya çalış
    if " " in s:
        right = s.split(" ", 1)[1]
        if ":" in right:
            try:
                return int(right.split(":")[0])
            except Exception:
                return 0

    return 0


# ============================================================
# Ana widget
# ============================================================

class VentasConDetalleWidget(QWidget):
    """
    Report Manager içine gömülecek rapor widget'ı.
    Dışarıdan filtre verilecek.

    Kullanım:
        widget = VentasConDetalleWidget()
        widget.load_data(desde="2026-03-01", hasta="2026-03-31", sucursal_id=1)
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        self._last_desde = None
        self._last_hasta = None
        self._last_sucursal_id = None
        self._last_sucursal_nombre = None
        self._current_filters = {}

        self._build_ui()

    # --------------------------------------------------------
    # UI
    # --------------------------------------------------------
    def _build_ui(self):
        self.setObjectName("ventasConDetalleWidget")

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        self.lbl_title = QLabel("Ventas Con Detalle")
        f = QFont()
        f.setPointSize(14)
        f.setBold(True)
        self.lbl_title.setFont(f)
        root.addWidget(self.lbl_title)

        self.lbl_sucursal = QLabel("")
        self.lbl_sucursal.setStyleSheet("font-size: 16px; font-weight: bold; color: #111;")
        root.addWidget(self.lbl_sucursal)

        self.lbl_subtitle = QLabel("Seleccione fechas y sucursal desde el panel de filtros.")
        self.lbl_subtitle.setStyleSheet("color: #666;")
        root.addWidget(self.lbl_subtitle)

        # Ana içerik
        content = QHBoxLayout()
        content.setSpacing(10)
        root.addLayout(content, 1)

        # Sol panel
        left_frame = QFrame()
        left_frame.setFrameShape(QFrame.StyledPanel)
        left_layout = QVBoxLayout(left_frame)
        left_layout.setContentsMargins(8, 8, 8, 8)
        left_layout.setSpacing(6)

        left_title = QLabel("Detalle por código")
        left_title.setStyleSheet("font-weight: bold; font-size: 13px;")
        left_layout.addWidget(left_title)

        self.tbl_detalle = QTableWidget(0, 4)
        self.tbl_detalle.setHorizontalHeaderLabels([
            "Código",
            "Cantidad",
            "Precio Promedio",
            "Total",
        ])
        self.tbl_detalle.setAlternatingRowColors(True)
        self.tbl_detalle.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl_detalle.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl_detalle.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl_detalle.verticalHeader().setVisible(False)
        self.tbl_detalle.setWordWrap(False)
        self.tbl_detalle.setSortingEnabled(False)

        h = self.tbl_detalle.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.Interactive)
        h.setSectionResizeMode(1, QHeaderView.Interactive)
        h.setSectionResizeMode(2, QHeaderView.Interactive)
        h.setSectionResizeMode(3, QHeaderView.Interactive)

        self.tbl_detalle.setColumnWidth(0, 260)  # Código
        self.tbl_detalle.setColumnWidth(1, 90)   # Cantidad
        self.tbl_detalle.setColumnWidth(2, 120)  # Precio Promedio
        self.tbl_detalle.setColumnWidth(3, 140)  # Total

        left_layout.addWidget(self.tbl_detalle, 1)

        # Sağ panel
        right_frame = QFrame()
        right_frame.setFrameShape(QFrame.StyledPanel)
        right_layout = QVBoxLayout(right_frame)
        right_layout.setContentsMargins(8, 8, 8, 8)
        right_layout.setSpacing(10)

        # Saat özeti
        top_right_title = QLabel("Resumen por horario")
        top_right_title.setStyleSheet("font-weight: bold; font-size: 13px;")
        right_layout.addWidget(top_right_title)

        self.tbl_horario = QTableWidget(0, 3)
        self.tbl_horario.setHorizontalHeaderLabels([
            "Horario",
            "Cantidad",
            "Total",
        ])
        self.tbl_horario.setAlternatingRowColors(True)
        self.tbl_horario.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl_horario.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl_horario.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl_horario.verticalHeader().setVisible(False)

        hh = self.tbl_horario.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Interactive)
        hh.setSectionResizeMode(1, QHeaderView.Interactive)
        hh.setSectionResizeMode(2, QHeaderView.Interactive)

        self.tbl_horario.setColumnWidth(0, 120)  # Horario
        self.tbl_horario.setColumnWidth(1, 120)   # Cantidad
        self.tbl_horario.setColumnWidth(2, 120)  # Total

        self.tbl_horario.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        right_layout.addWidget(self.tbl_horario)

        # Kategori özeti
        bottom_right_title = QLabel("Resumen por categoría")
        bottom_right_title.setStyleSheet("font-weight: bold; font-size: 13px;")
        right_layout.addWidget(bottom_right_title)

        self.tbl_categoria = QTableWidget(0, 4)
        self.tbl_categoria.setHorizontalHeaderLabels([
            "Categoría",
            "Cantidad",
            "Precio Promedio",
            "Total",
        ])
        self.tbl_categoria.setAlternatingRowColors(True)
        self.tbl_categoria.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl_categoria.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl_categoria.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl_categoria.verticalHeader().setVisible(False)

        hc = self.tbl_categoria.horizontalHeader()
        hc.setSectionResizeMode(0, QHeaderView.Interactive)
        hc.setSectionResizeMode(1, QHeaderView.Interactive)
        hc.setSectionResizeMode(2, QHeaderView.Interactive)
        hc.setSectionResizeMode(3, QHeaderView.Interactive)

        self.tbl_categoria.setColumnWidth(0, 120)  # Categoría
        self.tbl_categoria.setColumnWidth(1, 90)   # Cantidad
        self.tbl_categoria.setColumnWidth(2, 120)  # Precio Promedio
        self.tbl_categoria.setColumnWidth(3, 130)  # Total

        right_layout.addWidget(self.tbl_categoria, 1)

        # Oran
        content.addWidget(left_frame, 3)
        content.addWidget(right_frame, 2)

    # --------------------------------------------------------
    # Dışarıdan çağrılacak ana fonksiyon
    # --------------------------------------------------------
    def load_data(
        self,
        desde: Any,
        hasta: Any,
        sucursal_id: Optional[Any] = None,
        sucursal_nombre: Optional[str] = None,
    ):
        """
        Report Manager burayı çağıracak.

        desde / hasta:
            - "YYYY-MM-DD"
            - datetime.date
            - datetime.datetime

        sucursal_id:
            - numeric veya str olabilir

        sucursal_nombre:
            - sucursal adı
        """
        self._last_desde = desde
        self._last_hasta = hasta
        self._last_sucursal_id = sucursal_id
        self._last_sucursal_nombre = sucursal_nombre

        try:
            rows = self._fetch_rows(
                desde=desde,
                hasta=hasta,
                sucursal_id=sucursal_id,
                sucursal_nombre=sucursal_nombre,
            )
            self._render_all(rows, desde, hasta, sucursal_id, sucursal_nombre)

        except Exception as e:
            self._clear_tables()
            QMessageBox.critical(
                self,
                "Ventas Con Detalle",
                f"Rapor yüklenirken hata oluştu:\n\n{e}"
            )

    def refresh(self):
        """
        Aynı filtrelerle tekrar yüklemek için.
        """
        self.load_data(
            desde=self._last_desde,
            hasta=self._last_hasta,
            sucursal_id=self._last_sucursal_id,
            sucursal_nombre=self._last_sucursal_nombre,
        )

    # --------------------------------------------------------
    # DB
    # --------------------------------------------------------
    def _fetch_rows(
        self,
        desde: Any,
        hasta: Any,
        sucursal_id: Optional[Any] = None,
        sucursal_nombre: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        if get_conn is None:
            raise RuntimeError("db.py içinden get_conn import edilemedi.")

        desde_str = self._date_to_str(desde)
        hasta_str = self._date_to_str(hasta)

        con = get_conn()
        cur = None

        try:
            cur = con.cursor()

            # ----------------------------------------------------------------
            # BURASI en kritik yer.
            # Eğer tablo/alan isimlerin farklıysa sadece burayı düzeltmen yeterli.
            #
            # Beklenen alanlar:
            #   ventas.id
            #   ventas.fecha
            #   ventas.sucursal  (veya sucursal adı benzeri alan)
            #   ventas.sucursal_id (varsa)
            #
            #   venta_detalle.venta_id
            #   venta_detalle.codigo
            #   venta_detalle.descripcion / producto
            #   venta_detalle.categoria
            #   venta_detalle.cantidad
            #   venta_detalle.precio_unitario
            #   venta_detalle.total
            # ----------------------------------------------------------------

            sql = """
                SELECT
                    v.id AS venta_id,
                    v.fecha AS fecha,
                    COALESCE(v.sucursal, '') AS sucursal,

                    COALESCE(vi.codigo, '') AS codigo,
                    COALESCE(qc.descripcion, vi.saco, vi.producto, '') AS descripcion,
                    COALESCE(vi.categoria, '') AS categoria,

                    COALESCE(vi.cantidad, 0) AS cantidad,
                    COALESCE(vi.precio, 0) AS precio_unitario,
                    COALESCE(vi.valor, 0) AS total_linea

                FROM ventas v
                INNER JOIN venta_items vi ON vi.venta_id = v.id
                LEFT JOIN quick_codes qc ON qc.codigo = vi.codigo
                WHERE DATE(v.fecha) BETWEEN %s AND %s
            """

            params: List[Any] = [desde_str, hasta_str]

            if _safe_strip(sucursal_id):
                sql += " AND CAST(v.sucursal_id AS TEXT) = %s "
                params.append(str(sucursal_id))
            elif _safe_strip(sucursal_nombre):
                sql += " AND COALESCE(v.sucursal, '') = %s "
                params.append(str(sucursal_nombre))

            sql += " ORDER BY v.fecha ASC, vi.codigo ASC, vi.producto ASC "

            cur.execute(sql, params)
            fetched = cur.fetchall()

            cols = [desc[0] for desc in cur.description] if cur.description else []

            rows: List[Dict[str, Any]] = []
            for row in fetched:
                if isinstance(row, dict):
                    rows.append(row)
                else:
                    rows.append(dict(zip(cols, row)))

            return rows

        finally:
            try:
                if cur:
                    cur.close()
            except Exception:
                pass
            try:
                con.close()
            except Exception:
                pass

    # --------------------------------------------------------
    # Render
    # --------------------------------------------------------
    def _render_all(
        self,
        rows: List[Dict[str, Any]],
        desde: Any,
        hasta: Any,
        sucursal_id: Optional[Any],
        sucursal_nombre: Optional[str],
    ):
        self._clear_tables()

        desde_txt = self._date_to_display(desde)
        hasta_txt = self._date_to_display(hasta)
        suc_txt = _safe_strip(sucursal_nombre) or _safe_strip(sucursal_id) or "Todas"
        self.lbl_sucursal.setText(f"📍 SUCURSAL: {suc_txt}")

        self.lbl_subtitle.setText(
            f"Periodo: {desde_txt} - {hasta_txt}    |    Sucursal: {suc_txt}"
        )

        detalle_data = self._build_detalle_summary(rows)
        horario_data = self._build_horario_summary(rows)
        categoria_data = self._build_categoria_summary(rows)

        self._fill_detalle_table(detalle_data)
        self._fill_horario_table(horario_data)
        self._fill_categoria_table(categoria_data)

    def _clear_tables(self):
        self.tbl_detalle.setRowCount(0)
        self.tbl_horario.setRowCount(0)
        self.tbl_categoria.setRowCount(0)

    # --------------------------------------------------------
    # Summary builders
    # --------------------------------------------------------
    def _build_detalle_summary(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        grouped: Dict[str, Dict[str, float]] = {}

        for r in rows:
            descripcion = _safe_strip(r.get("descripcion"))
            codigo = _safe_strip(r.get("codigo"))
            categoria = _safe_strip(r.get("categoria"))

            # Sadece codigo göster
            if descripcion:
                key = descripcion
            elif codigo:
                key = codigo
            elif categoria:
                 key = categoria.upper()
            else:
                 key = "SIN CODIGO"

            qty = _to_float(r.get("cantidad"))
            unit = _to_float(r.get("precio_unitario"))
            total = _to_float(r.get("total_linea"))

            if total == 0 and qty > 0 and unit > 0:
                total = qty * unit

            if key not in grouped:
                grouped[key] = {
                    "label": key,
                    "qty": 0.0,
                    "total": 0.0,
                }

            grouped[key]["qty"] += qty
            grouped[key]["total"] += total

        result: List[Dict[str, Any]] = []
        grand_qty = 0.0
        grand_total = 0.0

        for _, item in grouped.items():
            qty = item["qty"]
            total = item["total"]
            avg = (total / qty) if qty else 0.0

            result.append({
                "label": item["label"],
                "qty": qty,
                "avg": avg,
                "total": total,
            })

            grand_qty += qty
            grand_total += total

        result.sort(key=lambda x: (-x["qty"], x["label"]))

        grand_avg = (grand_total / grand_qty) if grand_qty else 0.0
        result.append({
            "label": "TOTAL GENERAL",
            "qty": grand_qty,
            "avg": grand_avg,
            "total": grand_total,
            "_is_total": True,
        })

        return result

    def _build_horario_summary(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        # Senin istediğin aralıklar:
        # 08:00 - 13:00
        # 13:01 - 17:00
        # 17:01 - cierre
        buckets = [
            {"label": "08:00 - 13:00", "qty": 0.0, "total": 0.0},
            {"label": "13:01 - 17:00", "qty": 0.0, "total": 0.0},
            {"label": "17:01 - Cierre", "qty": 0.0, "total": 0.0},
        ]

        for r in rows:
            hour = _extract_hour(r.get("fecha"))
            qty = _to_float(r.get("cantidad"))
            unit = _to_float(r.get("precio_unitario"))
            total = _to_float(r.get("total_linea"))

            if total == 0 and qty > 0 and unit > 0:
                total = qty * unit

            if 8 <= hour <= 13:
                buckets[0]["qty"] += qty
                buckets[0]["total"] += total
            elif 14 <= hour <= 17:
                buckets[1]["qty"] += qty
                buckets[1]["total"] += total
            else:
                buckets[2]["qty"] += qty
                buckets[2]["total"] += total

        grand_qty = sum(x["qty"] for x in buckets)
        grand_total = sum(x["total"] for x in buckets)

        result = list(buckets)
        result.append({
            "label": "TOTAL GENERAL",
            "qty": grand_qty,
            "total": grand_total,
            "_is_total": True,
        })
        return result

    def _build_categoria_summary(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        grouped: Dict[str, Dict[str, float]] = {}

        for r in rows:
            categoria = _normalize_category(_safe_strip(r.get("categoria")))

            qty = _to_float(r.get("cantidad"))
            unit = _to_float(r.get("precio_unitario"))
            total = _to_float(r.get("total_linea"))

            if total == 0 and qty > 0 and unit > 0:
                total = qty * unit

            if categoria not in grouped:
                grouped[categoria] = {
                    "categoria": categoria,
                    "qty": 0.0,
                    "total": 0.0,
                }

            grouped[categoria]["qty"] += qty
            grouped[categoria]["total"] += total

        result: List[Dict[str, Any]] = []
        grand_qty = 0.0
        grand_total = 0.0

        for _, item in grouped.items():
            qty = item["qty"]
            total = item["total"]
            avg = (total / qty) if qty else 0.0

            result.append({
                "categoria": item["categoria"],
                "qty": qty,
                "avg": avg,
                "total": total,
            })

            grand_qty += qty
            grand_total += total

        result.sort(key=lambda x: (-x["qty"], x["categoria"]))

        grand_avg = (grand_total / grand_qty) if grand_qty else 0.0
        result.append({
            "categoria": "TOTAL GENERAL",
            "qty": grand_qty,
            "avg": grand_avg,
            "total": grand_total,
            "_is_total": True,
        })

        return result

    # --------------------------------------------------------
    # Table fillers
    # --------------------------------------------------------
    def _fill_detalle_table(self, data: List[Dict[str, Any]]):
        self.tbl_detalle.setRowCount(len(data))

        for row_idx, row in enumerate(data):
            is_total = bool(row.get("_is_total"))

            self._set_item(
                self.tbl_detalle, row_idx, 0,
                row.get("label", ""),
                align=Qt.AlignLeft | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_detalle, row_idx, 1,
                _fmt_int(row.get("qty", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_detalle, row_idx, 2,
                _fmt_money(row.get("avg", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_detalle, row_idx, 3,
                _fmt_money(row.get("total", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )

    def _fill_horario_table(self, data: List[Dict[str, Any]]):
        self.tbl_horario.setRowCount(len(data))

        for row_idx, row in enumerate(data):
            is_total = bool(row.get("_is_total"))

            self._set_item(
                self.tbl_horario, row_idx, 0,
                row.get("label", ""),
                align=Qt.AlignLeft | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_horario, row_idx, 1,
                _fmt_int(row.get("qty", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_horario, row_idx, 2,
                _fmt_money(row.get("total", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )

    def _fill_categoria_table(self, data: List[Dict[str, Any]]):
        self.tbl_categoria.setRowCount(len(data))

        for row_idx, row in enumerate(data):
            is_total = bool(row.get("_is_total"))

            self._set_item(
                self.tbl_categoria, row_idx, 0,
                row.get("categoria", ""),
                align=Qt.AlignLeft | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_categoria, row_idx, 1,
                _fmt_int(row.get("qty", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_categoria, row_idx, 2,
                _fmt_money(row.get("avg", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )
            self._set_item(
                self.tbl_categoria, row_idx, 3,
                _fmt_money(row.get("total", 0)),
                align=Qt.AlignRight | Qt.AlignVCenter,
                bold=is_total
            )

    def _set_item(
        self,
        table: QTableWidget,
        row: int,
        col: int,
        text: str,
        align: Qt.AlignmentFlag = Qt.AlignLeft | Qt.AlignVCenter,
        bold: bool = False,
    ):
        item = QTableWidgetItem("" if text is None else str(text))
        item.setTextAlignment(int(align))

        if bold:
            font = item.font()
            font.setBold(True)
            item.setFont(font)

        table.setItem(row, col, item)

    # --------------------------------------------------------
    # Date helpers
    # --------------------------------------------------------
    def _date_to_str(self, value: Any) -> str:
        if isinstance(value, datetime):
            return value.strftime("%Y-%m-%d")
        if isinstance(value, date):
            return value.strftime("%Y-%m-%d")

        s = str(value).strip()
        if not s:
            return ""

        # dd/mm/yyyy gelirse çevir
        if "/" in s:
            try:
                return datetime.strptime(s, "%d/%m/%Y").strftime("%Y-%m-%d")
            except Exception:
                pass

        return s

    def _date_to_display(self, value: Any) -> str:
        if isinstance(value, datetime):
            return value.strftime("%d/%m/%Y")
        if isinstance(value, date):
            return value.strftime("%d/%m/%Y")

        s = str(value).strip()
        if not s:
            return ""

        if "-" in s:
            try:
                return datetime.strptime(s[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
            except Exception:
                pass

        return s


# ============================================================
# Tek başına test etmek istersen
# ============================================================
if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication

    app = QApplication(sys.argv)

    w = VentasConDetalleWidget()
    w.resize(1300, 760)
    w.show()

    # test
    w.load_data(
        desde="2026-03-01",
        hasta="2026-03-31",
        sucursal_id=None,
        sucursal_nombre=None,
    )

    sys.exit(app.exec())