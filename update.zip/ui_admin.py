# ui_admin.py
from __future__ import annotations
from typing import Optional, List, Dict, Any

# Qt fallback
QT_LIB = None
try:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QListWidget, QListWidgetItem, QLineEdit, QFrame, QMessageBox
    )
    QT6 = True
    QT_LIB = "pyside6"
except Exception:
    try:
        from PyQt6.QtCore import Qt
        from PyQt6.QtGui import QFont
        from PyQt6.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
            QListWidget, QListWidgetItem, QLineEdit, QFrame, QMessageBox
        )
        QT6 = True
        QT_LIB = "pyqt6"
    except Exception:
        from PyQt5.QtCore import Qt
        from PyQt5.QtGui import QFont
        from PyQt5.QtWidgets import (
            QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
            QListWidget, QListWidgetItem, QLineEdit, QFrame, QMessageBox
        )
        QT6 = False
        QT_LIB = "pyqt5"

def _norm(s: str) -> str:
    return (s or "").strip()

def _qt_user_role():
    return Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole


class CashRegisterDialog(QDialog):
    """
    Profesyonel kasa seçme ekranı.
    returns: selected kasa dict (code/name/id...)
    """
    def __init__(self, cajas: List[Dict[str, Any]], parent=None):
        super().__init__(parent)
        self.setWindowTitle("Seleccionar Caja")
        self.setModal(True)
        self.resize(520, 620)

        self._all = cajas[:]  # cache
        self.selected: Optional[Dict[str, Any]] = None

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(12)

        title = QLabel("Bienvenido 👋")
        title.setFont(QFont("Segoe UI", 18, 800))
        root.addWidget(title)

        subtitle = QLabel("Selecciona la caja para iniciar. Esto ayuda a registrar ventas y arqueos correctamente.")
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color:#475569; font-weight:700;")
        root.addWidget(subtitle)

        card = QFrame()
        card.setStyleSheet("""
            QFrame{
                background:#ffffff;
                border:1px solid #e5e7eb;
                border-radius:16px;
            }
        """)
        card_l = QVBoxLayout(card)
        card_l.setContentsMargins(14, 14, 14, 14)
        card_l.setSpacing(10)
        root.addWidget(card, 1)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Buscar caja... (ej: CAJA 1 / Providencia / Barros Arana)")
        self.search.textChanged.connect(self._filter)
        self.search.setStyleSheet("""
            QLineEdit{
                padding:10px 12px; border-radius:12px;
                border:1px solid #cbd5e1; font-size:14px;
            }
        """)
        card_l.addWidget(self.search)

        self.list = QListWidget()
        self.list.setStyleSheet("""
            QListWidget{ border:0px; background:transparent; }
            QListWidget::item{
                padding:14px;
                margin:6px 0px;
                border:1px solid #e5e7eb;
                border-radius:14px;
                background:#f8fafc;
                font-size:16px;
                font-weight:800;
            }
            QListWidget::item:selected{
                background:#dbeafe;
                border:2px solid #2563eb;
            }
        """)
        self.list.itemDoubleClicked.connect(lambda _it: self._accept())
        card_l.addWidget(self.list, 1)

        # buttons
        btnrow = QHBoxLayout()
        btnrow.setSpacing(10)

        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.clicked.connect(self.reject)

        self.btn_ok = QPushButton("Continuar ➜")
        self.btn_ok.setStyleSheet("""
            QPushButton{
                background:#2563eb; color:white;
                border:1px solid #2563eb;
                padding:10px 14px; border-radius:12px;
                font-size:16px; font-weight:900;
            }
            QPushButton:hover{ background:#1d4ed8; }
        """)
        self.btn_ok.clicked.connect(self._accept)

        btnrow.addWidget(self.btn_cancel)
        btnrow.addStretch(1)
        btnrow.addWidget(self.btn_ok)
        root.addLayout(btnrow)

        self._render(self._all)

    def _render(self, items: List[Dict[str, Any]]):
        self.list.clear()
        for d in items:
            # gösterim metni
            code = str(d.get("code") or d.get("codigo") or d.get("id") or "").strip()
            name = str(d.get("name") or d.get("nombre") or "").strip()
            suc = str(d.get("sucursal") or "").strip()
            txt = " · ".join([x for x in [name, suc, code] if x])
            it = QListWidgetItem(txt if txt else code)
            it.setData(_qt_user_role(), d)
            self.list.addItem(it)

    def _filter(self):
        q = _norm(self.search.text()).lower()
        if not q:
            self._render(self._all)
            return
        filtered = []
        for d in self._all:
            blob = " ".join([str(v) for v in d.values()]).lower()
            if q in blob:
                filtered.append(d)
        self._render(filtered)

    def _accept(self):
        it = self.list.currentItem()
        if not it:
            QMessageBox.warning(self, "Atención", "Debes seleccionar una caja.")
            return
        self.selected = it.data(_qt_user_role())
        self.accept()