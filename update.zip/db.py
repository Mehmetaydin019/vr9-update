# db.py (VR9 - SINGLE DB + FIX ADMIN DUPLICATES + SAFE MIGRATIONS)
from __future__ import annotations

import os
import sys
import hashlib
import re
import unicodedata
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from psycopg2.pool import SimpleConnectionPool

# -----------------------------
# DATABASE MODE
# -----------------------------
CONFIG_PATH = Path(__file__).resolve().parent / "config.json"

DEFAULT_PG_CONFIG = {
    "host": "192.168.0.47",
    "port": 5432,
    "dbname": "vr9_db",
    "user": "postgres",
    "password": "2846"
}

def load_pg_config():
    if CONFIG_PATH.exists():
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            pg = data.get("pg_config", {})
            return {
                "host": pg.get("host", DEFAULT_PG_CONFIG["host"]),
                "port": int(pg.get("port", DEFAULT_PG_CONFIG["port"])),
                "dbname": pg.get("dbname", DEFAULT_PG_CONFIG["dbname"]),
                "user": pg.get("user", DEFAULT_PG_CONFIG["user"]),
                "password": pg.get("password", DEFAULT_PG_CONFIG["password"]),
            }
        except Exception as e:
            print("CONFIG LOAD ERROR:", e)

    return DEFAULT_PG_CONFIG.copy()

def save_pg_config(cfg: dict):
    data = {"pg_config": cfg}
    CONFIG_PATH.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

PG_CONFIG = load_pg_config()

class PGCompatConnection:
    def __init__(self, conn):
        self._conn = conn

    def execute(self, query, params=None):
        query = query.replace("?", "%s")

        cur = self._conn.cursor(cursor_factory=RealDictCursor)
        if params is None:
            cur.execute(query)
        else:
            cur.execute(query, params)
        return cur

    def executemany(self, query, seq_of_params):
        query = query.replace("?", "%s")

        cur = self._conn.cursor(cursor_factory=RealDictCursor)
        cur.executemany(query, seq_of_params)
        return cur

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def cursor(self, *args, **kwargs):
        return self._conn.cursor(*args, **kwargs)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type:
            self.rollback()
        else:
            self.commit()
        self.close()

    def close(self):
        try:
            global _pg_pool
            if _pg_pool:
                _pg_pool.putconn(self._conn)
            else:
                self._conn.close()
        except Exception:
            pass

import psycopg2
from psycopg2.extras import RealDictCursor

def _project_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _appdata_dir() -> Path:
    base = Path(os.environ.get("APPDATA", str(Path.home())))
    d = base / "VR9"
    d.mkdir(parents=True, exist_ok=True)
    return d

def _resolve_db_path() -> Path:
    env = (os.environ.get("VR9_DB_PATH") or "").strip()
    if env:
        p = Path(env).expanduser().resolve()
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    proj = _project_dir() / "etiket_pos.db"
    if proj.exists():
        return proj

    return _appdata_dir() / "etiket_pos.db"

DB_PATH: Path = _resolve_db_path()

_pg_pool = None

def get_pg_conn():
    global _pg_pool
    if _pg_pool is None:
        _pg_pool = SimpleConnectionPool(
            1, 10,
            host=PG_CONFIG["host"],
            port=PG_CONFIG["port"],
            dbname=PG_CONFIG["dbname"],
            user=PG_CONFIG["user"],
            password=PG_CONFIG["password"],
            connect_timeout=3
        )
    return _pg_pool.getconn()

def connect(db_path: Path = DB_PATH):
    raw_conn = get_pg_conn()
    return PGCompatConnection(raw_conn)
   
def table_exists(con, table_name: str) -> bool:
    cur = con.cursor()
    cur.execute("""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_name = %s
        );
    """, (table_name,))
    return cur.fetchone()[0]

def _columns(con, table_name: str):
    cur = con.cursor()
    cur.execute("""
        SELECT column_name 
        FROM information_schema.columns
        WHERE table_name = %s
    """, (table_name,))
    return [r[0] for r in cur.fetchall()]

def _hash_password(p: str) -> str:
    p = (p or "").strip()
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

# -----------------------------
# Migrations / Schema
# -----------------------------
def init_db() -> None:
    with connect() as con:
        _migrate_sacos(con)
        _migrate_barcode_sequence(con)
        _migrate_usuarios(con)
        _migrate_sucursales(con)
        _migrate_document_sequences(con)
        _migrate_stock_tables(con)

        if table_exists(con, "ventas"):
            cols = _columns(con, "ventas")
            if "sucursal" not in cols:
                con.execute("ALTER TABLE ventas ADD COLUMN sucursal TEXT DEFAULT ''")
            if "usuario" not in cols:
                con.execute("ALTER TABLE ventas ADD COLUMN usuario TEXT DEFAULT ''")
            con.commit()

        con.execute("""
            CREATE TABLE IF NOT EXISTS generos (
                id SERIAL PRIMARY KEY,
                nombre TEXT NOT NULL UNIQUE,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS categorias (
                id SERIAL PRIMARY KEY,
                nombre TEXT NOT NULL UNIQUE,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS productos (
                id SERIAL PRIMARY KEY,
                categoria_id INTEGER,
                nombre TEXT NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(categoria_id, nombre),
                FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS tallas (
                id SERIAL PRIMARY KEY,
                nombre TEXT NOT NULL UNIQUE,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS items (
                barcode TEXT PRIMARY KEY,
                producto TEXT NOT NULL,
                descripcion TEXT,
                categoria TEXT,
                genero TEXT,
                saco TEXT,
                price INTEGER NOT NULL,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS labels (
                id SERIAL PRIMARY KEY,
                barcode TEXT NOT NULL UNIQUE,
                saco_codigo TEXT,
                saco_kg INTEGER DEFAULT 0,
                genero TEXT,
                categoria TEXT,
                producto TEXT,
                talla TEXT,
                precio INTEGER NOT NULL,
                kg REAL DEFAULT 0,
                descripcion TEXT,
                prefix TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
         
        con.execute("""
            CREATE TABLE IF NOT EXISTS quick_codes (
                codigo TEXT PRIMARY KEY,
                descripcion TEXT NOT NULL,
                producto_base TEXT DEFAULT '',
                categoria TEXT DEFAULT '',
                genero TEXT DEFAULT 'General',
                precio INTEGER NOT NULL DEFAULT 0,
                kg REAL DEFAULT 0,
                activo INTEGER NOT NULL DEFAULT 1,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS boleta_config (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                titulo_negocio TEXT DEFAULT 'GALATA TREND',
                razon_social TEXT DEFAULT 'Importadora Galata SpA',
                rut TEXT DEFAULT '78.325.343-7',
                direccion TEXT DEFAULT 'Arturo Prat 414, Curicó',
                giro TEXT DEFAULT '',
                telefono TEXT DEFAULT '',
                email TEXT DEFAULT '',
                mensaje_cambio_1 TEXT DEFAULT 'NO SE ACEPTAN CAMBIO',
                mensaje_cambio_2 TEXT DEFAULT 'NI DEVOLUCIONES',
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS boleta_layout_config (
                id INTEGER PRIMARY KEY CHECK (id = 1),

                header_align TEXT DEFAULT 'center',
                header_width INTEGER DEFAULT 2,
                header_height INTEGER DEFAULT 2,

                empresa_width INTEGER DEFAULT 1,
                empresa_height INTEGER DEFAULT 1,

                rut_width INTEGER DEFAULT 1,
                rut_height INTEGER DEFAULT 1,

                direccion_width INTEGER DEFAULT 1,
                direccion_height INTEGER DEFAULT 1,

                item_spacing INTEGER DEFAULT 1,

                footer_align TEXT DEFAULT 'center',
                footer_width INTEGER DEFAULT 1,
                footer_height INTEGER DEFAULT 1,

                footer_msg1 TEXT DEFAULT 'NO SE ACEPTAN CAMBIO',
                footer_msg2 TEXT DEFAULT 'NI DEVOLUCIONES'
        )
        """)

        con.execute("""
        INSERT INTO boleta_layout_config (id)
        VALUES (1)
        ON CONFLICT DO NOTHING
        """)

        con.execute("""
        INSERT INTO boleta_config (
            id, titulo_negocio, razon_social, rut, direccion,
            giro, telefono, email, mensaje_cambio_1, mensaje_cambio_2
        )
        VALUES (
            1,
            'GALATA TREND',
            'Importadora Galata SpA',
            '78.325.343-7',
            'Arturo Prat 414, Curicó',
            '',
            '',
            '',
            'NO SE ACEPTAN CAMBIO',
            'NI DEVOLUCIONES'
        )
        ON CONFLICT (id) DO NOTHING
        """)

        con.executemany("""
            INSERT INTO quick_codes(
                codigo, descripcion, producto_base, categoria, genero, precio, kg, activo
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (codigo) DO NOTHING
        """,[
            ("11", "Bolsa Chica", "Bolsa", "Accesorios", "General", 100, 0, 1),
            ("22", "Bolsa Mediana", "Bolsa", "Accesorios", "General", 200, 0, 1),
            ("33", "Bolsa Grande", "Bolsa", "Accesorios", "General", 300, 0, 1),

            ("101", "S.Hand Ropa", "Ropa", "Ropa", "General", 0, 0, 1),
            ("102", "S.Hand Calzado", "Calzado", "Calzado", "General", 0, 0, 1),
            ("103", "Retorno Hogar", "Hogar", "Hogar", "General", 0, 0, 1),
            ("104", "S.Hand Accesorio", "Accesorio", "Accesorios", "General", 0, 0, 1),
        ])

        cols_labels = _columns(con, "labels")

        if "production_no" not in cols_labels:
            con.execute("ALTER TABLE labels ADD COLUMN production_no TEXT DEFAULT ''")

        con.execute("""
            CREATE TABLE IF NOT EXISTS prints (
                id SERIAL PRIMARY KEY,
                barcode TEXT NOT NULL,
                printed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.commit()

        con.execute("""
            CREATE TABLE IF NOT EXISTS clientes (
                id SERIAL PRIMARY KEY,
                rut TEXT NOT NULL UNIQUE,
                razon_social TEXT NOT NULL,
                giro TEXT DEFAULT '',
                direccion TEXT DEFAULT '',
                region TEXT DEFAULT '',
                comuna TEXT DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.execute("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS apellido TEXT DEFAULT ''")
        con.execute("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS giro TEXT DEFAULT ''")
        con.execute("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS direccion TEXT DEFAULT ''")
        con.execute("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS region TEXT DEFAULT ''")
        con.execute("ALTER TABLE clientes ADD COLUMN IF NOT EXISTS comuna TEXT DEFAULT ''")

        con.execute("""
            CREATE TABLE IF NOT EXISTS ofertas (
                id SERIAL PRIMARY KEY,
                fecha_desde TEXT NOT NULL,
                fecha_hasta TEXT NOT NULL,
                saco TEXT DEFAULT 'TODOS',
                categoria TEXT DEFAULT 'TODOS',
                producto TEXT DEFAULT 'TODOS',
                descuento_pct INTEGER NOT NULL,
                activo INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        con.execute("ALTER TABLE ofertas ADD COLUMN IF NOT EXISTS categoria TEXT DEFAULT 'TODOS'")
        con.execute("ALTER TABLE ofertas ADD COLUMN IF NOT EXISTS tipo_oferta TEXT DEFAULT 'PCT'")
        con.execute("ALTER TABLE ofertas ADD COLUMN IF NOT EXISTS valor_oferta TEXT DEFAULT ''")
 
        con.commit()

        # --- SAFE MIGRATION: labels.created_at ekle ---
        try:
            cur = con.execute(
                """
                SELECT column_name
                FROM information_schema.columns
                WHERE table_schema = 'public' AND table_name = ?
                """,
                ("labels",)
            )
            rows = cur.fetchall()

            cols = []
            for r in rows:
                if isinstance(r, dict):
                    cols.append(r["column_name"])
                else:
                    cols.append(r[0])

            if "created_at" not in cols:
                con.execute("ALTER TABLE labels ADD COLUMN created_at TEXT")
                print("labels.created_at kolonu eklendi")

        except Exception as e:
            print("migration error:", e)

        # HOJA DE ENTRADA TABLOSU
        con.execute("""
        CREATE TABLE IF NOT EXISTS hoja_entradas (
            id SERIAL PRIMARY KEY,
            numero TEXT UNIQUE,
            fecha TEXT,
            sucursal_destino TEXT,
            sucursal_origen TEXT,
            accion TEXT,
            usuario TEXT,
            estado TEXT,
            saco_codigo TEXT,
            production_no TEXT,
            nota TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
        """)  

def ensure_admin() -> None:
    """
    - NULL/boş usuario yüzünden ADMIN duplicate oluyordu.
    - Bu fonksiyon:
      1) usuarios tablosu yoksa oluşturur
      2) Admin/System satırlarında usuario boşsa ADMIN yapar
      3) ADMIN fazlalarını siler (tek kayıt bırakır)
      4) ADMIN’i garanti eder (clave=admin)
    """
    init_db()
    admin_hash = _hash_password("admin")

    with connect() as con:
        # 1) tablo garanti
        con.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id SERIAL PRIMARY KEY,
                usuario TEXT,
                nombre TEXT NOT NULL,
                apellido TEXT NOT NULL DEFAULT '',
                clave_hash TEXT,
                role TEXT NOT NULL DEFAULT 'user',
                is_active INTEGER NOT NULL DEFAULT 1,

                can_pos INTEGER NOT NULL DEFAULT 1,
                can_stock INTEGER NOT NULL DEFAULT 1,
                can_production INTEGER NOT NULL DEFAULT 1,
                can_informes INTEGER NOT NULL DEFAULT 0,
                can_database INTEGER NOT NULL DEFAULT 0,
                can_ajustes INTEGER NOT NULL DEFAULT 0,
                sucursal_id INTEGER,

                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.execute("ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS apellido TEXT DEFAULT ''")
   
        cols_usuarios = _columns(con, "usuarios")
        if "apellido" not in cols_usuarios:
            con.execute("ALTER TABLE usuarios ADD COLUMN apellido TEXT DEFAULT ''")

        # 2) Admin/System satırlarında usuario boşsa ADMIN yap
        con.execute("""
            UPDATE usuarios
            SET usuario='ADMIN'
            WHERE (usuario IS NULL OR TRIM(usuario)='')
              AND UPPER(COALESCE(nombre,''))='ADMIN'
              AND UPPER(COALESCE(apellido,'')) IN ('SYSTEM','SYS')
        """)

        # 3) ADMIN fazlalarını sil (en küçük id kalsın)
        rows = con.execute("""
            SELECT id
            FROM usuarios
            WHERE UPPER(COALESCE(usuario,''))='ADMIN'
            ORDER BY id ASC
        """).fetchall()

        if len(rows) > 1:
            keep_id = int(rows[0]["id"])
            del_ids = [int(r["id"]) for r in rows[1:]]

            con.executemany("DELETE FROM usuarios WHERE id=%s", [(i,) for i in del_ids])


        # 4) ADMIN yoksa ekle
        con.execute("""
            INSERT INTO usuarios(
                usuario, nombre, apellido, clave_hash, role, is_active,
                can_pos, can_stock, can_production, can_informes, can_database, can_ajustes
            )
            SELECT 'ADMIN','Admin','System', %s, 'admin', 1, 1,1,1,1,1,1
            WHERE NOT EXISTS (
                SELECT 1 FROM usuarios WHERE UPPER(COALESCE(usuario,''))='ADMIN'
            )
        """, (admin_hash,))

        # 5) ADMIN’i düzelt
        con.execute("""
            UPDATE usuarios
            SET clave_hash = COALESCE(NULLIF(TRIM(COALESCE(clave_hash,'')), ''), %s),
                role='admin',
                is_active=1,
                can_pos=1,
                can_stock=1,
                can_production=1,
                can_informes=1,
                can_database=1,
                can_ajustes=1,
                updated_at=CURRENT_TIMESTAMP
            WHERE UPPER(COALESCE(usuario,''))='ADMIN'
        """, (admin_hash,))

        con.commit()

def seed_defaults() -> None:
    init_db()
    with connect() as con:
        generos = ["Hombre", "Mujer", "Niño", "Niña", "General"]
        categorias = ["Ropa", "Calzado", "Accesorios", "Hogar"]
        tallas = ["XS", "S", "M", "L", "XL", "XXL", "3XL", "-",]

        for g in generos:
            con.execute("INSERT INTO generos(nombre) VALUES (%s) ON CONFLICT DO NOTHING", (g,))
        for c in categorias:
            con.execute("INSERT INTO categorias(nombre) VALUES (%s) ON CONFLICT DO NOTHING", (c,))
        for t in tallas:
            con.execute("INSERT INTO tallas(nombre) VALUES (%s) ON CONFLICT DO NOTHING", (t,))
        con.commit()

    seed_quick_codes()

def _migrate_sacos(con) -> None:
    if not table_exists(con, "sacos"):
        con.execute("""
            CREATE TABLE sacos (
                codigo TEXT PRIMARY KEY,
                kg INTEGER NOT NULL DEFAULT 0,
                precio_saco INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.commit()
        return

    cols = _columns(con, "sacos")
    if "precio_saco" not in cols:
        con.execute("ALTER TABLE sacos ADD COLUMN precio_saco INTEGER NOT NULL DEFAULT 0")
    cols = _columns(con, "sacos")
    if "updated_at" not in cols:
        con.execute("ALTER TABLE sacos ADD COLUMN updated_at TEXT")
        con.execute("UPDATE sacos SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
    con.commit()

def _migrate_barcode_sequence(con) -> None:
    if not table_exists(con, "barcode_sequence"):
        con.execute("""
            CREATE TABLE barcode_sequence (
                prefix TEXT PRIMARY KEY,
                last_number INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.commit()
        return

    cols = _columns(con, "barcode_sequence")
    if "updated_at" not in cols:
        con.execute("ALTER TABLE barcode_sequence ADD COLUMN updated_at TEXT")
        con.execute("UPDATE barcode_sequence SET updated_at=CURRENT_TIMESTAMP WHERE updated_at IS NULL")
    con.commit()

def _migrate_usuarios(con) -> None:
    cols = _columns(con, "usuarios") if table_exists(con, "usuarios") else []

    if not cols:
        con.execute("""
            CREATE TABLE usuarios (
                id SERIAL PRIMARY KEY,
                usuario TEXT,
                nombre TEXT NOT NULL,
                apellido TEXT NOT NULL DEFAULT '',
                clave_hash TEXT,
                role TEXT NOT NULL DEFAULT 'user',
                is_active INTEGER NOT NULL DEFAULT 1,

                can_pos INTEGER NOT NULL DEFAULT 1,
                can_stock INTEGER NOT NULL DEFAULT 1,
                can_production INTEGER NOT NULL DEFAULT 1,
                can_informes INTEGER NOT NULL DEFAULT 0,
                can_database INTEGER NOT NULL DEFAULT 0,
                can_ajustes INTEGER NOT NULL DEFAULT 0,
                sucursal_id INTEGER,

                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        con.commit()
        return

    for coldef in [
        ("usuario", "TEXT"),
        ("clave_hash", "TEXT"),
        ("role", "TEXT NOT NULL DEFAULT 'user'"),
        ("is_active", "INTEGER NOT NULL DEFAULT 1"),
        ("can_pos", "INTEGER NOT NULL DEFAULT 1"),
        ("can_stock", "INTEGER NOT NULL DEFAULT 1"),
        ("can_production", "INTEGER NOT NULL DEFAULT 1"),
        ("can_informes", "INTEGER NOT NULL DEFAULT 0"),
        ("can_database", "INTEGER NOT NULL DEFAULT 0"),
        ("can_ajustes", "INTEGER NOT NULL DEFAULT 0"),
        ("sucursal_id", "INTEGER"),
        ("created_at", "TEXT"),
        ("updated_at", "TEXT"),
    ]:
        name, typ = coldef
        if name not in cols:
            con.execute(f"ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS {name} {typ}")

    con.commit()

def _migrate_sucursales(con) -> None:
    if not table_exists(con, "sucursales"):
        con.execute("""
            CREATE TABLE sucursales (
                id SERIAL PRIMARY KEY,
                codigo TEXT NOT NULL UNIQUE,
                nombre TEXT NOT NULL,
                direccion TEXT DEFAULT '',
                region TEXT DEFAULT '',
                comuna TEXT DEFAULT '',
                is_active INTEGER NOT NULL DEFAULT 1,

                api_environment TEXT DEFAULT 'prod',
                api_company_rut TEXT DEFAULT '',
                api_sucursal_code TEXT DEFAULT '',
                api_user TEXT DEFAULT '',
                api_password TEXT DEFAULT '',
                api_token TEXT DEFAULT '',
                api_url TEXT DEFAULT '',
                api_enabled INTEGER NOT NULL DEFAULT 0,
                api_extra_json TEXT DEFAULT '',

                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.commit()
        return

    cols = _columns(con, "sucursales")
    for name, typ in [
        ("codigo", "TEXT"),
        ("nombre", "TEXT"),
        ("direccion", "TEXT DEFAULT ''"),
        ("region", "TEXT DEFAULT ''"),
        ("comuna", "TEXT DEFAULT ''"),
        ("is_active", "INTEGER NOT NULL DEFAULT 1"),
        ("api_environment", "TEXT DEFAULT 'prod'"),
        ("api_company_rut", "TEXT DEFAULT ''"),
        ("api_sucursal_code", "TEXT DEFAULT ''"),
        ("api_user", "TEXT DEFAULT ''"),
        ("api_password", "TEXT DEFAULT ''"),
        ("api_token", "TEXT DEFAULT ''"),
        ("api_url", "TEXT DEFAULT ''"),
        ("api_enabled", "INTEGER NOT NULL DEFAULT 0"),
        ("api_extra_json", "TEXT DEFAULT ''"),
        ("created_at", "TEXT"),
        ("updated_at", "TEXT"),
    ]:
        if name not in cols:
            con.execute(f"ALTER TABLE sucursales ADD COLUMN {name} {typ}")

    con.commit()


def _migrate_document_sequences(con) -> None:
    if not table_exists(con, "document_sequences"):
        con.execute("""
            CREATE TABLE document_sequences (
                doc_type TEXT PRIMARY KEY,
                last_number INTEGER NOT NULL DEFAULT 0,
                updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)
        con.commit()
        return

    cols = _columns(con, "document_sequences")
    for name, typ in [
        ("doc_type", "TEXT"),
        ("last_number", "INTEGER NOT NULL DEFAULT 0"),
        ("updated_at", "TEXT"),
    ]:
        if name not in cols:
            con.execute(f"ALTER TABLE document_sequences ADD COLUMN {name} {typ}")

    con.commit()

def _migrate_stock_tables(con) -> None:
    # stock_batches
    if not table_exists(con, "stock_batches"):
        con.execute("""
            CREATE TABLE stock_batches (
                id6 TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                sucursal_id INTEGER,
                saco_codigo TEXT,
                categoria TEXT,
                genero TEXT
            )
        """)
    else:
        cols = _columns(con, "stock_batches")
        if "sucursal_id" not in cols:
            con.execute("ALTER TABLE stock_batches ADD COLUMN sucursal_id INTEGER")
        if "saco_codigo" not in cols:
            con.execute("ALTER TABLE stock_batches ADD COLUMN saco_codigo TEXT")
        if "categoria" not in cols:
            con.execute("ALTER TABLE stock_batches ADD COLUMN categoria TEXT")
        if "genero" not in cols:
            con.execute("ALTER TABLE stock_batches ADD COLUMN genero TEXT")

    # stock_batch_lines
    if not table_exists(con, "stock_batch_lines"):
        con.execute("""
            CREATE TABLE stock_batch_lines (
                id SERIAL PRIMARY KEY,
                batch_id6 TEXT NOT NULL,
                barcode TEXT NOT NULL,
                producto TEXT,
                genero TEXT,
                descripcion TEXT,
                precio INTEGER NOT NULL,
                FOREIGN KEY(batch_id6) REFERENCES stock_batches(id6) ON DELETE CASCADE
            )
        """)
    else:
        cols = _columns(con, "stock_batch_lines")
        if "barcode" not in cols:
            con.execute("ALTER TABLE stock_batch_lines ADD COLUMN barcode TEXT")
        if "producto" not in cols:
            con.execute("ALTER TABLE stock_batch_lines ADD COLUMN producto TEXT")
        if "genero" not in cols:
            con.execute("ALTER TABLE stock_batch_lines ADD COLUMN genero TEXT")
        if "descripcion" not in cols:
            con.execute("ALTER TABLE stock_batch_lines ADD COLUMN descripcion TEXT")
        if "precio" not in cols:
            con.execute("ALTER TABLE stock_batch_lines ADD COLUMN precio INTEGER NOT NULL DEFAULT 0")

    con.commit()

# -----------------------------
# CRUD minimal (senin main kullanıyor)
# -----------------------------
def list_usuarios(active_only: bool = True) -> List[Dict[str, Any]]:
    init_db()
    with connect() as con:
        sql = """
            SELECT id, usuario, nombre, apellido, role, is_active,
                   can_pos, can_stock, can_production, can_informes, can_database, can_ajustes,
                   sucursal_id
            FROM usuarios
        """
        if active_only:
            sql += " WHERE COALESCE(is_active,1)=1"
        sql += " ORDER BY COALESCE(usuario,''), id"
        rows = con.execute(sql).fetchall()
        return [dict(r) for r in rows]


def authenticate_usuario(usuario: str, clave: str) -> Optional[Dict[str, Any]]:
    init_db()
    usuario = (usuario or "").strip().upper()
    clave = (clave or "").strip()
    if not usuario or not clave:
        return None

    h = _hash_password(clave)
    with connect() as con:
        row = con.execute("""
            SELECT id, usuario, nombre, apellido, role, is_active,
                   can_pos, can_stock, can_production, can_informes, can_database, can_ajustes,
                   sucursal_id
            FROM usuarios
            WHERE UPPER(COALESCE(usuario,'')) = UPPER(%s)
                AND COALESCE(clave_hash,'') = %s
                AND COALESCE(is_active,1) = 1
            LIMIT 1
        """, (usuario, h)).fetchone()

        return dict(row) if row else None


def create_usuario(*, usuario: str, nombre: str, apellido: str, clave: str, role: str = "user",
                   perms: Optional[Dict[str, int]] = None, is_active: int = 1,
                   sucursal_id: Optional[int] = None) -> None:
    init_db()
    usuario = (usuario or "").strip().upper()
    if not usuario:
        raise ValueError("usuario vacío")

    if perms is None:
        perms = dict(
            can_pos=1, can_stock=1, can_production=1,
            can_informes=0, can_database=0, can_ajustes=0
        )

    with connect() as con:
        con.execute("""
            INSERT INTO usuarios(
                usuario, nombre, apellido, clave_hash, role, is_active,
                can_pos, can_stock, can_production, can_informes, can_database, can_ajustes,
                sucursal_id, created_at, updated_at
            )
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
        """, (
            usuario, nombre, apellido, _hash_password(clave), role, int(is_active),
            int(perms.get("can_pos", 1)),
            int(perms.get("can_stock", 1)),
            int(perms.get("can_production", 1)),
            int(perms.get("can_informes", 0)),
            int(perms.get("can_database", 0)),
            int(perms.get("can_ajustes", 0)),
            int(sucursal_id) if sucursal_id else None
        ))
        con.commit()


def update_usuario(*, user_id: int, usuario: str, nombre: str, apellido: str, role: str,
                   is_active: int, perms: Dict[str, int], sucursal_id: Optional[int] = None) -> None:
    init_db()
    usuario = (usuario or "").strip().upper()

    with connect() as con:
        con.execute("""
            UPDATE usuarios SET
                usuario=%s, nombre=%s, apellido=%s, role=%s, is_active=%s,
                can_pos=%s, can_stock=%s, can_production=%s, can_informes=%s, can_database=%s, can_ajustes=%s,
                sucursal_id=%s,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=%s
        """, (
            usuario, nombre, apellido, role, int(is_active),
            int(perms.get("can_pos", 1)),
            int(perms.get("can_stock", 1)),
            int(perms.get("can_production", 1)),
            int(perms.get("can_informes", 0)),
            int(perms.get("can_database", 0)),
            int(perms.get("can_ajustes", 0)),
            int(sucursal_id) if sucursal_id else None,
            int(user_id)
         ))
        con.commit()


def set_usuario_password(user_id: int, clave: str) -> None:
    init_db()
    with connect() as con:
        con.execute(
            "UPDATE usuarios SET clave_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (_hash_password(clave), int(user_id))
        )
        con.commit()


def delete_usuario(user_id: int) -> None:
    init_db()
    with connect() as con:
        con.execute("DELETE FROM usuarios WHERE id=?", (int(user_id),))
        con.commit()
# Sacos helpers (senin ArticulosScreen kullanıyor)
def upsert_saco(codigo: str, kg: int = 0, precio_saco: Optional[int] = None) -> None:
    init_db()
    codigo = (codigo or "").strip().upper()
    if not codigo:
        raise ValueError("codigo vacío")
    with connect() as con:
        con.execute("""
            INSERT INTO sacos(codigo, kg, precio_saco, updated_at)
            VALUES(?, ?, COALESCE(?,0), CURRENT_TIMESTAMP)
            ON CONFLICT(codigo) DO UPDATE SET
                kg=excluded.kg,
                precio_saco=COALESCE(?, sacos.precio_saco),
                updated_at=CURRENT_TIMESTAMP
        """, (codigo, int(kg), precio_saco, precio_saco))
        con.commit()

def list_sacos() -> List[Dict[str, Any]]:
    init_db()
    with connect() as con:
        rows = con.execute("SELECT codigo, kg, COALESCE(precio_saco,0) precio_saco, updated_at FROM sacos ORDER BY codigo").fetchall()
        return [dict(r) for r in rows]

def delete_saco(codigo: str) -> None:
    init_db()
    codigo = (codigo or "").strip().upper()
    if not codigo:
        return
    with connect() as con:
        con.execute("DELETE FROM sacos WHERE codigo=?", (codigo,))
        con.commit()

def delete_producto(nombre: str, categoria: str | None = None) -> None:
    init_db()

    nombre = (nombre or "").strip()
    categoria = (categoria or "").strip() if categoria else None

    if not nombre:
        return

    with connect() as con:
        if categoria:
            row = con.execute(
                "SELECT id FROM categorias WHERE LOWER(nombre)=LOWER(?)",
                (categoria,)
            ).fetchone()

            if not row:
                raise ValueError(f"No existe la categoría: {categoria}")

            categoria_id = int(row["id"])

            con.execute(
                "DELETE FROM productos WHERE LOWER(nombre)=LOWER(?) AND categoria_id=?",
                (nombre, categoria_id)
            )
        else:
            con.execute(
                "DELETE FROM productos WHERE LOWER(nombre)=LOWER(?)",
                (nombre,)
            )

        con.commit()
# -----------------------------
# Sucursales
# -----------------------------
def list_sucursales(active_only: bool = True) -> List[Dict[str, Any]]:
    init_db()
    with connect() as con:
        sql = """
            SELECT id, codigo, nombre, direccion, region, comuna, is_active,
                   api_environment, api_company_rut, api_sucursal_code,
                   api_user, api_password, api_token, api_url, api_enabled, api_extra_json
            FROM sucursales
        """
        if active_only:
            sql += " WHERE COALESCE(is_active,1)=1"
        sql += " ORDER BY codigo, nombre"
        rows = con.execute(sql).fetchall()
        return [dict(r) for r in rows]


def get_sucursal_by_id(sucursal_id: int):
    init_db()
    with connect() as con:
        row = con.execute("""
            SELECT *
            FROM sucursales
            WHERE id = ?
            LIMIT 1
        """, (int(sucursal_id),)).fetchone()
        return dict(row) if row else None


def create_sucursal(
    *,
    codigo: str,
    nombre: str,
    direccion: str = "",
    region: str = "",
    comuna: str = "",
    is_active: int = 1,
    api_environment: str = "prod",
    api_company_rut: str = "",
    api_sucursal_code: str = "",
    api_user: str = "",
    api_password: str = "",
    api_token: str = "",
    api_url: str = "",
    api_enabled: int = 0,
    api_extra_json: str = "",
):
    init_db()

    codigo = (codigo or "").strip().upper()
    nombre = (nombre or "").strip()

    if not codigo:
        raise ValueError("Código vacío")
    if not nombre:
        raise ValueError("Nombre vacío")

    with connect() as con:
        con.execute("""
            INSERT INTO sucursales(
                codigo, nombre, direccion, region, comuna, is_active,
                api_environment, api_company_rut, api_sucursal_code,
                api_user, api_password, api_token, api_url, api_enabled, api_extra_json,
                created_at, updated_at
            )
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)
        """, (
            codigo, nombre, direccion, region, comuna, int(is_active),
            api_environment, api_company_rut, api_sucursal_code,
            api_user, api_password, api_token, api_url, int(api_enabled), api_extra_json
        ))
        con.commit()


def update_sucursal(
    *,
    sucursal_id: int,
    codigo: str,
    nombre: str,
    direccion: str = "",
    region: str = "",
    comuna: str = "",
    is_active: int = 1,
    api_environment: str = "prod",
    api_company_rut: str = "",
    api_sucursal_code: str = "",
    api_user: str = "",
    api_password: str = "",
    api_token: str = "",
    api_url: str = "",
    api_enabled: int = 0,
    api_extra_json: str = "",
):
    init_db()

    codigo = (codigo or "").strip().upper()
    nombre = (nombre or "").strip()

    if not codigo:
        raise ValueError("Código vacío")
    if not nombre:
        raise ValueError("Nombre vacío")

    with connect() as con:
        con.execute("""
            UPDATE sucursales SET
                codigo = ?,
                nombre = ?,
                direccion = ?,
                region = ?,
                comuna = ?,
                is_active = ?,
                api_environment = ?,
                api_company_rut = ?,
                api_sucursal_code = ?,
                api_user = ?,
                api_password = ?,
                api_token = ?,
                api_url = ?,
                api_enabled = ?,
                api_extra_json = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (
            codigo, nombre, direccion, region, comuna, int(is_active),
            api_environment, api_company_rut, api_sucursal_code,
            api_user, api_password, api_token, api_url, int(api_enabled), api_extra_json,
            int(sucursal_id)
        ))
        con.commit()


def delete_sucursal(sucursal_id: int):
    init_db()
    with connect() as con:
        con.execute("DELETE FROM sucursales WHERE id = ?", (int(sucursal_id),))
        con.commit()

# -----------------------------
# Catalog helpers (UI uses these)
# -----------------------------
def list_generos():
    init_db()
    with connect() as con:
        rows = con.execute("SELECT nombre FROM generos ORDER BY nombre").fetchall()
        return [dict(r) for r in rows]

def list_categorias():
    init_db()
    with connect() as con:
        rows = con.execute("SELECT nombre FROM categorias ORDER BY nombre").fetchall()
        return [dict(r) for r in rows]

def list_tallas():
    init_db()
    with connect() as con:
        rows = con.execute("SELECT nombre FROM tallas ORDER BY nombre").fetchall()
        return [dict(r) for r in rows]

def list_productos_by_categoria(categoria: str):
    init_db()
    categoria = (categoria or "").strip()
    with connect() as con:
        row = con.execute(
            "SELECT id FROM categorias WHERE LOWER(nombre)=LOWER(?)",
            (categoria,)
        ).fetchone()
        if not row:
            return []
        cid = int(row["id"])
        rows = con.execute(
            "SELECT nombre FROM productos WHERE categoria_id=? ORDER BY nombre",
            (cid,)
        ).fetchall()
        return [dict(r) for r in rows]

def list_productos(_unused=None):
    # fallback: tüm ürünler
    init_db()
    with connect() as con:
        rows = con.execute("SELECT nombre FROM productos ORDER BY nombre").fetchall()
        return [dict(r) for r in rows]

def insert_producto(nombre: str, categoria: str):
    init_db()

    nombre = (nombre or "").strip()
    categoria = (categoria or "").strip()

    if not nombre:
        raise ValueError("Nombre de producto vacío.")
    if not categoria:
        raise ValueError("Categoría vacía.")

    with connect() as con:
        row = con.execute(
            "SELECT id FROM categorias WHERE LOWER(nombre)=LOWER(?)",
            (categoria,)
        ).fetchone()

        if not row:
            raise ValueError(f"No existe la categoría: {categoria}")

        categoria_id = int(row["id"])

        con.execute("""
            INSERT INTO productos (categoria_id, nombre)
            VALUES (?, ?)
        """, (categoria_id, nombre))

        con.commit()

# -----------------------------
# EAN13 generator
# -----------------------------
def next_ean13(prefix: str, con=None):
    """
    Generates next EAN13 barcode using prefix + sequential number
    """
    import random

    prefix = str(prefix)

    # 12 hanelik base oluştur
    base = prefix + str(random.randint(10000, 99999))

    base = base[:12]

    digits = [int(x) for x in base]

    s = sum(digits[::2]) + sum(d * 3 for d in digits[1::2])
    check = (10 - (s % 10)) % 10

    return base + str(check)

# -----------------------------
# Production: bulk generate labels
# -----------------------------
def bulk_generate_labels(
    *,
    qty: int,
    prefix: str,
    descripcion: str,
    precio: int,
    kg: float,
    saco_codigo: str,
    saco_kg: int,
    genero: str,
    categoria: str,
    producto: str,
    talla: str,
) -> List[str]:
    """
    Creates <qty> labels with unique EAN13 barcodes and inserts into labels table.
    Returns generated barcodes list.
    """
    init_db()

    qty = int(qty)
    if qty <= 0:
        return []

    precio = int(precio)
    kg = float(kg or 0)
    saco_codigo = (saco_codigo or "").strip().upper()
    genero = (genero or "").strip()
    categoria = (categoria or "").strip()
    producto = (producto or "").strip()
    talla = (talla or "").strip() or "-"

    barcodes: List[str] = []
    con = connect()

    try:
        for _ in range(qty):
            bc = next_ean13(prefix, con=con)

            con.execute("""
                INSERT INTO labels(
                    barcode, saco_codigo, saco_kg, genero, categoria, producto, talla,
                    precio, kg, descripcion, prefix, created_at
                )
                VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            """, (
                bc,
                saco_codigo,
                int(saco_kg),
                genero,
                categoria,
                producto,
                talla,
                int(precio),
                float(kg),
                descripcion,
                prefix
            ))

            barcodes.append(bc)

        con.commit()
        return barcodes

    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def preview_generate_labels(
    *,
    qty: int,
    prefix: str,
    descripcion: str,
    precio: int,
    kg: float,
    saco_codigo: str,
    saco_kg: int,
    genero: str,
    categoria: str,
    producto: str,
    talla: str,
    exclude_barcodes: Optional[set[str]] = None,
) -> List[Dict[str, Any]]:
    """
    Sadece preview için barkod üretir.
    DB'ye yazmaz.
    """
    init_db()

    qty = int(qty)
    if qty <= 0:
        return []

    precio = int(precio)
    kg = float(kg or 0)
    saco_codigo = (saco_codigo or "").strip().upper()
    genero = (genero or "").strip()
    categoria = (categoria or "").strip()
    producto = (producto or "").strip()
    talla = (talla or "").strip() or "-"

    rows: List[Dict[str, Any]] = []

    con = connect()
    try:
        used = set(exclude_barcodes or [])

        for _ in range(qty):
            for _retry in range(50):
                bc = next_ean13(prefix, con=con)
                if bc in used:
                    continue

                row = con.execute(
                    "SELECT 1 FROM labels WHERE barcode=? LIMIT 1",
                    (bc,)
                ).fetchone()

                if row is None:
                    used.add(bc)
                    rows.append({
                        "barcode": bc,
                        "saco_codigo": saco_codigo,
                        "saco_kg": int(saco_kg),
                        "genero": genero,
                        "categoria": categoria,
                        "producto": producto,
                        "talla": talla,
                        "precio": int(precio),
                        "kg": float(kg),
                        "descripcion": descripcion,
                        "prefix": prefix,
                    })
                    break
            else:
                raise RuntimeError("No se pudo generar barcode único para preview.")

        con.commit()
        return rows

    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def fetch_analizar_ventas(
    *,
    desde: str,
    hasta: str,
    sucursal: str = "TODAS",
    saco: str = "TODOS",
    producto: str = "TODOS",
    genero: str = "TODOS",
):
    init_db()

    sql = """
        SELECT
            COALESCE(v.sucursal, '') AS sucursal,
            COALESCE(vi.saco, '') AS saco,
            COALESCE(MAX(vi.producto_base), '') AS producto,
            COALESCE(MAX(vi.genero), '') AS genero,
            COALESCE(SUM(vi.cantidad), 0) AS cantidad,
            COALESCE(SUM(vi.kg), 0) AS kg_total,
            COALESCE(SUM(vi.valor), 0) AS total
        FROM ventas v
        INNER JOIN venta_items vi ON vi.venta_id = v.id
        WHERE DATE(v.fecha) BETWEEN %s AND %s
    """

    params = [desde, hasta]

    sucursal_val = str(sucursal or "").strip().upper()
    saco_val = str(saco or "").strip().upper()
    producto_val = str(producto or "").strip().upper()
    genero_val = str(genero or "").strip().upper()

    if sucursal_val not in ("TODAS", "TODOS", ""):
        sql += " AND TRIM(UPPER(COALESCE(v.sucursal, ''))) = TRIM(UPPER(%s))"
        params.append(str(sucursal).strip())

    if saco_val not in ("TODOS", "TODAS", ""):
        sql += " AND TRIM(UPPER(COALESCE(vi.saco, ''))) = TRIM(UPPER(%s))"
        params.append(str(saco).strip())

    if producto_val not in ("TODOS", "TODAS", ""):
        sql += " AND TRIM(UPPER(COALESCE(vi.producto_base, ''))) = TRIM(UPPER(%s))"
        params.append(str(producto).strip())

    if genero_val not in ("TODOS", "TODAS", ""):
        sql += " AND TRIM(UPPER(COALESCE(vi.genero, ''))) = TRIM(UPPER(%s))"
        params.append(str(genero).strip())

    sql += """
        GROUP BY
            COALESCE(v.sucursal, ''),
            COALESCE(vi.saco, '')
        ORDER BY
            COALESCE(v.sucursal, ''),
            COALESCE(vi.saco, '')
    """

    with connect() as con:
        rows = con.execute(sql, params).fetchall()

    out = []

    for rr in rows:
        r = dict(rr)

        cantidad = int(r.get("cantidad", 0) or 0)
        kg_total = float(r.get("kg_total", 0) or 0)
        total = int(r.get("total", 0) or 0)

        precio_promedio = int(round(total / cantidad)) if cantidad > 0 else 0
        precio_por_kg = int(round(total / kg_total)) if kg_total > 0 else 0

        out.append({
            "sucursal": r.get("sucursal", "") or "",
            "saco": r.get("saco", "") or "",
            "producto": r.get("producto", "") or "",
            "genero": r.get("genero", "") or "",
            "cantidad": cantidad,
            "kg_total": kg_total,
            "precio_promedio": precio_promedio,
            "precio_por_kg": precio_por_kg,
            "total": total,
        })

    return out

def fetch_analizar_filter_values():
    with connect() as con:
        def get_list(query, params=None):
            params = params or ()
            rows = con.execute(query, params).fetchall()

            vals = []
            for r in rows:
                if isinstance(r, dict):
                    v = list(r.values())[0] if r else None
                else:
                    try:
                        v = r[0]
                    except Exception:
                        v = None

                if v and str(v).strip():
                    vals.append(str(v).strip())

            return vals

        try:
            sucursales = get_list("""
                SELECT DISTINCT sucursal
                FROM ventas
                WHERE COALESCE(sucursal, '') <> ''
                ORDER BY sucursal
            """)
        except Exception:
            sucursales = []

        try:
            productos = get_list("""
                SELECT DISTINCT producto_base
                FROM venta_items
                WHERE COALESCE(producto_base, '') <> ''
                ORDER BY producto_base
            """)
        except Exception:
            productos = []

        try:
            generos = get_list("""
                SELECT DISTINCT genero
                FROM venta_items
                WHERE COALESCE(genero, '') <> ''
                ORDER BY genero
            """)
        except Exception:
            generos = []

        try:
            sacos = get_list("""
                SELECT DISTINCT saco
                FROM venta_items
                WHERE COALESCE(saco, '') <> ''
                ORDER BY saco
            """)
        except Exception:
            sacos = []

        return {
            "sucursales": sucursales,
            "productos": productos,
            "generos": generos,
            "sacos": sacos,
        }

def fetch_sucursales_for_filter():
    with connect() as con:
        try:
            rows = con.execute("""
                SELECT nombre
                FROM sucursales
                WHERE COALESCE(nombre, '') <> ''
                ORDER BY nombre
            """).fetchall()

            vals = []
            for r in rows:
                if isinstance(r, dict):
                    v = r.get("nombre")
                else:
                    v = r[0] if r else None

                if v and str(v).strip():
                    vals.append(str(v).strip())

            return vals
        except Exception:
            return []

# ---------------------------------------------------------
# OFERTAS
# ---------------------------------------------------------

def create_oferta(*, fecha_desde: str, fecha_hasta: str, saco: str, categoria: str, producto: str,
                  descuento_pct: int = 0, tipo_oferta: str = "PCT", valor_oferta: str = ""):
    init_db()

    saco = (saco or "TODOS").strip().upper()
    categoria = (categoria or "TODOS").strip()
    producto = (producto or "TODOS").strip()
    tipo_oferta = (tipo_oferta or "PCT").strip().upper()
    valor_oferta = (valor_oferta or "").strip()

    with connect() as con:
        con.execute("""
            INSERT INTO ofertas(
                fecha_desde,
                fecha_hasta,
                saco,
                categoria,
                producto,
                descuento_pct,
                tipo_oferta,
                valor_oferta,
                activo
            )
            VALUES(?,?,?,?,?,?,?,?,1)
        """, (
            fecha_desde,
            fecha_hasta,
            saco,
            categoria,
            producto,
            int(descuento_pct),
            tipo_oferta,
            valor_oferta
        ))
        con.commit()


def list_ofertas():
    init_db()

    with connect() as con:
        rows = con.execute("""
            SELECT *
            FROM ofertas
            ORDER BY id DESC
        """).fetchall()

        return [dict(r) for r in rows]


def toggle_oferta(oferta_id: int):
    init_db()

    with connect() as con:
        con.execute("""
            UPDATE ofertas
            SET activo =
                CASE
                    WHEN activo = 1 THEN 0
                    ELSE 1
                END
            WHERE id = ?
        """, (oferta_id,))
        con.commit()


def delete_oferta(oferta_id: int):
    init_db()

    with connect() as con:
        con.execute(
            "DELETE FROM ofertas WHERE id=?",
            (oferta_id,)
        )
        con.commit()

def calcular_oferta(barcode: str, precio_actual: int) -> int:
    """
    POS barkod okuttuğunda çalışır.
    Aktif oferta varsa fiyatı düşürür.
    """

    import datetime

    init_db()

    hoy = datetime.date.today().isoformat()

    with connect() as con:

        item = con.execute("""
            SELECT saco_codigo, producto
            FROM labels
            WHERE barcode=?
        """, (barcode,)).fetchone()

        if not item:
            return precio_actual

        saco = (item["saco_codigo"] or "").strip().upper()
        producto = (item["producto"] or "").strip()

        oferta = con.execute("""
            SELECT *
            FROM ofertas
            WHERE activo = 1
            AND date(?) BETWEEN date(fecha_desde) AND date(fecha_hasta)
            LIMIT 1
        """, (hoy,)).fetchone()

        if not oferta:
            return precio_actual

        oferta_saco = (oferta["saco"] or "TODOS").upper()
        oferta_prod = (oferta["producto"] or "TODOS")

        if oferta_saco != "TODOS" and oferta_saco != saco:
            return precio_actual

        if oferta_prod != "TODOS" and oferta_prod != producto:
            return precio_actual

        pct = int(oferta["descuento_pct"])

        nuevo = int(precio_actual * (1 - pct / 100))

        return nuevo

def get_matching_oferta(*, saco: str, categoria: str, producto: str, fecha_iso: str):
    init_db()

    saco = (saco or "").strip().upper()
    categoria = (categoria or "").strip()
    producto = (producto or "").strip()

    with connect() as con:
        rows = con.execute("""
            SELECT *
            FROM ofertas
            WHERE activo = 1
              AND date(?) BETWEEN date(fecha_desde) AND date(fecha_hasta)
            ORDER BY id DESC
        """, (fecha_iso,)).fetchall()

    for r in rows:
        oferta = dict(r)

        oferta_saco = (oferta.get("saco") or "TODOS").strip().upper()
        oferta_categoria = (oferta.get("categoria") or "TODOS").strip()
        oferta_producto = (oferta.get("producto") or "TODOS").strip()

        if oferta_saco != "TODOS" and oferta_saco != saco:
            continue

        if oferta_categoria != "TODOS" and oferta_categoria != categoria:
            continue

        if oferta_producto != "TODOS" and oferta_producto != producto:
            continue

        return oferta

    return None

def aplicar_descuento_pct(precio_actual: int, descuento_pct: int) -> int:
    precio_actual = int(precio_actual or 0)
    descuento_pct = int(descuento_pct or 0)

    if descuento_pct <= 0:
        return precio_actual

    nuevo = round(precio_actual * (1 - descuento_pct / 100.0))
    return max(0, int(nuevo))

def get_cliente_by_rut(rut: str):
    init_db()
    rut = (rut or "").strip()
    if not rut:
        return None

    with connect() as con:
        row = con.execute("""
            SELECT
                rut,
                razon_social,
                COALESCE(giro, '') AS giro,
                COALESCE(direccion, '') AS direccion,
                COALESCE(region, '') AS region,
                COALESCE(comuna, '') AS comuna
            FROM clientes
            WHERE rut = ?
            LIMIT 1
        """, (rut,)).fetchone()

        return dict(row) if row else None


def upsert_cliente(
    *,
    rut: str,
    razon_social: str,
    giro: str = "",
    direccion: str = "",
    region: str = "",
    comuna: str = "",
):
    init_db()

    rut = (rut or "").strip()
    razon_social = (razon_social or "").strip()
    giro = (giro or "").strip()
    direccion = (direccion or "").strip()
    region = (region or "").strip()
    comuna = (comuna or "").strip()

    if not rut:
        raise ValueError("RUT vacío")
    if not razon_social:
        raise ValueError("Razón Social vacía")

    with connect() as con:
        con.execute("""
            INSERT INTO clientes(
                rut,
                razon_social,
                giro,
                direccion,
                region,
                comuna,
                updated_at
            )
            VALUES(?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(rut) DO UPDATE SET
                razon_social = excluded.razon_social,
                giro = excluded.giro,
                direccion = excluded.direccion,
                region = excluded.region,
                comuna = excluded.comuna,
                updated_at = CURRENT_TIMESTAMP
        """, (
            rut,
            razon_social,
            giro,
            direccion,
            region,
            comuna,
        ))
        con.commit()

def list_clientes(limit: int = 200):
    init_db()
    with connect() as con:
        rows = con.execute("""
            SELECT
                rut,
                razon_social,
                COALESCE(giro, '') AS giro,
                COALESCE(direccion, '') AS direccion,
                COALESCE(region, '') AS region,
                COALESCE(comuna, '') AS comuna
            FROM clientes
            ORDER BY razon_social
            LIMIT ?
        """, (int(limit),)).fetchall()
        return [dict(r) for r in rows]

# -----------------------------
# Document sequences (empresa geneli)
# -----------------------------
def get_next_doc_number(*, doc_type: str) -> int:
    init_db()

    doc_type = (doc_type or "").strip().upper()
    if doc_type not in ("BOLETA", "FACTURA"):
        raise ValueError("doc_type inválido")

    with connect() as con:
        row = con.execute("""
            SELECT last_number
            FROM document_sequences
            WHERE doc_type = ?
            LIMIT 1
        """, (doc_type,)).fetchone()

        if row is None:
            next_number = 1
            con.execute("""
                INSERT INTO document_sequences(doc_type, last_number, updated_at)
                VALUES(?, ?, CURRENT_TIMESTAMP)
            """, (doc_type, next_number))
        else:
            next_number = int(row["last_number"] or 0) + 1
            con.execute("""
                UPDATE document_sequences
                SET last_number = ?, updated_at = CURRENT_TIMESTAMP
                WHERE doc_type = ?
            """, (next_number, doc_type))

        con.commit()
        return next_number

def get_usuario_by_login(usuario: str):
    init_db()
    usuario = (usuario or "").strip().upper()

    with connect() as con:
        row = con.execute("""
            SELECT *
            FROM usuarios
            WHERE UPPER(COALESCE(usuario,'')) = UPPER(?)
            LIMIT 1
        """, (usuario,)).fetchone()

        return dict(row) if row else None

def clear_labels_and_prints():
    init_db()
    with connect() as con:
        con.execute("DELETE FROM prints")
        con.execute("DELETE FROM labels")
        con.commit()

# -----------------------------
# STOCK
# -----------------------------
def list_stock_batches(
    *,
    sucursal_id: Optional[int] = None
) -> List[Dict[str, Any]]:
    init_db()
    with connect() as con:
        sql = """
            SELECT
                sb.id6,
                sb.created_at,
                sb.sucursal_id,
                sb.saco_codigo,
                sb.categoria,
                sb.genero,
                COUNT(sbl.id) AS total_items,
                COALESCE(SUM(sbl.precio), 0) AS total_precio
            FROM stock_batches sb
            LEFT JOIN stock_batch_lines sbl
                ON sbl.batch_id6 = sb.id6
        """
        params = []

        if sucursal_id is not None:
            sql += " WHERE sb.sucursal_id = ?"
            params.append(int(sucursal_id))

        sql += """
            GROUP BY
                sb.id6, sb.created_at, sb.sucursal_id, sb.saco_codigo, sb.categoria, sb.genero
            ORDER BY sb.created_at DESC, sb.id6 DESC
        """

        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]


def get_stock_batch_lines(batch_id6: str) -> List[Dict[str, Any]]:
    init_db()
    with connect() as con:
        rows = con.execute("""
            SELECT
                id,
                batch_id6,
                barcode,
                producto,
                genero,
                descripcion,
                precio
            FROM stock_batch_lines
            WHERE batch_id6 = ?
            ORDER BY id ASC
        """, (batch_id6,)).fetchall()
        return [dict(r) for r in rows]

from datetime import datetime

def generate_production_no():
    init_db()
    yymm = datetime.now().strftime("%y%m")

    with connect() as con:
        row = con.execute("""
            SELECT production_no
            FROM production_sessions
            WHERE production_no LIKE ?
            ORDER BY production_no DESC
            LIMIT 1
        """, (yymm + "%",)).fetchone()

        if row:
            last_no = str(row["production_no"])
            counter = int(last_no[-4:]) + 1
        else:
            counter = 1

        return f"{yymm}{counter:04d}"

def ensure_production_tables():
    init_db()
    with connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS production_sessions (
                id SERIAL PRIMARY KEY,
                production_no TEXT NOT NULL UNIQUE,
                sucursal_id INTEGER,
                usuario TEXT DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                status TEXT NOT NULL DEFAULT 'OPEN'
            )
        """)
        con.commit()

def create_production_session(sucursal_id, usuario):
    init_db()

    production_no = generate_production_no()

    with connect() as con:
        row = con.execute("""
            INSERT INTO production_sessions (
                production_no, sucursal_id, usuario, created_at, status
            )
            VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?)
            RETURNING production_no
        """, (
            production_no,
            sucursal_id,
            usuario,
            "open",
        )).fetchone()

        con.commit()
        return row["production_no"] if isinstance(row, dict) else row[0]

def fetch_production_report(*, fecha_desde: str, fecha_hasta: str, saco: str = "", barcode: str = ""):
    init_db()

    where = [
        "DATE(h.fecha) >= %s",
        "DATE(h.fecha) <= %s",
        "TRIM(UPPER(COALESCE(h.accion, ''))) = 'PRODUCCIÓN'"
    ]
    params = [fecha_desde, fecha_hasta]

    if (saco or "").strip():
        where.append("UPPER(COALESCE(h.saco_codigo,'')) = UPPER(%s)")
        params.append((saco or "").strip())

    if (barcode or "").strip():
        where.append("""
            EXISTS (
                SELECT 1
                FROM labels lx
                WHERE lx.production_no = h.production_no
                  AND COALESCE(lx.barcode, '') = %s
            )
        """)
        params.append((barcode or "").strip())

    sql = f"""
        SELECT
            h.production_no,
            h.fecha AS created_at,
            COALESCE(h.usuario, '') AS usuario,
            NULL::integer AS sucursal_id,
            COALESCE(h.sucursal_destino, '') AS sucursal_nombre,
            COALESCE(COUNT(l.id), 0) AS cantidad,
            COALESCE(SUM(l.kg), 0) AS total_kg,
            COALESCE(SUM(l.precio), 0) AS total_precio,
            COALESCE(h.saco_codigo, '') AS saco_codigo
        FROM hoja_entradas h
        LEFT JOIN labels l
            ON l.production_no = h.production_no
        WHERE {" AND ".join(where)}
        GROUP BY
            h.production_no,
            h.fecha,
            h.usuario,
            h.sucursal_destino,
            h.saco_codigo,
            h.id
        ORDER BY
            h.id DESC
    """

    with connect() as con:
        rows = con.execute(sql, params).fetchall()
        return [dict(r) for r in rows]


def get_production_labels(production_no: str):
    init_db()
    ensure_production_tables()

    with connect() as con:
        rows = con.execute("""
            SELECT
                id,
                barcode,
                COALESCE(descripcion, '') AS descripcion,
                COALESCE(producto, '') AS producto,
                COALESCE(categoria, '') AS categoria,
                COALESCE(genero, '') AS genero,
                COALESCE(talla, '') AS talla,
                COALESCE(precio, 0) AS precio,
                COALESCE(kg, 0) AS kg,
                COALESCE(saco_codigo, '') AS saco_codigo,
                COALESCE(created_at, '') AS created_at
            FROM labels
            WHERE COALESCE(production_no, '') = ?
            ORDER BY id ASC
        """, (production_no or "",)).fetchall()

        return [dict(r) for r in rows]

def fetch_production_header(production_no: str):
    init_db()
    ensure_production_tables()

    with connect() as con:
        row = con.execute("""
            SELECT
                ps.production_no,
                ps.created_at,
                ps.usuario,
                ps.status,
                ps.sucursal_id,
                COALESCE(s.nombre, '') AS sucursal_nombre,
                COALESCE(MAX(l.saco_codigo), '') AS saco_codigo,
                COUNT(l.id) AS cantidad,
                COALESCE(SUM(l.kg), 0) AS total_kg,
                COALESCE(SUM(l.precio), 0) AS total_precio
            FROM production_sessions ps
            LEFT JOIN labels l
                ON l.production_no = ps.production_no
            LEFT JOIN sucursales s
                ON s.id = ps.sucursal_id
            WHERE ps.production_no = ?
            GROUP BY
                ps.production_no, ps.created_at, ps.usuario, ps.status,
                ps.sucursal_id, s.nombre
        """, (production_no or "",)).fetchone()

        return dict(row) if row else None

if __name__ == "__main__":
    with connect() as con:
        rows = con.execute("""
            SELECT
                vi.id,
                vi.codigo,
                vi.producto,
                vi.kg,
                l.kg AS label_kg
            FROM venta_items vi
            LEFT JOIN labels l
                ON l.barcode = vi.codigo
            ORDER BY vi.id DESC
            LIMIT 10
        """).fetchall()

        for r in rows:
            print(dict(r))

def fetch_sucursales_resumen_filter():
    with connect() as con:
        try:
            rows = con.execute("""
                SELECT nombre
                FROM sucursales
                WHERE COALESCE(nombre, '') <> ''
                ORDER BY nombre
            """).fetchall()

            vals = []
            for r in rows:
                if isinstance(r, dict):
                    v = r.get("nombre")
                else:
                    v = r[0] if r else None

                if v and str(v).strip():
                    vals.append(str(v).strip())

            return vals
        except Exception as e:
            print("SUCURSALES FILTER ERROR:", repr(e))
            return []


def fetch_usuarios_resumen_filter():
    with connect() as con:
        try:
            rows = con.execute("""
                SELECT DISTINCT usuario
                FROM ventas
                WHERE COALESCE(usuario, '') <> ''
                ORDER BY usuario
            """).fetchall()

            vals = []
            for r in rows:
                if isinstance(r, dict):
                    v = r.get("usuario")
                else:
                    v = r[0] if r else None

                if v and str(v).strip():
                    vals.append(str(v).strip())

            return vals
        except Exception as e:
            print("USUARIOS FILTER ERROR:", repr(e))
            return []


def fetch_ventas_resumen_filter_values():
    """
    Geriye dönük uyumluluk için bırakıldı.
    Artık:
      - sucursales -> master sucursales tablosundan
      - cajas -> usuario filtresi için boş liste
    """
    return {
        "sucursales": fetch_sucursales_resumen_filter(),
        "cajas": []
    }


def fetch_ventas_resumen(
    *,
    desde: str,
    hasta: str,
    sucursal: str,
    caja: str = "TODAS",
    usuario: str = "TODOS",
    venta_id: int | None = None
):
    init_db()

    sql = """
        SELECT
            v.id,
            v.id AS folio,
            COALESCE(TO_CHAR(v.fecha, 'YYYY-MM-DD'), '') AS fecha,
            COALESCE(v.sucursal, '') AS sucursal,
            COALESCE((
                SELECT SUM(COALESCE(vi2.cantidad, 0))
                FROM venta_items vi2
                WHERE vi2.venta_id = v.id
            ), 0) AS cantidad,
            COALESCE(v.total, 0) AS total,
            COALESCE(v.promocion, 0) AS promo,
            COALESCE(v.medio_pago, '') AS medio_pago,
            COALESCE(v.usuario, '') AS usuario
        FROM ventas v
        WHERE DATE(v.fecha) BETWEEN %s AND %s
    """

    params = [desde, hasta]

    if sucursal and sucursal not in ("TODAS", "TODOS", ""):
        sql += " AND TRIM(UPPER(COALESCE(v.sucursal, ''))) = TRIM(UPPER(%s))"
        params.append(sucursal)

    # Caja artık aktif kullanılmıyor; geriye dönük uyumluluk için bırakıldı
    if caja and caja != "TODAS":
        # Eski kayıtlarla çakışma olmasın diye şimdilik pas geçiyoruz
        pass

    if usuario and usuario != "TODOS":
        sql += " AND TRIM(UPPER(COALESCE(v.usuario, ''))) = TRIM(UPPER(%s))"
        params.append(usuario)

    if venta_id is not None:
        sql += " AND v.id = %s"
        params.append(int(venta_id))

    sql += " ORDER BY v.id DESC"

    with connect() as con:
        rows = con.execute(sql, params).fetchall()

    out = []

    for rr in rows:
        r = dict(rr)

        medio_raw = str(r.get("medio_pago") or "").strip()
        medio_norm = unicodedata.normalize("NFKD", medio_raw).encode("ascii", "ignore").decode().lower()

        total = int(r.get("total", 0) or 0)

        monto_pago = total
        if ":" in medio_raw:
            try:
                parte = medio_raw.split(":", 1)[1]
                solo_digitos = re.sub(r"\D", "", parte)
                if solo_digitos:
                    monto_pago = int(solo_digitos)
            except Exception:
                monto_pago = total

        es_efectivo = "efectivo" in medio_norm
        es_debito = "debito" in medio_norm
        es_credito = "credito" in medio_norm
        es_transferencia = "transferencia" in medio_norm or "transfer" in medio_norm

        out.append({
            "id": r["id"],
            "folio": r["folio"],
            "fecha": r["fecha"],
            "sucursal": r["sucursal"],
            "cantidad": int(r["cantidad"] or 0),
            "total": total,
            "efectivo": monto_pago if es_efectivo else 0,
            "debito": monto_pago if es_debito else 0,
            "credito": monto_pago if es_credito else 0,
            "transferencia": monto_pago if es_transferencia else 0,
            "promo": r["promo"],
            "usuario": r["usuario"],
            "medio_pago": r["medio_pago"]
        })

    return out

def fetch_venta_detalle(venta_id:int):

    init_db()

    with connect() as con:

        rows = con.execute("""

            SELECT
                codigo,
                producto,
                cantidad,
                precio,
                valor,
                COALESCE(kg,0) as kg

            FROM venta_items
            WHERE venta_id=?
            ORDER BY id ASC

        """,(venta_id,)).fetchall()

    return [dict(r) for r in rows]

def find_venta_id_by_barcode(barcode:str):

    init_db()

    with connect() as con:

        row = con.execute("""

            SELECT venta_id
            FROM venta_items
            WHERE codigo=?
            ORDER BY id DESC
            LIMIT 1

        """,(barcode,)).fetchone()

        if not row:
            return None

        return int(row["venta_id"])

def update_venta_pago(*,venta_id:int,medio_pago:str,promo:int):

    init_db()

    with connect() as con:

        con.execute("""

            UPDATE ventas
            SET medio_pago=?,
                promo=?
            WHERE id=?

        """,(medio_pago,promo,venta_id))

        con.commit()

def update_venta_resumen_fields(venta_id: int, medio_pago: str, fecha: str, usuario: str):
    init_db()

    with connect() as con:
        con.execute("""
            UPDATE ventas
            SET medio_pago = ?, fecha = ?, usuario = ?
            WHERE id = ?
        """, (medio_pago, fecha, usuario, int(venta_id)))
        con.commit()

def seed_quick_codes():
    init_db()

    rows = [
        ("11", "Bolsa Chica", "Bolsa", "Accesorios", "General", 100, 0, 1),
        ("22", "Bolsa Mediana", "Bolsa", "Accesorios", "General", 200, 0, 1),
        ("33", "Bolsa Grande", "Bolsa", "Accesorios", "General", 300, 0, 1),

        ("101", "S.Hand Ropa", "Ropa", "Ropa", "General", 0, 0, 1),
        ("102", "S.Hand Calzado", "Calzado", "Calzado", "General", 0, 0, 1),
        ("103", "Retorno Hogar", "Hogar", "Hogar", "General", 0, 0, 1),
        ("104", "S.Hand Accesorio", "Accesorio", "Accesorios", "General", 0, 0, 1),
    ]

    with connect() as con:
        con.executemany("""
            INSERT INTO quick_codes(
                codigo, descripcion, producto_base, categoria, genero, precio, kg, activo
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (codigo) DO NOTHING
        """, rows)
    con.commit()

def fetch_quick_code(codigo: str):
    init_db()
    codigo = (codigo or "").strip()

    with connect() as con:
        row = con.execute("""
            SELECT
                codigo,
                descripcion,
                producto_base,
                categoria,
                genero,
                precio,
                kg,
                activo
            FROM quick_codes
            WHERE codigo = ?
              AND activo = 1
            LIMIT 1
        """, (codigo,)).fetchone()

        return dict(row) if row else None

def get_bolsas():

    with connect() as con:

        rows = con.execute("""

            SELECT codigo, descripcion, precio
            FROM quick_codes
            WHERE producto_base='Bolsa'
            ORDER BY codigo

        """).fetchall()

        return [dict(r) for r in rows]

def update_quick_price(codigo, precio):

    with connect() as con:

        con.execute("""

            UPDATE quick_codes
            SET precio=?
            WHERE codigo=?

        """, (precio, codigo))

        con.commit()

def get_boleta_config() -> dict:
    with connect() as con:
        row = con.execute("SELECT * FROM boleta_config WHERE id=1").fetchone()
        return dict(row) if row else {}

def save_boleta_config(
    *,
    titulo_negocio: str,
    razon_social: str,
    rut: str,
    direccion: str,
    giro: str = "",
    telefono: str = "",
    email: str = "",
    mensaje_cambio_1: str = "",
    mensaje_cambio_2: str = "",
):
    with connect() as con:
        con.execute("""
            UPDATE boleta_config
            SET titulo_negocio=?,
                razon_social=?,
                rut=?,
                direccion=?,
                giro=?,
                telefono=?,
                email=?,
                mensaje_cambio_1=?,
                mensaje_cambio_2=?,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=1
        """, (
            titulo_negocio,
            razon_social,
            rut,
            direccion,
            giro,
            telefono,
            email,
            mensaje_cambio_1,
            mensaje_cambio_2,
        ))
        con.commit()

def get_boleta_layout():
    with connect() as con:
        row = con.execute(
            "SELECT * FROM boleta_layout_config WHERE id=1"
        ).fetchone()
        return dict(row) if row else {}


def save_boleta_layout(data: dict):
    with connect() as con:
        con.execute("""
        UPDATE boleta_layout_config
        SET
            header_align=?,
            header_width=?,
            header_height=?,

            empresa_width=?,
            empresa_height=?,

            rut_width=?,
            rut_height=?,

            direccion_width=?,
            direccion_height=?,

            item_spacing=?,

            footer_align=?,
            footer_width=?,
            footer_height=?,

            footer_msg1=?,
            footer_msg2=?
        WHERE id=1
        """, (
            data["header_align"],
            data["header_width"],
            data["header_height"],

            data["empresa_width"],
            data["empresa_height"],

            data["rut_width"],
            data["rut_height"],

            data["direccion_width"],
            data["direccion_height"],

            data["item_spacing"],

            data["footer_align"],
            data["footer_width"],
            data["footer_height"],

            data["footer_msg1"],
            data["footer_msg2"],
        ))

        con.commit()

def save_hoja_entrada(data: dict):
    init_db()

    sql = """
        INSERT INTO hoja_entradas (
            numero, fecha, sucursal_destino, sucursal_origen,
            accion, usuario, estado, saco_codigo,
            production_no, nota
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    params = (
        data.get("numero"),
        data.get("fecha"),
        data.get("sucursal_destino"),
        data.get("sucursal_origen"),
        data.get("accion"),
        data.get("usuario"),
        data.get("estado"),
        data.get("saco_codigo"),
        data.get("production_no"),
        data.get("nota"),
    )

    with connect() as con:
        con.execute(sql, params)
        con.commit()

def save_labels_to_db(rows: List[Dict[str, Any]]) -> None:
    """
    Preview edilmiş label'ları DB'ye kalıcı kaydeder.
    """
    init_db()

    if not rows:
        return

    with connect() as con:
        for row in rows:
            con.execute("""
                INSERT INTO labels(
                    barcode, saco_codigo, saco_kg, genero, categoria, producto, talla,
                    precio, kg, descripcion, prefix, production_no
                )
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                row.get("barcode", ""),
                row.get("saco_codigo", ""),
                int(row.get("saco_kg", 0) or 0),
                row.get("genero", ""),
                row.get("categoria", ""),
                row.get("producto", ""),
                row.get("talla", "-"),
                int(row.get("precio", 0) or 0),
                float(row.get("kg", 0) or 0),
                row.get("descripcion", ""),
                row.get("prefix", ""),
                row.get("production_no", ""),
            ))

        con.commit()

def get_hoja_entrada(numero: str):
    with connect() as con:
        row = con.execute("""
        SELECT * FROM hoja_entradas WHERE numero = ?
        """, (numero,)).fetchone()
        return dict(row) if row else None

def get_hoja_entrada_by_production_no(production_no: str):
    init_db()
    with connect() as con:
        row = con.execute("""
            SELECT *
            FROM hoja_entradas
            WHERE production_no = %s
            ORDER BY id DESC
            LIMIT 1
        """, (production_no,)).fetchone()
        return dict(row) if row else None

def update_hoja_entrada(numero: str, data: dict):
    with connect() as con:
        con.execute("""
        UPDATE hoja_entradas SET
            fecha = ?,
            sucursal_destino = ?,
            sucursal_origen = ?,
            accion = ?,
            usuario = ?,
            estado = ?,
            saco_codigo = ?,
            production_no = ?,
            nota = ?
        WHERE numero = ?
        """, (
            data.get("fecha"),
            data.get("sucursal_destino"),
            data.get("sucursal_origen"),
            data.get("accion"),
            data.get("usuario"),
            data.get("estado"),
            data.get("saco_codigo"),
            data.get("production_no"),
            data.get("nota"),
            numero
        ))
   
def sync_productions_to_hoja_entradas():
    with connect() as con:
        rows = con.execute("""
            SELECT
                ps.production_no,
                ps.created_at,
                ps.usuario,
                ps.status,
                COALESCE(s.nombre, '') AS sucursal_nombre,
                COALESCE(MAX(l.saco_codigo), '') AS saco_codigo
            FROM production_sessions ps
            LEFT JOIN labels l
                ON l.production_no = ps.production_no
            LEFT JOIN sucursales s
                ON s.id = ps.sucursal_id
            GROUP BY
                ps.production_no, ps.created_at, ps.usuario, ps.status, s.nombre
            ORDER BY
                ps.id ASC
        """).fetchall()

        for r in rows:
            production_no = str(r["production_no"] or "").strip()
            if not production_no:
                continue

            exists = con.execute("""
                SELECT 1
                FROM hoja_entradas
                WHERE numero = ?
                   OR production_no = ?
                LIMIT 1
            """, (production_no, production_no)).fetchone()

            if exists:
                continue

            fecha = str(r["created_at"] or "").strip()
            fecha_only = fecha.split(" ")[0] if fecha else ""

            con.execute("""
                INSERT INTO hoja_entradas (
                    numero,
                    fecha,
                    sucursal_destino,
                    sucursal_origen,
                    accion,
                    usuario,
                    estado,
                    saco_codigo,
                    production_no,
                    nota
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                production_no,
                fecha_only,
                str(r["sucursal_nombre"] or "").strip(),
                "",
                "PRODUCCIÓN",
                str(r["usuario"] or "").strip(),
                str(r["status"] or "ABIERTO").strip(),
                str(r["saco_codigo"] or "").strip(),
                production_no,
                ""
            ))

def delete_hoja_entrada(numero: str):
    init_db()

    with connect() as con:
        row = con.execute("""
            SELECT *
            FROM hoja_entradas
            WHERE numero = ?
            LIMIT 1
        """, (numero,)).fetchone()

        if not row:
            return False

        row = dict(row)
        production_no = str(row.get("production_no") or "").strip()
        accion = str(row.get("accion") or "").strip().upper()

        # 1. Hoja sil
        con.execute("""
            DELETE FROM hoja_entradas
            WHERE numero = ?
        """, (numero,))

        # 2. Eğer PRODUCCIÓN ise production da sil
        if accion == "PRODUCCIÓN" and production_no:
            con.execute("""
                DELETE FROM labels
                WHERE production_no = ?
            """, (production_no,))

            con.execute("""
                DELETE FROM stock_batches
                WHERE id6 = ?
            """, (production_no,))

            con.execute("""
                DELETE FROM stock_batch_lines
                WHERE batch_id6 = ?
            """, (production_no,))

        con.commit()
        return True

def ensure_hoja_entrada_for_production(production_no: str):
    """
    Bir production için otomatik hoja_entrada oluşturur.
    Zaten varsa tekrar oluşturmaz.
    """
    init_db()

    production_no = str(production_no or "").strip()
    if not production_no:
        raise RuntimeError("production_no vacío")

    with connect() as con:
        # Var mı?
        existing = con.execute("""
            SELECT *
            FROM hoja_entradas
            WHERE production_no = %s
            LIMIT 1
        """, (production_no,)).fetchone()

        if existing:
            return dict(existing)

        # Stock batch bilgisini al
        row = con.execute("""
            SELECT
                sb.id6,
                sb.created_at,
                sb.saco_codigo,
                sb.categoria,
                sb.genero,
                sb.usuario,
                sb.sucursal_id,
                COALESCE(s.nombre, '') AS sucursal_nombre
            FROM stock_batches sb
            LEFT JOIN sucursales s
                ON s.id = sb.sucursal_id
            WHERE sb.id6 = %s
            LIMIT 1
        """, (production_no,)).fetchone()

        if not row:
            raise RuntimeError(f"No existe stock_batch para production_no={production_no}")

        row = dict(row)

        fecha_txt = ""
        created_at = str(row.get("created_at") or "").strip()
        if created_at:
            fecha_txt = created_at.split(" ")[0].strip()

        data = {
            "numero": production_no,
            "fecha": fecha_txt,
            "sucursal_destino": row.get("sucursal_nombre", "") or "",
            "sucursal_origen": "",
            "accion": "PRODUCCIÓN",
            "usuario": row.get("usuario", "") or "",
            "estado": "",
            "saco_codigo": row.get("saco_codigo", "") or "",
            "production_no": production_no,
            "nota": "",
        }

        save_hoja_entrada(data)
        return data

def get_last_hoja_entrada():
    init_db()
    with connect() as con:
        row = con.execute("""
            SELECT *
            FROM hoja_entradas
            ORDER BY id DESC
            LIMIT 1
        """).fetchone()
        return dict(row) if row else None


def get_next_hoja_entrada_numero():
    """
    Yeni hoja numarası üretir.
    Production session oluşturmaz.
    """
    init_db()

    with connect() as con:
        # hoja_entradas içindeki en son numero
        row_h = con.execute("""
            SELECT numero
            FROM hoja_entradas
            WHERE COALESCE(numero, '') <> ''
            ORDER BY id DESC
            LIMIT 1
        """).fetchone()

        # stock_batches / production tarafındaki en son id6
        row_p = con.execute("""
            SELECT id6
            FROM stock_batches
            WHERE COALESCE(id6, '') <> ''
            ORDER BY id DESC
            LIMIT 1
        """).fetchone()

        nums = []

        for row in (row_h, row_p):
            if row:
                try:
                    val = row["numero"] if isinstance(row, dict) and "numero" in row else (
                        row["id6"] if isinstance(row, dict) and "id6" in row else row[0]
                    )
                    if val:
                        nums.append(int(str(val)))
                except Exception:
                    pass

        next_num = (max(nums) + 1) if nums else 1
        return str(next_num).zfill(6)