from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import psycopg2
from psycopg2.extras import RealDictCursor

app = FastAPI()


def get_conn():
    return psycopg2.connect(
        host="localhost",
        database="vr9_db",
        user="postgres",
        password="2846",
        port=5432
    )


class DiscountRequest(BaseModel):
    barcode: str
    desc_pct: float
    updated_by: str = "mobile_app"


@app.get("/")
def root():
    return {"status": "ok", "message": "VR9 API çalışıyor"}


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/producto/{barcode}")
def get_producto(barcode: str):
    con = get_conn()
    cur = con.cursor(cursor_factory=RealDictCursor)

    cur.execute("""
        SELECT
            sbl.barcode,
            sbl.descripcion,
            sbl.precio,
            sbl.desc_pct,
            sbl.desc_val,
            sbl.desc_final_price,
            sbl.desc_active,
            l.created_at AS fecha_produccion
        FROM stock_batch_lines sbl
        LEFT JOIN labels l
            ON l.barcode = sbl.barcode
        WHERE sbl.barcode = %s
        LIMIT 1
    """, (barcode,))

    row = cur.fetchone()

    cur.close()
    con.close()

    if not row:
        return {"status": "not_found"}

    precio = int(row["precio"] or 0)
    desc_pct = float(row["desc_pct"] or 0)
    desc_val = int(row["desc_val"] or 0)
    desc_final_price = row["desc_final_price"]
    desc_active = bool(row["desc_active"] or False)

    if desc_active and desc_final_price is not None:
        precio_venta = int(desc_final_price)
    else:
        precio_venta = precio

    return {
        "status": "ok",
        "barcode": row["barcode"],
        "nombre": row["descripcion"],
        "precio": precio,
        "desc_pct": desc_pct,
        "desc_val": desc_val,
        "desc_final_price": int(desc_final_price) if desc_final_price is not None else None,
        "desc_active": desc_active,
        "precio_venta": precio_venta,
        "fecha_produccion": str(row["fecha_produccion"]) if row["fecha_produccion"] else Nonee
    }

@app.post("/discount")
def apply_discount(data: DiscountRequest):
    barcode = (data.barcode or "").strip()
    desc_pct = float(data.desc_pct or 0)
    updated_by = (data.updated_by or "mobile_app").strip()

    if not barcode:
        raise HTTPException(status_code=400, detail="barcode zorunlu")

    if desc_pct < 0 or desc_pct > 100:
        raise HTTPException(status_code=400, detail="desc_pct 0 ile 100 arasında olmalı")

    con = get_conn()
    cur = con.cursor(cursor_factory=RealDictCursor)

    try:
        cur.execute("""
            SELECT barcode, descripcion, precio
            FROM stock_batch_lines
            WHERE barcode = %s
            LIMIT 1
        """, (barcode,))
        row = cur.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Ürün bulunamadı")

        precio = int(row["precio"] or 0)

        # %0 ise indirimi kaldır
        if desc_pct == 0:
            cur.execute("""
                UPDATE stock_batch_lines
                SET
                    desc_pct = 0,
                    desc_val = 0,
                    desc_final_price = NULL,
                    desc_active = FALSE,
                    desc_updated_at = NOW(),
                    desc_updated_by = %s
                WHERE barcode = %s
            """, (updated_by, barcode))

            con.commit()

            return {
                "status": "ok",
                "barcode": barcode,
                "nombre": row["descripcion"],
                "precio_original": precio,
                "desc_pct": 0,
                "desc_val": 0,
                "desc_final_price": None,
                "desc_active": False,
                "updated_by": updated_by
            }

        # normal indirim uygula
        desc_val = round(precio * (desc_pct / 100.0))
        desc_final_price = max(precio - desc_val, 0)

        cur.execute("""
            UPDATE stock_batch_lines
            SET
                desc_pct = %s,
                desc_val = %s,
                desc_final_price = %s,
                desc_active = TRUE,
                desc_updated_at = NOW(),
                desc_updated_by = %s
            WHERE barcode = %s
        """, (
            desc_pct,
            desc_val,
            desc_final_price,
            updated_by,
            barcode
        ))

        con.commit()

        return {
            "status": "ok",
            "barcode": barcode,
            "nombre": row["descripcion"],
            "precio_original": precio,
            "desc_pct": desc_pct,
            "desc_val": desc_val,
            "desc_final_price": desc_final_price,
            "desc_active": True,
            "updated_by": updated_by
        }

    except HTTPException:
        con.rollback()
        raise
    except Exception as e:
        con.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        con.close()

@app.post("/discount/remove/{barcode}")
def remove_discount(barcode: str, updated_by: str = "mobile_app"):
    barcode = (barcode or "").strip()
    updated_by = (updated_by or "mobile_app").strip()

    if not barcode:
        raise HTTPException(status_code=400, detail="barcode zorunlu")

    con = get_conn()
    cur = con.cursor(cursor_factory=RealDictCursor)

    try:
        cur.execute("""
            SELECT barcode, descripcion, precio
            FROM stock_batch_lines
            WHERE barcode = %s
            LIMIT 1
        """, (barcode,))
        row = cur.fetchone()

        if not row:
            raise HTTPException(status_code=404, detail="Ürün bulunamadı")

        cur.execute("""
            UPDATE stock_batch_lines
            SET
                desc_pct = 0,
                desc_val = 0,
                desc_final_price = NULL,
                desc_active = FALSE,
                desc_updated_at = NOW(),
                desc_updated_by = %s
            WHERE barcode = %s
        """, (updated_by, barcode))

        con.commit()

        return {
            "status": "ok",
            "barcode": barcode,
            "nombre": row["descripcion"],
            "precio_original": int(row["precio"] or 0),
            "desc_pct": 0,
            "desc_val": 0,
            "desc_final_price": None,
            "desc_active": False,
            "updated_by": updated_by
        }

    except HTTPException:
        con.rollback()
        raise
    except Exception as e:
        con.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close()
        con.close()

@app.post("/login/pin")
def login_pin(data: dict):
    pin = (data.get("pin") or "").strip()

    if not pin:
        return {"status": "error", "message": "PIN vacío"}

    con = get_conn()
    cur = con.cursor(cursor_factory=RealDictCursor)

    cur.execute("""
        SELECT id, nombre, sucursal_id
        FROM usuarios
        WHERE pin_code = %s
          AND pin_active = TRUE
        LIMIT 1
    """, (pin,))

    row = cur.fetchone()

    cur.close()
    con.close()

    if not row:
        return {"status": "error", "message": "PIN inválido"}

    return {
        "status": "ok",
        "user_id": row["id"],
        "nombre": row["nombre"],
        "sucursal_id": row["sucursal_id"]
    }