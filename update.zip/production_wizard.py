# production_wizard.py
# VR9 - Production Wizard (Touch UI)
# - Steps: Sucursal -> Saco -> Categoría -> Género -> Producto -> Talla -> Precio -> Detalle
# - Bottom Excel-like tabs (QTabBar)
# - Detalle page: checkbox list, reprint/delete, Guardar Saco (stock save) + clear + back to Saco
from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
import subprocess

# ---- Prefer PySide6, fallback to PyQt6, then PyQt5 ----
QT_LIB = None
try:
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
        QLabel, QPushButton, QListWidget, QListWidgetItem,
        QStackedWidget, QMessageBox, QFrame, QSpinBox, QLineEdit,
        QTabBar, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
        QAbstractItemView, QScrollArea, QDialog
    )
    QT_LIB = "pyside6"
    QT6 = True
except Exception:
    try:
        from PyQt6.QtCore import Qt, QTimer
        from PyQt6.QtGui import QFont
        from PyQt6.QtWidgets import (
            QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
            QLabel, QPushButton, QListWidget, QListWidgetItem,
            QStackedWidget, QMessageBox, QFrame, QSpinBox, QLineEdit,
            QTabBar, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
            QAbstractItemView, QScrollArea, QDialog
        )
        QT_LIB = "pyqt6"
        QT6 = True
    except Exception:
        from PyQt5.QtCore import Qt, QTimer
        from PyQt5.QtGui import QFont
        from PyQt5.QtWidgets import (
            QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
            QLabel, QPushButton, QListWidget, QListWidgetItem,
            QStackedWidget, QMessageBox, QFrame, QSpinBox, QLineEdit,
            QTabBar, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView,
            QAbstractItemView, QScrollArea, QDialog
        )
        QT_LIB = "pyqt5"
        QT6 = False

import db  # your db.py
from print_engine import print_label, build_label_preview_pixmap

# ----------------------------
# Helpers
# ----------------------------
def _norm(s: str) -> str:
    return (s or "").strip()

def _fmt_clp(n: int) -> str:
    try:
        n = int(n)
    except Exception:
        n = 0
    return f"{n:,}".replace(",", ".")

def _parse_kg_input(text: str) -> float:
    s = (text or "").strip().replace(",", ".")
    if not s:
        return 0.0

    try:
        v = float(s)
    except Exception:
        return -1.0

    # Kullanıcı 59 yazarsa -> 0.59
    # 120 yazarsa -> 1.20
    # 0.59 yazarsa aynen kalır
    if "." not in s and v >= 10:
        v = v / 100.0

    return round(v, 3)

def _is_hogar(cat: str) -> bool:
    return _norm(cat).lower() == "hogar"

def _qt_align_left():
    return Qt.AlignmentFlag.AlignLeft if QT6 else Qt.AlignLeft

def _qt_user_role():
    return Qt.ItemDataRole.UserRole if QT6 else Qt.UserRole


# ----------------------------
# Stock DB helpers (local, safe)
# ----------------------------
def _ensure_stock_tables():
    con = db.connect() if hasattr(db, "connect") else None
    if con is None:
        return

    try:
        con.execute("""
            CREATE TABLE IF NOT EXISTS stock_batches (
                id6 TEXT PRIMARY KEY,
                created_at TIMESTAMP NOT NULL,
                sucursal_id INTEGER,
                saco_codigo TEXT,
                categoria TEXT,
                genero TEXT,
                usuario TEXT
            )
        """)

        con.execute("""
            CREATE TABLE IF NOT EXISTS stock_batch_lines (
                id SERIAL PRIMARY KEY,
                batch_id6 TEXT NOT NULL,
                barcode TEXT NOT NULL,
                producto TEXT,
                genero TEXT,
                descripcion TEXT,
                precio INTEGER NOT NULL,
                FOREIGN KEY(batch_id6) REFERENCES stock_batches(id6) ON DELETE CASCADE
            )
        """)

        con.commit()
    finally:
        con.close()

def _new_id6() -> str:
    return datetime.now().strftime("%H%M%S")

def _save_stock_batch(
    id6: str,
    sucursal_id: int,
    saco_codigo: str,
    categoria: str,
    genero: str,
    usuario: str,
    rows: List[Dict[str, Any]],
) -> None:
    _ensure_stock_tables()
    con = db.connect() if hasattr(db, "connect") else None
    if con is None:
        raise RuntimeError("DB connection not available")

    try:
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        tries = 0
        while True:
            row = con.execute(
                "SELECT id6 FROM stock_batches WHERE id6=?",
                (id6,)
            ).fetchone()

            if row is None:
                break

            tries += 1
            if tries > 50:
                raise RuntimeError("No se pudo generar ID único (6 dígitos).")

            id6 = str(int(id6) + tries).zfill(6)[-6:]

        con.execute(
            """
            INSERT INTO stock_batches(
                id6, created_at, sucursal_id, saco_codigo, categoria, genero, usuario
            )
            VALUES(?,?,?,?,?,?,?)
            """,
            (id6, created_at, sucursal_id, saco_codigo, categoria, genero, usuario),
        )

        for r in rows:
            con.execute(
                """
                INSERT INTO stock_batch_lines(
                    batch_id6, barcode, producto, genero, descripcion, precio
                )
                VALUES(?,?,?,?,?,?)
                """,
                (
                    id6,
                    str(r.get("barcode", "")),
                    str(r.get("producto", "")),
                    str(r.get("genero", "")),
                    str(r.get("descripcion", "")),
                    int(r.get("precio", 0) or 0),
                )
            )

        con.commit()
    finally:
        con.close()

class PrintPreviewDialog(QDialog):
    def __init__(self, parent=None, labels: Optional[List[Dict[str, Any]]] = None):
        super().__init__(parent)
        self.setWindowTitle("Vista previa de impresión")
        self.resize(760, 520)

        self.labels = labels or []
        self.approved = False

        root = QVBoxLayout(self)
        root.setSpacing(0)

        title = QLabel("Vista previa antes de imprimir")
        title.setStyleSheet("font-size:18px; font-weight:900; color:#111827;")
        root.addWidget(title)

        info = QLabel(
            "Revisa la información antes de enviar a impresión.\n"
            "Si necesitas ajustar tamaño / gap / media, abre preferencias de impresora."
        )
        info.setWordWrap(True)
        info.setStyleSheet("font-size:14px; font-weight:700; color:#475569;")
        root.addWidget(info)

        self.preview_label = QLabel()
        self.preview_label.setAlignment(Qt.AlignCenter if QT6 else Qt.AlignCenter)
        self.preview_label.setMinimumHeight(160)
        self.preview_label.setStyleSheet("""
            background:#f8fafc;
            border:1px solid #e5e7eb;
            border-radius:14px;
            padding:12px;
        """)
        root.addWidget(self.preview_label, 1)

        self.current_index = 0

        nav_row = QHBoxLayout()
        self.btn_prev = QPushButton("⬅ Anterior")
        self.btn_next = QPushButton("Siguiente ➜")

        self.btn_prev.clicked.connect(self.show_prev)
        self.btn_next.clicked.connect(self.show_next)

        nav_row.addStretch(1)
        nav_row.addWidget(self.btn_prev)
        nav_row.addWidget(self.btn_next)
        nav_row.addStretch(1)

        root.addLayout(nav_row)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(10)

        self.btn_printer = QPushButton("🖨 Preferencias de impresora")
        self.btn_print = QPushButton("✅ Imprimir")
        self.btn_cancel = QPushButton("❌ Cancelar")

        self.btn_print.setObjectName("Primary")

        self.btn_printer.clicked.connect(self.open_default_printer_preferences)
        self.btn_print.clicked.connect(self.accept_print)
        self.btn_cancel.clicked.connect(self.reject)

        btn_row.addWidget(self.btn_printer)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_cancel)
        btn_row.addWidget(self.btn_print)

        root.addLayout(btn_row)

        self.setStyleSheet("""
            QDialog {
                background:#ffffff;
            }
            QLabel {
                color:#0f172a;
            }
            QTableWidget {
                border:1px solid #e5e7eb;
                border-radius:14px;
                font-size:14px;
                background:#ffffff;
            }
            QHeaderView::section {
                background:#f8fafc;
                padding:8px;
                font-weight:900;
                border:0px;
                border-bottom:1px solid #e5e7eb;
            }
            QPushButton {
                min-height:40px;
                padding:8px 14px;
                font-size:14px;
                font-weight:900;
                border-radius:12px;
                border:1px solid #d1d5db;
                background:#f8fafc;
            }
            QPushButton#Primary {
                background:#2563eb;
                color:white;
                border:1px solid #2563eb;
            }
        """)

        self.load_data()

    def load_data(self):
        self.show_preview()

    def show_preview(self):
        if not self.labels:
            self.preview_label.setText("No hay etiquetas para vista previa.")
            return

        row = self.labels[self.current_index]

        preview_row = {
            "barcode": row.get("barcode", ""),
            "saco": row.get("saco_codigo", ""),
            "fecha": datetime.now().strftime("%d/%m/%Y"),
            "talla": row.get("talla", ""),
            "kg": row.get("kg", 0),
            "descripcion": row.get("descripcion", ""),
            "precio": _fmt_clp(int(row.get("precio", 0) or 0)),
            "production_no": row.get("production_no", ""),
        }

        pix = build_label_preview_pixmap(preview_row)
        scaled = pix.scaled(
            260, 600,
            Qt.KeepAspectRatio if QT6 else Qt.KeepAspectRatio,
            Qt.SmoothTransformation if QT6 else Qt.SmoothTransformation
        )
        self.preview_label.setPixmap(scaled)

        self.btn_prev.setEnabled(self.current_index > 0)
        self.btn_next.setEnabled(self.current_index < len(self.labels) - 1)

    def show_prev(self):
        if self.current_index > 0:
            self.current_index -= 1
            self.show_preview()

    def show_next(self):
        if self.current_index < len(self.labels) - 1:
            self.current_index += 1
            self.show_preview()
 
    def open_default_printer_preferences(self):
        try:
            import win32print

            printer_name = win32print.GetDefaultPrinter()
            if not printer_name:
                QMessageBox.warning(self, "Impresora", "No hay impresora predeterminada en Windows.")
                return

            subprocess.Popen([
                "rundll32",
                "printui.dll,PrintUIEntry",
                "/e",
                "/n",
                printer_name
            ])

        except Exception as e:
            QMessageBox.warning(self, "Impresora", f"No se pudo abrir preferencias de impresora:\n{e}")

    def accept_print(self):
        self.approved = True
        self.accept()

# ----------------------------
# Main Wizard
# ----------------------------
class ProductionWizard(QWidget):
    """
    Touch-friendly wizard for label production.
    """

    def __init__(self, parent: Optional[QWidget] = None, usuario: str = ""):
        super().__init__(parent)

        self.data: Dict[str, Any] = {
            "sucursal_id": None,
            "sucursal_nombre": "",
            "saco": "",
            "saco_kg": 0,
            "precio_saco": 0,
            "genero": "",
            "categoria": "",
            "producto": "",
            "talla": "",
            "precio": 0,
            "qty": 1,
            "descripcion": "",
            "con_detalle": False,
        }

        self.current_labels: List[Dict[str, Any]] = []
        self.production_no = ""
        self.usuario = (usuario or "").strip()

        self.tallas_ropa = ["-", "XS", "S", "M", "L", "XL", "XXL", "3XL", "4XL"]
        self.tallas_calzado = [str(n) for n in range(30, 50)]
        self.tallas_sin = ["-"]

        # ✅ Grid selections
        self.selected_categoria = ""
        self.selected_genero = ""
        self.selected_producto = ""

        # ---- Root layout ----
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.card = QFrame()
        self.card.setObjectName("Card")
        card_layout = QVBoxLayout(self.card)
        card_layout.setContentsMargins(8, 8, 8, 6)
        card_layout.setSpacing(4)
        root.addWidget(self.card, 1)

        self.header_row = QHBoxLayout()
        self.header_row.setSpacing(12)

        self.lbl_step = QLabel("")
        self.lbl_step.setObjectName("StepTitle")

        self.lbl_production_no = QLabel("")
        self.lbl_production_no.setStyleSheet("""
            font-size:14px;
            font-weight:900;
            color:#475569;
            padding-top: 4px;
        """)
        self.lbl_production_no.setAlignment(Qt.AlignmentFlag.AlignRight if QT6 else Qt.AlignRight)

        self.header_row.addWidget(self.lbl_step, 1)
        self.header_row.addWidget(self.lbl_production_no, 0)

        card_layout.addLayout(self.header_row)

        self.lbl_status = QLabel("")
        self.lbl_status.setObjectName("StatusToast")
        self.lbl_status.setVisible(False)
        self.lbl_status.setWordWrap(True)
        card_layout.addWidget(self.lbl_status)

        self.stack = QStackedWidget()
        card_layout.addWidget(self.stack, 1)

        footer = QVBoxLayout()
        footer.setSpacing(4)
        card_layout.addLayout(footer)

        nav_row = QHBoxLayout()
        nav_row.setSpacing(6)

        self.btn_back = QPushButton("⬅ ATRÁS")
        self.btn_next = QPushButton("CONTINUAR ➜")
        self.btn_back.setMinimumHeight(34)
        self.btn_next.setMinimumHeight(34)
        self.btn_back.clicked.connect(self.go_back)
        self.btn_next.clicked.connect(self.go_next)

        self.btn_generate_nav = QPushButton("✅ GENERAR")
        self.btn_generate_nav.setMinimumHeight(34)
        self.btn_generate_nav.setObjectName("Primary")
        self.btn_generate_nav.clicked.connect(self.generate_labels)

        nav_row.addWidget(self.btn_back, 0)
        nav_row.addStretch(1)
        nav_row.addWidget(self.btn_generate_nav, 0)
        nav_row.addWidget(self.btn_next, 0)
        footer.addLayout(nav_row)

        self.tabs = QTabBar()
        self.tabs.setObjectName("Tabs")
        self.tabs.setExpanding(True)
        self.tabs.setMovable(False)
        self.tabs.setUsesScrollButtons(False)
        self.tabs.setDrawBase(True)
        self.tabs.setMinimumHeight(28)

        for name in ["Sucursal", "Saco", "Categoría", "Género", "Producto", "Talla", "Precio", "Detalle"]:
            self.tabs.addTab(name)

        self.tabs.currentChanged.connect(self.on_tab_clicked)
        footer.addWidget(self.tabs)

        # ---- Pages ----
        self.page_sucursal = self._build_page_sucursal()
        self.page_saco = self._build_page_saco()
        self.page_categoria = self._build_page_categoria() # ✅ grid
        self.page_genero = self._build_page_genero()       # ✅ grid
        self.page_producto = self._build_page_producto()   # ✅ grid
        self.page_talla = self._build_page_talla()
        self.page_precio = self._build_page_precio_qty()
        self.page_detalle = self._build_page_detalle()

        self.stack.addWidget(self.page_sucursal)
        self.stack.addWidget(self.page_saco)
        self.stack.addWidget(self.page_categoria)
        self.stack.addWidget(self.page_genero)
        self.stack.addWidget(self.page_producto)
        self.stack.addWidget(self.page_talla)
        self.stack.addWidget(self.page_precio)
        self.stack.addWidget(self.page_detalle)

        self.steps = [
            ("Selecciona Sucursal", self.page_sucursal),
            ("Selecciona Saco", self.page_saco),
            ("Selecciona Categoría", self.page_categoria),
            ("Selecciona Género", self.page_genero),
            ("Selecciona Producto", self.page_producto),
            ("Selecciona Talla", self.page_talla),
            ("Precio & Cantidad", self.page_precio),
            ("Detalle", self.page_detalle),
        ]
        self.step_index = 0

        self.apply_touch_ui()

        self._refresh_all_lists()
        self._set_step(0)

    def showEvent(self, event):
        super().showEvent(event)

        def _refresh():
            try:
                self.updateGeometry()
                if self.layout():
                    self.layout().activate()
                self.adjustSize()
                self.repaint()
            except Exception as e:
                QMessageBox.warning(self, "Error", str(e))

        QTimer.singleShot(0, _refresh)

    # ----------------------------
    # GRID RENDERERS
    # ----------------------------
    def _clear_grid(self, grid: QGridLayout):
        while grid.count():
            item = grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def _render_tallas_grid(self, tallas: List[str]):
        self._clear_grid(self.talla_grid)
        cols = 5
        row = 0
        col = 0

        for talla in tallas:
            btn = QPushButton(str(talla))
            btn.setFixedSize(160, 130)
            btn.setStyleSheet("font-size:26px; font-weight:900;")
            btn.clicked.connect(lambda _, t=talla: self._select_talla(t))
            self.talla_grid.addWidget(btn, row, col)

            col += 1
            if col >= cols:
                col = 0
                row += 1

    def _render_generos_grid(self, generos: List[str]):
        self._clear_grid(self.genero_grid)

        cols = 3
        row = 0
        col = 0

        for g in generos:
            btn = QPushButton(str(g))
            btn.setCheckable(True)
            btn.setFixedSize(220, 120)
            btn.setObjectName("GeneroSquare")

            def on_click(_, genero=g):
                for i in range(self.genero_grid.count()):
                    w = self.genero_grid.itemAt(i).widget()
                    if isinstance(w, QPushButton) and w.objectName() == "GeneroSquare":
                        w.setChecked(w.text() == genero)

                self.selected_genero = genero
                self.data["genero"] = genero

                # Género seçildikten sonra ürünleri ve tallaları güncelle
                self._load_productos_for_categoria(self.data.get("categoria", ""))
                self.data["talla"] = ""
                self._load_tallas()

                self._set_step(4)

            btn.clicked.connect(on_click)
            self.genero_grid.addWidget(btn, row, col)

            col += 1
            if col >= cols:
                col = 0
                row += 1

    def _render_categorias_grid(self, categorias: List[str]):
        self._clear_grid(self.categoria_grid)

        cols = 2
        row = 0
        col = 0

        for cat in categorias:
            btn = QPushButton(str(cat))
            btn.setCheckable(True)
            btn.setFixedSize(260, 120)
            btn.setObjectName("CategoriaSquare")

            def on_click(_, categoria=cat):
                for i in range(self.categoria_grid.count()):
                    w = self.categoria_grid.itemAt(i).widget()
                    if isinstance(w, QPushButton) and w.objectName() == "CategoriaSquare":
                        w.setChecked(w.text() == categoria)

                self.selected_categoria = categoria
                self.data["categoria"] = categoria

                self._set_step(3)

            btn.clicked.connect(on_click)
            self.categoria_grid.addWidget(btn, row, col)

            col += 1
            if col >= cols:
                col = 0
                row += 1

    def _render_productos_grid(self, productos: List[str]):
        self._clear_grid(self.producto_grid)

        if not productos:
            # placeholder
            lbl = QLabel("— (No hay productos en esta categoría) —")
            lbl.setStyleSheet("color:#64748b; font-weight:900; padding:14px;")
            self.producto_grid.addWidget(lbl, 0, 0)
            return

        cols = 4
        row = 0
        col = 0

        for p in productos:
            btn = QPushButton(str(p))
            btn.setCheckable(True)
            btn.setFixedSize(250, 115)
            btn.setObjectName("ProductoSquare")

            def on_click(_, prod=p):
                for i in range(self.producto_grid.count()):
                    w = self.producto_grid.itemAt(i).widget()
                    if isinstance(w, QPushButton) and w.objectName() == "ProductoSquare":
                        w.setChecked(w.text() == prod)

                self.selected_producto = prod
                self.data["producto"] = prod
                self._set_step(5)

            btn.clicked.connect(on_click)
            self.producto_grid.addWidget(btn, row, col)

            col += 1
            if col >= cols:
                col = 0
                row += 1

    def _select_talla(self, talla):
        self.data["talla"] = str(talla)
        self._set_step(6)

    # ----------------------------
    # UI Styling (Touch)
    # ----------------------------
    def apply_touch_ui(self):
        self.setFont(QFont("Segoe UI", 14))

        self.setStyleSheet("""
            QWidget { color: #0f172a; }
            QLabel#Title {
                font-size: 20px;
                font-weight: 700;
                padding: 6px 0px;
            }
            QFrame#Card {
                background: #ffffff;
                border: 1px solid #e5e7eb;
                border-radius: 18px;
            }
            QCheckBox {
                font-size: 16px;
                font-weight: 800;
                spacing: 8px;
                color: #334155;
            }
            QCheckBox::indicator {
                width: 22px;
                height: 22px;
            }
            QLabel#StepTitle {
                font-size: 18px;
                font-weight: 900;
                color: #111827;
                padding: 0px 0px 2px 0px;
            }
            QPushButton {
                min-height: 40px;
                padding: 8px 14px;
                font-size: 22px;
                font-weight: 900;
                border-radius: 14px;
                border: 1px solid #d1d5db;
                background: #f8fafc;
            }
            QPushButton:hover { background: #eef2ff; }
            QPushButton:pressed { background: #e0e7ff; }

            QPushButton#Primary {
                background: #2563eb;
                color: white;
                border: 1px solid #2563eb;
            }
            QPushButton#Primary:hover { background: #1d4ed8; }

            QLineEdit {
                min-height: 56px;
                padding: 10px 14px;
                font-size: 18px;
                border-radius: 14px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
            }
            QSpinBox {
                min-height: 56px;
                padding: 8px 12px;
                font-size: 18px;
                border-radius: 14px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
            }

            QListWidget {
                border: 1px solid #e5e7eb;
                border-radius: 14px;
                padding: 8px;
                background: #ffffff;
            }
            QListWidget::item {
                min-height: 70px;
                padding: 12px 14px;
                margin: 6px;
                border-radius: 14px;
                background: #f8fafc;
                border: 1px solid #e5e7eb;
                font-size: 24px;
                font-weight: 900;
            }
            QListWidget::item:selected {
                background: #dbeafe;
                border: 2px solid #2563eb;
            }

            QTabBar::tab {
                background: #f8fafc;
                border: 1px solid #dbe4f0;
                padding: 4px 8px;
                min-height: 22px;
                font-size: 11px;
                font-weight: 700;
                color: #475569;
            }
            QTabBar::tab:selected {
                background: #eef4ff;
                color: #1d4ed8;
                border-color: #bfdbfe;
            }

            QTableWidget {
                border: 1px solid #e5e7eb;
                border-radius: 14px;
                font-size: 14px;
            }
            QHeaderView::section {
                background: #f1f5f9;
                font-weight: 900;
                padding: 8px;
                border: 0px;
                border-bottom: 1px solid #e5e7eb;
            }

            QLabel#StatusToast {
                padding: 10px 14px;
                border-radius: 12px;
                font-size: 16px;
                font-weight: 900;
                background: #dcfce7;
                color: #166534;
                border: 1px solid #86efac;
            }

            QPushButton#GeneroSquare, QPushButton#CategoriaSquare, QPushButton#ProductoSquare {
                background: #ffffff;
                border: 2px solid #cbd5e1;
                border-radius: 16px;
                font-weight: 900;
                font-size: 22px;
            }
            QPushButton#GeneroSquare:checked, QPushButton#CategoriaSquare:checked, QPushButton#ProductoSquare:checked {
                background: #1d4ed8;
                border: 2px solid #1d4ed8;
                color: white;
            }
        """)

    # ----------------------------
    # Pages
    # ----------------------------
   
    def _build_page_sucursal(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.sucursal_search = QLineEdit()
        self.sucursal_search.setPlaceholderText("Buscar sucursal...")
        self.sucursal_search.textChanged.connect(self._filter_sucursales)

        top = QHBoxLayout()
        top.setSpacing(4)
        top.addWidget(self.sucursal_search, 1)

        self.btn_refresh_sucursales = QPushButton("🔄 Actualizar")
        self.btn_refresh_sucursales.setFixedWidth(170)
        self.btn_refresh_sucursales.clicked.connect(self._load_sucursales)
        top.addWidget(self.btn_refresh_sucursales, 0)

        lay.addLayout(top)

        self.list_sucursales = QListWidget()
        lay.addWidget(self.list_sucursales, 1)

        hint = QLabel("Tip: Sucursal seçince otomatik ilerler.")
        hint.setStyleSheet("color:#64748b; font-weight:700;")
        lay.addWidget(hint)

        self.list_sucursales.itemClicked.connect(lambda _it: self._auto_next_from_list(0))
        return w

    def _build_page_saco(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.saco_search = QLineEdit()
        self.saco_search.setPlaceholderText("Buscar saco... (ej: QBMC)")
        self.saco_search.textChanged.connect(self._filter_sacos)

        toprow = QHBoxLayout()
        toprow.setSpacing(4)
        toprow.addWidget(self.saco_search, 1)

        self.btn_refresh_sacos = QPushButton("🔄 Actualizar")
        self.btn_refresh_sacos.setFixedWidth(170)
        self.btn_refresh_sacos.clicked.connect(self._load_sacos)
        toprow.addWidget(self.btn_refresh_sacos, 0)

        lay.addLayout(toprow)

        self.list_sacos = QListWidget()
        lay.addWidget(self.list_sacos, 1)

        hint = QLabel("Tip: Saco seçince otomatik ilerler.")
        hint.setStyleSheet("color:#64748b; font-weight:700;")
        lay.addWidget(hint)

        self.list_sacos.itemClicked.connect(lambda _it: self._auto_next_from_list(1))
        return w

    def _build_page_genero(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.genero_scroll = QScrollArea()
        self.genero_scroll.setWidgetResizable(True)
        self.genero_scroll.setFrameShape(QFrame.NoFrame if hasattr(QFrame, "NoFrame") else QFrame.Box)

        inner = QWidget()
        self.genero_grid = QGridLayout(inner)
        self.genero_grid.setContentsMargins(0, 0, 0, 0)
        self.genero_grid.setSpacing(4)

        self.genero_scroll.setWidget(inner)
        lay.addWidget(self.genero_scroll, 1)

        return w

    def _build_page_categoria(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.categoria_scroll = QScrollArea()
        self.categoria_scroll.setWidgetResizable(True)
        self.categoria_scroll.setFrameShape(QFrame.NoFrame if hasattr(QFrame, "NoFrame") else QFrame.Box)

        inner = QWidget()
        self.categoria_grid = QGridLayout(inner)
        self.categoria_grid.setContentsMargins(0, 0, 0, 0)
        self.categoria_grid.setSpacing(4)

        self.categoria_scroll.setWidget(inner)
        lay.addWidget(self.categoria_scroll, 1)

        return w

    def _build_page_producto(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.lbl_producto_info = QLabel("")
        self.lbl_producto_info.setStyleSheet("color:#475569; font-weight:600;")
        self.lbl_producto_info.setWordWrap(True)
        lay.addWidget(self.lbl_producto_info)

        self.producto_scroll = QScrollArea()
        self.producto_scroll.setWidgetResizable(True)
        self.producto_scroll.setFrameShape(QFrame.NoFrame if hasattr(QFrame, "NoFrame") else QFrame.Box)

        inner = QWidget()
        self.producto_grid = QGridLayout(inner)
        self.producto_grid.setContentsMargins(0, 0, 0, 0)
        self.producto_grid.setSpacing(4)

        self.producto_scroll.setWidget(inner)
        lay.addWidget(self.producto_scroll, 1)

        return w

    def _build_page_talla(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.talla_scroll = QScrollArea()
        self.talla_scroll.setWidgetResizable(True)
        self.talla_scroll.setFrameShape(QFrame.NoFrame if hasattr(QFrame, "NoFrame") else QFrame.Box)

        inner = QWidget()
        self.talla_grid = QGridLayout(inner)
        self.talla_grid.setContentsMargins(0, 0, 0, 0)
        self.talla_grid.setSpacing(4)

        self.talla_scroll.setWidget(inner)
        lay.addWidget(self.talla_scroll, 1)

        return w

    def _build_page_precio_qty(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.lbl_summary = QLabel("")
        self.lbl_summary.setStyleSheet("font-size:22px; font-weight:700; color:#0f172a;")
        self.lbl_summary.setWordWrap(True)

        top_row = QHBoxLayout()
        top_row.setSpacing(20)
        top_row.setAlignment(_qt_align_left())

        # Sol blok
        left_box = QVBoxLayout()
        left_box.setSpacing(2)
        left_box.setContentsMargins(0, 0, 0, 0)
        left_box.addWidget(self.lbl_summary)

        # Sağ blok
        right_box = QVBoxLayout()
        right_box.setSpacing(2)
        right_box.setContentsMargins(0, 0, 0, 0)

        self.chk_detalle = QCheckBox("Con Detalle")
        self.chk_detalle.setChecked(False)
        self.chk_detalle.stateChanged.connect(self._con_detalle_changed)

        self.chk_keep_selection = QCheckBox("Mantener selección")
        self.chk_keep_selection.setChecked(False)

        self.chk_preview = QCheckBox("Vista previa antes de imprimir")
        self.chk_preview.setChecked(False)

        right_box.addWidget(self.chk_detalle, 0, _qt_align_left())
        right_box.addWidget(self.chk_keep_selection, 0, _qt_align_left())
        right_box.addWidget(self.chk_preview, 0, _qt_align_left())
        right_box.addStretch(1)

        top_row.addLayout(left_box, 1)
        top_row.addLayout(right_box, 0)

        lay.addLayout(top_row)

        prices_box = QFrame()
        grid = QGridLayout(prices_box)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(4)

        self.quick_prices = [
            499, 599, 699, 799, 899, 999, 1499, 1999,
            2499, 2999, 3499, 3999, 4999, 4499, 5999, 6999,
            7999, 8999, 9999, 10999, 11999, 12999, 13999, 14999,
            15999, 16999, 17999, 18999, 19999, 20999, 21999, 22999,
            23999, 24999, 25999, 26999, 27999, 28999, 29999, 31999
        ]

        cols = 8
        r = 0
        c = 0
        for p in self.quick_prices:
            b = QPushButton(_fmt_clp(p))
            b.setStyleSheet("font-size:14px; font-weight:900;")
            b.clicked.connect(lambda _=False, val=p: self.price_input.setText(str(val)))
            grid.addWidget(b, r, c)
            c += 1
            if c >= cols:
                c = 0
                r += 1

        lay.addWidget(prices_box, 1)

        row2 = QHBoxLayout()
        row2.setSpacing(6)

        lblq = QLabel("Cantidad:")
        lblq.setStyleSheet("font-size:20px; font-weight:800;")
        row2.addWidget(lblq)

        self.qty_input = QSpinBox()
        self.qty_input.setMinimum(1)
        self.qty_input.setMaximum(200)
        self.qty_input.setValue(1)
        self.qty_input.valueChanged.connect(lambda _v: self._update_summary())
        row2.addWidget(self.qty_input)

        lblp2 = QLabel("Precio:")
        lblp2.setStyleSheet("font-size:16px; font-weight:900;")
        row2.addWidget(lblp2)

        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("Ej: 4999")
        self.price_input.setFixedWidth(160)
        self.price_input.textChanged.connect(self._price_changed)
        row2.addWidget(self.price_input)

        btn_clear2 = QPushButton("Borrar")
        btn_clear2.setFixedWidth(100)
        btn_clear2.clicked.connect(lambda: self.price_input.setText(""))
        row2.addWidget(btn_clear2)
  
        lblkg = QLabel("KG:")
        lblkg.setStyleSheet("font-size:16px; font-weight:900;")
        row2.addWidget(lblkg)

        self.kg_input = QLineEdit()
        self.kg_input.setPlaceholderText("Ej: 0.450")
        self.kg_input.setFixedWidth(120)
        row2.addWidget(self.kg_input)

        row2.addStretch(1)
        lay.addLayout(row2)

        return w

    def _build_page_detalle(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(6)

        self.lbl_detalle_top = QLabel("Detalle de etiquetas generadas (selecciona para reimprimir o eliminar).")
        self.lbl_detalle_top.setStyleSheet("font-size:14px; font-weight:900; color:#0f172a;")
        self.lbl_detalle_top.setWordWrap(True)
        lay.addWidget(self.lbl_detalle_top)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(["Sel", "Barcode", "Lote", "Producto", "Género", "Descripción", "Kg", "Precio"])
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.verticalHeader().setVisible(False)

        hh = self.table.horizontalHeader()
        if QT6:
            hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(4, QHeaderView.Stretch)
            hh.setSectionResizeMode(5, QHeaderView.Stretch)
            hh.setSectionResizeMode(6, QHeaderView.Stretch)
            hh.setSectionResizeMode(7, QHeaderView.ResizeToContents)
        else:
            hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
            hh.setSectionResizeMode(4, QHeaderView.Stretch)
            hh.setSectionResizeMode(5, QHeaderView.Stretch)
            hh.setSectionResizeMode(6, QHeaderView.Stretch)
            hh.setSectionResizeMode(7, QHeaderView.ResizeToContents)

        lay.addWidget(self.table, 1)

        self.lbl_total = QLabel("TOTAL: 0")
        self.lbl_total.setStyleSheet("font-size:16px; font-weight:900;")
        lay.addWidget(self.lbl_total)

        self.lbl_saco_precio = QLabel("PRECIO SACO: 0")
        self.lbl_saco_precio.setStyleSheet("font-size:16px; font-weight:900;")
        lay.addWidget(self.lbl_saco_precio)

        self.lbl_brut_kar = QLabel("GANANCIA: 0")
        self.lbl_brut_kar.setStyleSheet("font-size:16px; font-weight:900;")
        lay.addWidget(self.lbl_brut_kar)

        self.lbl_total_kg = QLabel("TOTAL KG: 0")
        self.lbl_total_kg.setStyleSheet("font-size:16px; font-weight:900;")
        lay.addWidget(self.lbl_total_kg)

        self.lbl_diferencia = QLabel("DIFERENCIA: 0")
        self.lbl_diferencia.setStyleSheet("font-size:16px; font-weight:900;")
        lay.addWidget(self.lbl_diferencia)

        row = QHBoxLayout()
        row.setSpacing(6)

        self.btn_reprint = QPushButton("🖨 Reimprimir seleccionados")
        self.btn_delete = QPushButton("🗑 Eliminar seleccionados")
        self.btn_guardar_saco = QPushButton("💾 Guardar Saco")
        self.btn_guardar_saco.setObjectName("Primary")

        self.btn_reprint.clicked.connect(self.reprint_selected)
        self.btn_delete.clicked.connect(self.delete_selected)
        self.btn_guardar_saco.clicked.connect(self.guardar_saco)

        row.addStretch(1)
        row.addWidget(self.btn_reprint)
        row.addWidget(self.btn_delete)
        row.addWidget(self.btn_guardar_saco)
        row.addStretch(1)

        lay.addLayout(row)

        return w

    # ----------------------------
    # Data loading
    # ----------------------------
    def _refresh_all_lists(self):
        self._load_sucursales()
        self._load_sacos()
        self._load_generos()
        self._load_categorias()

        if hasattr(self, "producto_grid"):
            self._clear_grid(self.producto_grid)

        if hasattr(self, "lbl_producto_info"):
            self.lbl_producto_info.setText("")

        self._load_tallas()
        self.list_sucursales.clearSelection()
        self.list_sacos.clearSelection()

    def _load_sucursales(self):
        self._sucursales_cache: List[Dict[str, Any]] = []
        self.list_sucursales.clear()

        try:
            rows = db.list_sucursales(active_only=True) if hasattr(db, "list_sucursales") else []
        except Exception as e:
            QMessageBox.critical(self, "DB", f"list_sucursales error:\n{e}")
            rows = []

        parsed = []
        for r in rows:
            sid = r.get("id")
            codigo = str(r.get("codigo", "")).strip().upper()
            nombre = str(r.get("nombre", "")).strip()
            if sid and codigo:
                parsed.append({
                    "id": int(sid),
                    "codigo": codigo,
                    "nombre": nombre,
                })

        parsed.sort(key=lambda x: (x["codigo"], x["nombre"]))
        self._sucursales_cache = parsed
        self._render_sucursales(parsed)


    def _render_sucursales(self, items: List[Dict[str, Any]]):
        self.list_sucursales.clear()
        for d in items:
            txt = f'{d["codigo"]} | {d["nombre"]}'
            it = QListWidgetItem(txt)
            it.setData(_qt_user_role(), d)
            self.list_sucursales.addItem(it)


    def _filter_sucursales(self):
        q = _norm(self.sucursal_search.text()).upper()
        if not q:
            self._render_sucursales(self._sucursales_cache)
            return

        filtered = [
            x for x in self._sucursales_cache
            if q in x["codigo"].upper() or q in x["nombre"].upper()
        ]
        self._render_sucursales(filtered)

    def _load_sacos(self):
        self._sacos_cache: List[Dict[str, Any]] = []
        self.list_sacos.clear()
        try:
            sacos = db.list_sacos() if hasattr(db, "list_sacos") else []
        except Exception as e:
            QMessageBox.critical(self, "DB", f"list_sacos error:\n{e}")
            sacos = []

        parsed = []
        for s in sacos:
            if isinstance(s, dict):
                code = str(s.get("codigo", "")).strip().upper()
                kg = int(s.get("kg", 0) or 0)
                precio_saco = int(s.get("precio_saco", 0) or 0)
            elif isinstance(s, (list, tuple)) and len(s) >= 1:
                code = str(s[0]).strip().upper()
                kg = int(s[1]) if len(s) > 1 and str(s[1]).isdigit() else 0
                precio_saco = int(s[2]) if len(s) > 2 and str(s[2]).isdigit() else 0
            else:
                code = str(s).strip().upper()
                kg = 0
                precio_saco = 0

            if code:
                parsed.append({"code": code, "kg": kg, "precio_saco": precio_saco})

        parsed.sort(key=lambda x: x["code"])
        self._sacos_cache = parsed
        self._render_sacos(parsed)

    def _render_sacos(self, items: List[Dict[str, Any]]):
        self.list_sacos.clear()
        for d in items:
            code = d["code"]
            kg = d["kg"]
            ps = int(d.get("precio_saco", 0) or 0)
            txt = f"{code} | {kg} kg | ${_fmt_clp(ps)}"

            it = QListWidgetItem(txt)
            it.setData(_qt_user_role(), {"code": code, "kg": kg, "precio_saco": ps})
            self.list_sacos.addItem(it)

    def _filter_sacos(self):
        q = _norm(self.saco_search.text()).upper()
        if not q:
            self._render_sacos(self._sacos_cache)
            return
        filtered = [x for x in self._sacos_cache if q in x["code"]]
        self._render_sacos(filtered)

    def _load_generos(self):
        try:
            gens_raw = db.list_generos() if hasattr(db, "list_generos") else []
        except Exception:
            gens_raw = []

        gens: List[str] = []
        for g in gens_raw:
            if isinstance(g, dict):
                gens.append(str(g.get("nombre", "")).strip())
            else:
                gens.append(str(g).strip())

        gens = [g for g in gens if g and g.lower() != "hogar"]

        order = ["Mujer", "Hombre", "Niña", "Niño", "General"]
        ordered = []
        for o in order:
            if o in gens:
                ordered.append(o)
        for g in gens:
            if g not in ordered:
                ordered.append(g)

        self._render_generos_grid(ordered)

    def _load_categorias(self):
        try:
            cats_raw = db.list_categorias() if hasattr(db, "list_categorias") else []
        except Exception:
            cats_raw = []

        cats: List[str] = []
        for c in cats_raw:
            if isinstance(c, dict):
                cats.append(str(c.get("nombre", "")).strip())
            else:
                cats.append(str(c).strip())

        order = ["Ropa", "Calzado", "Hogar", "Accesorios"]
        ordered = []
        for o in order:
            if o in cats:
                ordered.append(o)
        for c in cats:
            if c not in ordered:
                ordered.append(c)

        self._render_categorias_grid(ordered)

    def _load_productos_for_categoria(self, categoria: str):
        cat = _norm(categoria)
        self.lbl_producto_info.setText(f"Categoría seleccionada: {cat}")

        prods: List[str] = []
        try:
            if hasattr(db, "list_productos_by_categoria"):
                rows = db.list_productos_by_categoria(cat)
                for r in rows:
                    if isinstance(r, dict):
                        prods.append(str(r.get("nombre","")).strip())
                    else:
                        prods.append(str(r).strip())
            else:
                if hasattr(db, "list_productos"):
                    rows = db.list_productos(None)
                    for r in rows:
                        if isinstance(r, dict):
                            if str(r.get("categoria","")).strip().lower() == cat.lower():
                                prods.append(str(r.get("nombre","")).strip())
        except Exception as e:
            QMessageBox.critical(self, "DB", f"Productos error:\n{e}")
            prods = []

        prods = [p for p in prods if p]
        prods.sort(key=lambda x: x.lower())

        # reset product selection on category change
        self.selected_producto = ""
        self.data["producto"] = ""

        self._render_productos_grid(prods)

    def _load_tallas(self):
        cat = (self.data.get("categoria") or "").strip().lower()

        if cat == "calzado":
            tallas = self.tallas_calzado
        elif cat in ["hogar", "accesorios"]:
            tallas = self.tallas_sin
        else:
            tallas = self.tallas_ropa

        self._render_tallas_grid(tallas)

    # ----------------------------
    # Navigation
    # ----------------------------
    def _set_step(self, idx: int):
        self.step_index = max(0, min(idx, len(self.steps) - 1))
        title, widget = self.steps[self.step_index]
        self.lbl_step.setText(title)
        self.stack.setCurrentWidget(widget)

        if self.production_no:
            self.lbl_production_no.setText(f"Producción N°: {self.production_no}")
        else:
            self.lbl_production_no.setText("")

        try:
            self.tabs.blockSignals(True)
            self.tabs.setCurrentIndex(self.step_index)
        finally:
            self.tabs.blockSignals(False)

        self.btn_back.setEnabled(self.step_index > 0)
        self.btn_next.setEnabled(self.step_index < len(self.steps) - 1)

        is_precio = (widget is self.page_precio)
        self.btn_generate_nav.setVisible(is_precio)

        if is_precio:
            self._update_summary()

        if widget is self.page_detalle:
            self._refresh_detalle_table()

    def _show_toast(self, msg: str, ms: int = 1700):
        self.lbl_status.setText(msg)
        self.lbl_status.setVisible(True)
        QTimer.singleShot(ms, lambda: self.lbl_status.setVisible(False))

    def go_back(self):
        self._set_step(self.step_index - 1)

    def go_next(self):
        if not self._commit_step_selection(self.step_index):
            return
        self._set_step(self.step_index + 1)

    def on_tab_clicked(self, idx: int):
        if idx == self.step_index:
            return

        # ✅ FAST VIEW: Etiket varsa Detalle'ye her yerden geç
        if idx == 7 and self.current_labels:
            self._set_step(7)
            return

        # Normal davranış
        if idx > self.step_index:
            if not self._commit_step_selection(self.step_index):
                try:
                    self.tabs.blockSignals(True)
                    self.tabs.setCurrentIndex(self.step_index)
                finally:
                    self.tabs.blockSignals(False)
                return

        self._set_step(idx)

    def _auto_next_from_list(self, step_idx: int):
        if self.step_index != step_idx:
            return
        if not self._commit_step_selection(step_idx):
            return
        self._set_step(step_idx + 1)

    def _commit_step_selection(self, step_idx: int) -> bool:
       
        if step_idx == 0:
            it = self.list_sucursales.currentItem()
            if not it:
                QMessageBox.warning(self, "Error", "Debes seleccionar una Sucursal.")
                return False

            payload = it.data(_qt_user_role()) or {}
            self.data["sucursal_id"] = payload.get("id")
            self.data["sucursal_nombre"] = payload.get("nombre", "")

            if not self.production_no:
                self.production_no = db.create_production_session(
                    sucursal_id=self.data.get("sucursal_id"),
                    usuario=self.usuario
                )

            return True

        if step_idx == 1:
            it = self.list_sacos.currentItem()
            if not it:
                QMessageBox.warning(self, "Error", "Debes seleccionar un Saco.")
                return False
            payload = it.data(_qt_user_role()) or {}
            self.data["saco"] = payload.get("code", it.text().split("|")[0].strip())
            self.data["saco_kg"] = int(payload.get("kg", 0) or 0)
            self.data["precio_saco"] = int(payload.get("precio_saco", 0) or 0)
            return True

        if step_idx == 2:
            cat = (self.selected_categoria or "").strip()
            if not cat:
                QMessageBox.warning(self, "Error", "Debes seleccionar una Categoría.")
                return False
            self.data["categoria"] = cat
            return True

        if step_idx == 3:
            genero = (self.selected_genero or "").strip()
            if not genero:
                QMessageBox.warning(self, "Error", "Debes seleccionar un Género.")
                return False
            self.data["genero"] = genero

            # Género seçildikten sonra ürünler ve talla güncellensin
            self._load_productos_for_categoria(self.data.get("categoria", ""))
            self.data["talla"] = ""
            self._load_tallas()
            return True

        if step_idx == 4:
            prod = (self.selected_producto or "").strip()
            if not prod:
                QMessageBox.warning(self, "Error", "Debes seleccionar un Producto.")
                return False
            self.data["producto"] = prod
            return True

        if step_idx == 5:
            if not self.data.get("talla"):
                QMessageBox.warning(self, "Error", "Debes seleccionar una Talla.")
                return False
            return True

        if step_idx == 6:
            self._update_summary()
            return True

        return True

    # ----------------------------
    # Precio logic
    # ----------------------------
    def _con_detalle_changed(self, _state: int):
        self.data["con_detalle"] = bool(self.chk_detalle.isChecked())
        self._update_summary()

    def _price_changed(self, _=None):
        self._update_summary()

    def _get_price_int(self) -> int:
        s = _norm(self.price_input.text()).replace(".", "").replace(",", "")
        if not s:
            return 0
        if not s.isdigit():
            return -1
        return int(s)

    def _build_descripcion(self) -> str:
        genero = self.data.get("genero", "")
        cat = self.data.get("categoria", "")
        prod = self.data.get("producto", "")
        con_det = bool(self.data.get("con_detalle", False))

        if _is_hogar(cat):
            desc = f"Retorno {prod}".strip()
        else:
            desc = f"S.Hand {prod} {genero}".strip()

        if con_det:
            desc = f"{desc} Con Detalle".strip()

        return desc

    def _update_summary(self):
        saco = self.data.get("saco", "")
        genero = self.data.get("genero", "")
        cat = self.data.get("categoria", "")
        prod = self.data.get("producto", "")
        talla = self.data.get("talla", "")
        kg = _parse_kg_input(self.kg_input.text())
        precio = self._get_price_int()
        qty = int(self.qty_input.value())

        desc = self._build_descripcion()
        self.data["descripcion"] = desc

        precio_txt = "—"
        if precio == -1:
            precio_txt = "⚠ inválido"
        elif precio >= 0:
            precio_txt = f"{_fmt_clp(precio)}"

        kg_txt = "—"
        if kg < 0:
            kg_txt = "⚠ inválido"
        else:
            kg_txt = f"{kg:.3f}".rstrip("0").rstrip(".")

        self.lbl_summary.setText(
            f"{saco} - {desc} - {talla} - Qty: {qty} - {precio_txt} CLP - KG: {kg_txt}"
        )

    # ----------------------------
    # Generate
    # ----------------------------
    def generate_labels(self):
        precio = self._get_price_int()
        kg = _parse_kg_input(self.kg_input.text())

        if kg < 0:
            QMessageBox.warning(self, "Error", "KG inválido. Ejemplo: 59 → 0.59 / 120 → 1.20 / 0.450")
            return

        if precio == 0:
            QMessageBox.warning(self, "Error", "Debes elegir un precio o escribirlo.")
            return

        if precio < 0:
            QMessageBox.warning(self, "Error", "Precio inválido. Solo números.")
            return

        qty = int(self.qty_input.value())
        if qty < 1 or qty > 500:
            QMessageBox.warning(self, "Error", "Cantidad debe estar entre 1 y 500.")
            return

        saco = self.data.get("saco", "")
        genero = self.data.get("genero", "")
        categoria = self.data.get("categoria", "")
        producto = self.data.get("producto", "")
        talla = self.data.get("talla", "")

        sucursal_id = self.data.get("sucursal_id")
        if not sucursal_id:
            QMessageBox.warning(self, "Error", "Debes seleccionar una Sucursal.")
            return

        if not all([saco, genero, categoria, producto, talla]):
            QMessageBox.warning(self, "Error", "Faltan selecciones (saco/género/categoría/producto/talla).")
            return

        descripcion = self._build_descripcion()
        self.data["descripcion"] = descripcion
        saco_kg = int(self.data.get("saco_kg", 0) or 0)

        if not hasattr(db, "preview_generate_labels"):
            QMessageBox.critical(self, "DB", "db.preview_generate_labels no existe. (db.py güncel değil)")
            return

        try:
            existing_barcodes = {str(r.get("barcode", "")).strip() for r in self.current_labels if r.get("barcode")}
            prefix = "770" + datetime.now().strftime("%y%m%d")
            preview_rows = db.preview_generate_labels(
                qty=qty,
                descripcion=descripcion,
                precio=int(precio),
                kg=float(kg),
                saco_codigo=saco,
                saco_kg=saco_kg,
                genero=genero,
                categoria=categoria,
                producto=producto,
                talla=talla if talla else "-",
                prefix=prefix,
                exclude_barcodes=existing_barcodes,
            )
        except Exception as e:
            QMessageBox.critical(self, "DB", f"preview_generate_labels error:\n{e}")
            return

        if not preview_rows:
            QMessageBox.warning(self, "Error", "No se pudieron generar etiquetas para vista previa.")
            return

        # Preview açılacak mı?
        if self.chk_preview.isChecked():
            dlg = PrintPreviewDialog(self, preview_rows)
            if dlg.exec() != QDialog.Accepted or not dlg.approved:
                self._show_toast("🛑 Impresión cancelada")
                return

        fecha = datetime.now().strftime("%d/%m/%Y")

        try:
            for row in preview_rows:
                print_label(
                    {
                        "barcode": row["barcode"],
                        "saco": row["saco_codigo"],
                        "fecha": fecha,
                        "talla": row["talla"],
                        "kg": row["kg"],
                        "descripcion": row["descripcion"],
                        "precio": _fmt_clp(int(row["precio"])),
                        "production_no": self.production_no,
                    }
                )
        except Exception as e:
            QMessageBox.critical(self, "Print", f"No se pudo imprimir:\n{e}")
            return

        for row in preview_rows:
            self.current_labels.append({
                "barcode": row["barcode"],
                "producto": row["producto"],
                "genero": row["genero"],
                "descripcion": row["descripcion"],
                "precio": int(row["precio"]),
                "kg": float(row["kg"]),
                "talla": row["talla"],
                "saco": row["saco_codigo"],
                "saco_codigo": row["saco_codigo"],
                "saco_kg": int(row["saco_kg"]),
                "categoria": row["categoria"],
                "prefix": row["prefix"],
                "production_no": self.production_no
            })

        keep = self.chk_keep_selection.isChecked()

        self.price_input.setText("")
        self.kg_input.setText("")
        self.qty_input.setValue(1)

        if not keep:
            # KALSIN:
            # self.data["sucursal_id"]
            # self.data["saco"]
            # self.data["categoria"]

            # SIFIRLANSIN:
            self.data["genero"] = ""
            self.data["producto"] = ""
            self.data["talla"] = ""
            self.data["precio"] = 0

            self.selected_genero = ""
            self.selected_producto = ""

            # kategori seçili kalsın
            # self.selected_categoria = ""

            # género butonlarını temizle
            for i in range(self.genero_grid.count()):
                w = self.genero_grid.itemAt(i).widget()
                if isinstance(w, QPushButton) and w.objectName() == "GeneroSquare":
                    w.setChecked(False)

            # ürün butonlarını temizle
            for i in range(self.producto_grid.count()):
                w = self.producto_grid.itemAt(i).widget()
                if isinstance(w, QPushButton) and w.objectName() == "ProductoSquare":
                    w.setChecked(False)

            # kategori gridine dokunma
            # kategori seçili kalacak

            self._clear_grid(self.producto_grid)
            self.lbl_producto_info.setText("")

            self._show_toast(f"✅ {len(preview_rows)} etiqueta(s) enviada(s) a impresión")
            self._set_step(3)
        else:
            self._show_toast(f"✅ {len(preview_rows)} etiqueta(s) enviada(s) a impresión")
            self._set_step(6)

    # ----------------------------
    # Detalle page actions
    # ----------------------------
    def _refresh_detalle_table(self):
        self.table.setRowCount(0)

        total = 0
        total_kg = 0.0
        for i, r in enumerate(self.current_labels):
            self.table.insertRow(i)

            chk = QCheckBox()
            chk.setChecked(False)
            self.table.setCellWidget(i, 0, chk)

            kg_val = float(r.get("kg", 0) or 0)

            self.table.setItem(i, 1, QTableWidgetItem(str(r.get("barcode",""))))
            self.table.setItem(i, 2, QTableWidgetItem(str(r.get("production_no",""))))
            self.table.setItem(i, 3, QTableWidgetItem(str(r.get("producto",""))))
            self.table.setItem(i, 4, QTableWidgetItem(str(r.get("genero",""))))
            self.table.setItem(i, 5, QTableWidgetItem(str(r.get("descripcion",""))))
            self.table.setItem(i, 6, QTableWidgetItem(f"{kg_val:.3f}".rstrip("0").rstrip(".")))
            self.table.setItem(i, 7, QTableWidgetItem(_fmt_clp(int(r.get("precio",0)))))

            total += int(r.get("precio",0))
            total_kg += float(r.get("kg", 0) or 0)

        self.lbl_total.setText(f"TOTAL: {_fmt_clp(total)} CLP")

        precio_saco = int(self.data.get("precio_saco", 0) or 0)
        self.lbl_saco_precio.setText(f"PRECIO SACO: {_fmt_clp(precio_saco)} CLP")

        brut_kar = total - precio_saco
        self.lbl_brut_kar.setText(f"GANANCIA: {_fmt_clp(brut_kar)} CLP")

        self.lbl_total_kg.setText(f"TOTAL KG: {total_kg:.3f}".rstrip("0").rstrip("."))

        saco_kg = float(self.data.get("saco_kg", 0) or 0)
        diferencia = saco_kg - total_kg
        self.lbl_diferencia.setText(
        f"DIFERENCIA: {diferencia:.3f}".rstrip("0").rstrip(".")
        )

    def _get_selected_indices(self) -> List[int]:
        idxs = []
        for i in range(self.table.rowCount()):
            w = self.table.cellWidget(i, 0)
            if isinstance(w, QCheckBox) and w.isChecked():
                idxs.append(i)
        return idxs

    def delete_selected(self):
        idxs = self._get_selected_indices()
        if not idxs:
            QMessageBox.information(self, "Info", "No hay filas seleccionadas.")
            return
        if QMessageBox.question(self, "Confirmar", f"¿Eliminar {len(idxs)} etiquetas de la lista?") != QMessageBox.StandardButton.Yes:
            return

        for i in sorted(idxs, reverse=True):
            if 0 <= i < len(self.current_labels):
                self.current_labels.pop(i)
        self._refresh_detalle_table()

    def reprint_selected(self):
        idxs = self._get_selected_indices()
        if not idxs:
            QMessageBox.information(self, "Info", "No hay filas seleccionadas.")
            return

        rows = [self.current_labels[i] for i in idxs if 0 <= i < len(self.current_labels)]
        if not rows:
            QMessageBox.information(self, "Info", "No hay filas seleccionadas.")
            return

        try:
            for r in rows:
                row = dict(r)
                row["fecha"] = row.get("fecha") or datetime.now().strftime("%d/%m/%Y")
                row["precio"] = _fmt_clp(int(row.get("precio", 0) or 0))
                row["kg"] = row.get("kg", 0)
                row["production_no"] = row.get("production_no", self.production_no)
                print_label(row)
        except Exception as e:
            QMessageBox.critical(self, "Print", f"No se pudo reimprimir:\n{e}")
            return

        self._show_toast(f"🖨 Reimpreso: {len(rows)} etiqueta(s)")

    def guardar_saco(self):
        if not self.current_labels:
            QMessageBox.warning(self, "Error", "No hay etiquetas para guardar.")
            return

        valid_rows = [
            r for r in self.current_labels
            if str(r.get("barcode", "") or "").strip()
        ]

        if not valid_rows:
            QMessageBox.warning(self, "Error", "Debe haber al menos 1 producto válido para guardar.")
            return

        saco = self.data.get("saco", "")
        categoria = self.data.get("categoria", "")
        genero = self.data.get("genero", "")
        sucursal_id = self.data.get("sucursal_id")

        if QMessageBox.question(
            self,
            "Guardar Saco",
            "¿Guardar este saco en stock y limpiar la lista?"
        ) != QMessageBox.StandardButton.Yes:
            return

        try:
            if not hasattr(db, "save_labels_to_db"):
                raise RuntimeError("db.save_labels_to_db no existe.")

            # DB'de zaten kayıtlı barkodları bul
            barcodes = [
                str(r.get("barcode", "") or "").strip()
                for r in self.current_labels
                if str(r.get("barcode", "") or "").strip()
            ]

            existing_barcodes = set()

            if barcodes:
                with db.connect() as con:
                    placeholders = ",".join("?" for _ in barcodes)
                    rows_exist = con.execute(
                        f"SELECT barcode FROM labels WHERE barcode IN ({placeholders})",
                        tuple(barcodes)
                    ).fetchall()

                    existing_barcodes = {
                        str(r["barcode"]).strip()
                        for r in rows_exist
                        if r["barcode"]
                    }

            # Sadece yeni barkodları kaydet
            rows_to_save = [
                r for r in self.current_labels
                if str(r.get("barcode", "") or "").strip() not in existing_barcodes
            ]

            if not rows_to_save:
                QMessageBox.information(
                    self,
                    "Info",
                    "No hay etiquetas nuevas para guardar.\nLas existentes ya estaban registradas."
                )
                return

            # Önce ekrandaki production_no'yu kullan
            production_no = str(getattr(self, "production_no", "") or "").strip()

            # Satırlarda varsa oradan da kontrol et
            if not production_no:
                for r in rows_to_save:
                    pn = str(r.get("production_no", "") or "").strip()
                    if pn:
                        production_no = pn
                        break

            if not production_no:
                raise RuntimeError("No se encontró production_no válido en las etiquetas.")

            # Stock batch ID de aynı olsun
            id6 = production_no

            for r in rows_to_save:
                r["production_no"] = production_no
                r["saco_codigo"] = saco
                r["genero"] = genero
                r["categoria"] = categoria

            db.save_labels_to_db(rows_to_save)

            _save_stock_batch(
                id6=id6,
                sucursal_id=sucursal_id,
                saco_codigo=saco,
                categoria=categoria,
                genero=genero,
                usuario=self.usuario,
                rows=rows_to_save
            )

            # Production için otomatik Hoja de Entrada oluştur
            if hasattr(db, "ensure_hoja_entrada_for_production"):
                db.ensure_hoja_entrada_for_production(production_no)

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo guardar:\n{e}")
            return

        QMessageBox.information(self, "OK", f"Saco guardado ✅\nProducción: {production_no}")

        self.current_labels.clear()
        self._refresh_detalle_table()

        self.production_no = ""

        self.data["sucursal_id"] = None
        self.data["sucursal_nombre"] = ""
        self.data["saco"] = ""
        self.data["saco_kg"] = 0
        self.data["precio_saco"] = 0
        self.data["genero"] = ""
        self.data["categoria"] = ""
        self.data["producto"] = ""
        self.data["talla"] = ""
        self.data["precio"] = 0
        self.data["descripcion"] = ""
        self.data["con_detalle"] = False

        self.selected_genero = ""
        self.selected_categoria = ""
        self.selected_producto = ""

        self.price_input.setText("")
        self.kg_input.setText("")
        self.qty_input.setValue(1)

        self._set_step(0)


    def _select_sucursal_by_id(self, sucursal_id):
        try:
            target = int(sucursal_id)
        except Exception:
            return

        for i in range(self.list_sucursales.count()):
            it = self.list_sucursales.item(i)
            payload = it.data(_qt_user_role()) or {}
            try:
                if int(payload.get("id")) == target:
                    self.list_sucursales.setCurrentRow(i)
                    return
            except Exception:
                pass

    def _select_saco_by_code(self, saco_code: str):
        code = (saco_code or "").strip().upper()
        if not code:
            return

        for i in range(self.list_sacos.count()):
            it = self.list_sacos.item(i)
            payload = it.data(_qt_user_role()) or {}
            if str(payload.get("code", "")).strip().upper() == code:
                self.list_sacos.setCurrentRow(i)
                return

    def load_production(self, production_no: str):
        production_no = (production_no or "").strip()
        if not production_no:
            QMessageBox.warning(self, "Producción", "No hay número de producción.")
            return

        header = db.fetch_production_header(production_no) if hasattr(db, "fetch_production_header") else None
        rows = db.get_production_labels(production_no) if hasattr(db, "get_production_labels") else []

        if not header:
            QMessageBox.warning(
                self,
                "Producción",
                f"No se encontró la producción:\n{production_no}"
            )
            return

        self.production_no = production_no

        # Header bilgileri
        self.data["sucursal_id"] = header.get("sucursal_id")
        self.data["sucursal_nombre"] = header.get("sucursal_nombre", "")
        self.data["saco"] = header.get("saco_codigo", "")
        self.data["descripcion"] = ""
        self.data["precio"] = 0
        self.data["qty"] = 1

        # Önce mevcut seçim listelerini yenile
        self._refresh_all_lists()

        # Sucursal ve saco seçimini ekranda da işaretle
        self._select_sucursal_by_id(header.get("sucursal_id"))
        self._select_saco_by_code(header.get("saco_codigo", ""))

        # Eski label satırlarını yükle
        self.current_labels = []
        first_row = rows[0] if rows else {}

        for r in rows:
            precio_val = r.get("precio", 0)
            kg_val = r.get("kg", 0)

            try:
                precio_val = int(float(precio_val or 0))
            except Exception:
                precio_val = 0

            try:
                kg_val = float(kg_val or 0)
            except Exception:
                kg_val = 0.0

            row_data = {
                "barcode": r.get("barcode", ""),
                "producto": r.get("producto", ""),
                "genero": r.get("genero", ""),
                "descripcion": r.get("descripcion", ""),
                "precio": precio_val,
                "kg": kg_val,
                "talla": r.get("talla", ""),
                "saco": r.get("saco_codigo", ""),
                "saco_codigo": r.get("saco_codigo", ""),
                "saco_kg": int(self.data.get("saco_kg", 0) or 0),
                "categoria": r.get("categoria", ""),
                "prefix": "",
                "production_no": production_no,
            }
            self.current_labels.append(row_data)

        # İlk satıra göre wizard seçimlerini doldur
        self.data["categoria"] = first_row.get("categoria", "") if first_row else ""
        self.data["genero"] = first_row.get("genero", "") if first_row else ""
        self.data["producto"] = first_row.get("producto", "") if first_row else ""
        self.data["talla"] = first_row.get("talla", "") if first_row else ""

        self.selected_categoria = self.data["categoria"]
        self.selected_genero = self.data["genero"]
        self.selected_producto = self.data["producto"]

        # UI alanları
        try:
            self.price_input.setText(str(first_row.get("precio", "")) if first_row else "")
        except Exception:
            pass

        try:
            self.kg_input.setText(str(first_row.get("kg", "")) if first_row else "")
        except Exception:
            pass

        try:
            self.qty_input.setValue(1)
        except Exception:
            pass

        # Eğer kategori geldiyse ürün/talla ekranlarını hazırla
        if self.data.get("categoria"):
            try:
                self._load_productos_for_categoria(self.data.get("categoria", ""))
            except Exception:
                pass

        if self.data.get("categoria"):
            try:
                self._load_tallas()
            except Exception:
                pass

        # Con Detalle kontrolü
        desc0 = str(first_row.get("descripcion", "") if first_row else "")
        try:
            self.chk_detalle.setChecked("con detalle" in desc0.lower())
        except Exception:
            pass

        # Detalle tablosunu göster
        self._refresh_detalle_table()
        self._set_step(7)
        self._show_toast(f"📦 Producción cargada: {production_no}", 2200)

    def closeEvent(self, event):
        if self.current_labels:
            reply = QMessageBox.question(
                self,
                "Guardar antes de salir?",
                "Todavía no hiciste 'Guardar Saco'.\n\n¿Quieres guardar antes de salir?",
                QMessageBox.StandardButton.Si |
                QMessageBox.StandardButton.No |
                QMessageBox.StandardButton.Cancel
            )

            if reply == QMessageBox.StandardButton.Yes:
                self._set_step(7)
                event.ignore()
                return
            elif reply == QMessageBox.StandardButton.No:
                event.accept()
                return
            else:
                event.ignore()
                return

        event.accept()

