import sys
import db
from pos_screen_qt import open_pos_qt


def main():
    usuario = ""
    sucursal_id = None
    sucursal_nombre = ""

    # 1) Komut satırından usuario al
    if len(sys.argv) >= 2:
        usuario = (sys.argv[1] or "").strip()

    # 2) Komut satırından sucursal_id al
    if len(sys.argv) >= 3:
        try:
            sucursal_id = int(sys.argv[2])
        except Exception:
            sucursal_id = None

    # 3) Öncelik: gelen sucursal_id
    if sucursal_id:
        try:
            suc = db.get_sucursal_by_id(sucursal_id)
            if suc and suc.get("nombre"):
                sucursal_nombre = str(suc.get("nombre")).strip()
        except Exception:
            pass

    # 4) Eğer sucursal_id gelmediyse, usuario üzerinden bul
    if not sucursal_id and usuario:
        try:
            u = db.get_usuario_by_login(usuario) if hasattr(db, "get_usuario_by_login") else None
            if u and u.get("sucursal_id"):
                sucursal_id = int(u.get("sucursal_id"))

                suc = db.get_sucursal_by_id(sucursal_id)
                if suc and suc.get("nombre"):
                    sucursal_nombre = str(suc.get("nombre")).strip()
        except Exception:
            pass

    # 5) Sucursal zorunlu
    if not sucursal_id or not sucursal_nombre:
        print("ERROR: usuario sin sucursal asignada")
        try:
            from PySide6.QtWidgets import QApplication, QMessageBox
            app = QApplication.instance() or QApplication(sys.argv)
            QMessageBox.critical(
                None,
                "Sucursal obligatoria",
                "Este usuario no tiene una sucursal asignada.\nNo puede realizar ventas."
            )
        except Exception:
            pass
        sys.exit(1)

    print(f"POS RUNNER → Usuario: {usuario} | Sucursal ID: {sucursal_id} | Sucursal: {sucursal_nombre}")

    # 6) POS aç
    open_pos_qt(
        usuario=usuario,
        sucursal_id=sucursal_id,
        sucursal_nombre=sucursal_nombre
    )


if __name__ == "__main__":
    main()