from PySide6.QtWidgets import (
    QDialog, QFormLayout, QDateEdit, QLineEdit, QComboBox,
    QDialogButtonBox, QMessageBox
)
from PySide6.QtCore import QDate
import db
from PySide6.QtWidgets import (
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
    QListWidget,
    QListWidgetItem,
    QLabel,
    QPushButton,
    QFrame,
    QSizePolicy,
    QMessageBox,
    QStackedWidget,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QToolButton
)
from db import fetch_production_report
from PySide6.QtCore import Qt, Signal, QSize, QTimer

REPORT_LIST = [
    "Venta Diaria",
    "Control De Ventas",
    "Analizar Venta",
    "Resumen De Ventas",
    "Ventas Con Detalle",
    "Ventas Por Sucursal",
    "Ventas Por Clientes",
    "Ventas De Entrada",
    "Informe de Producción",
    "Inventario",
    "Inventario Por Sucursal",
]

class AnalizarVentasFilterDialog(QDialog):
    def __init__(self, parent=None, current_filters=None):
        super().__init__(parent)
        self.setWindowTitle("Filtro · Analistas de venta")
        self.resize(420, 280)

        current_filters = current_filters or {}

        lay = QFormLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)

        self.dt_desde = QDateEdit()
        self.dt_desde.setCalendarPopup(True)
        self.dt_desde.setDate(QDate.currentDate().addMonths(-1))

        self.dt_hasta = QDateEdit()
        self.dt_hasta.setCalendarPopup(True)
        self.dt_hasta.setDate(QDate.currentDate())

        self.cb_sucursal = QComboBox()
        self.cb_producto = QComboBox()
        self.cb_genero = QComboBox()
        self.cb_saco = QComboBox()

        try:
            vals = db.fetch_analizar_filter_values()
            print(">>> FILTROS DB >>>", vals)
        except Exception as e:
            QMessageBox.warning(self, "DB", f"No se pudieron cargar filtros:\n{e}")
            vals = {
                "productos": [],
                "generos": [],
                "sacos": [],
            }

        try:
            sucursales = db.fetch_sucursales_for_filter()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"No se pudieron cargar sucursales:\n{e}")
            sucursales = []

        self._fill_combo(self.cb_sucursal, sucursales, current_filters.get("sucursal", ""))
        self._fill_combo(self.cb_producto, vals.get("productos", []), current_filters.get("producto", ""))
        self._fill_combo(self.cb_genero, vals.get("generos", []), current_filters.get("genero", ""))
        self._fill_combo(self.cb_saco, vals.get("sacos", []), current_filters.get("saco", ""))

        lay.addRow("Fecha desde:", self.dt_desde)
        lay.addRow("Fecha hasta:", self.dt_hasta)
        lay.addRow("Sucursal:", self.cb_sucursal)
        lay.addRow("Producto:", self.cb_producto)
        lay.addRow("Género:", self.cb_genero)
        lay.addRow("Saco:", self.cb_saco)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addRow(buttons)

    def _fill_combo(self, combo: QComboBox, values, selected_value):
        combo.clear()
        combo.addItem("TODOS")

        for value in values:
            text = str(value).strip()
            if text:
                combo.addItem(text)

        if selected_value:
            idx = combo.findText(str(selected_value).strip())
            if idx >= 0:
                combo.setCurrentIndex(idx)

    def values(self):
        return {
            "fecha_desde": self.dt_desde.date().toString("yyyy-MM-dd"),
            "fecha_hasta": self.dt_hasta.date().toString("yyyy-MM-dd"),
            "sucursal": self.cb_sucursal.currentText().strip(),
            "producto": self.cb_producto.currentText().strip(),
            "genero": self.cb_genero.currentText().strip(),
            "saco": self.cb_saco.currentText().strip(),
        }

class VentasConDetalleFilterDialog(QDialog):
    def __init__(self, parent=None, current_filters=None):
        super().__init__(parent)
        self.setWindowTitle("Filtro · Ventas Con Detalle")
        self.resize(420, 220)

        current_filters = current_filters or {}

        lay = QFormLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)

        self.dt_desde = QDateEdit()
        self.dt_desde.setCalendarPopup(True)
        self.dt_desde.setDate(QDate.currentDate().addMonths(-1))

        self.dt_hasta = QDateEdit()
        self.dt_hasta.setCalendarPopup(True)
        self.dt_hasta.setDate(QDate.currentDate())

        self.cb_sucursal = QComboBox()

        try:
            sucursales = db.fetch_sucursales_for_filter()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"No se pudieron cargar sucursales:\n{e}")
            sucursales = []

        self._fill_combo(
            self.cb_sucursal,
            sucursales,
            current_filters.get("sucursal", "")
        )

        lay.addRow("Fecha desde:", self.dt_desde)
        lay.addRow("Fecha hasta:", self.dt_hasta)
        lay.addRow("Sucursal:", self.cb_sucursal)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addRow(buttons)

    def _fill_combo(self, combo: QComboBox, values, selected_value):
        combo.clear()
        combo.addItem("TODOS")

        for value in values:
            text = str(value).strip()
            if text:
                combo.addItem(text)

        if selected_value:
            idx = combo.findText(str(selected_value).strip())
            if idx >= 0:
                combo.setCurrentIndex(idx)

    def values(self):
        sucursal = self.cb_sucursal.currentText().strip()
        if sucursal.upper() == "TODOS":
            sucursal = ""

        return {
            "fecha_desde": self.dt_desde.date().toString("yyyy-MM-dd"),
            "fecha_hasta": self.dt_hasta.date().toString("yyyy-MM-dd"),
            "sucursal": sucursal,
        }

class ReportManagerPage(QWidget):
    open_report_requested = Signal(str, dict)
  
    def __init__(self, parent=None):
        super().__init__(parent)

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # SOL PANEL
        left_wrap = QFrame()
        left_wrap.setObjectName("reportLeftPanel")
        left_wrap.setMinimumWidth(200)
        left_wrap.setMaximumWidth(220)

        left_layout = QVBoxLayout(left_wrap)
        left_layout.setContentsMargins(8, 8, 8, 8)
        left_layout.setSpacing(4)

        title = QLabel("REPORTES")
        title.setObjectName("reportLeftTitle")
        left_layout.addWidget(title)

        self.list_reports = QListWidget()
        self.list_reports.setObjectName("reportList")
        left_layout.addWidget(self.list_reports, 1)

        for r in REPORT_LIST:
            self._add_report_row(r)

        # SAĞ PANEL
        right_wrap = QFrame()
        right_wrap.setObjectName("reportRightPanel")

        right_layout = QVBoxLayout(right_wrap)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(0)

        self.content_stack = QStackedWidget()
        self.content_stack.setObjectName("reportContentStack")

        self.placeholder = QLabel("")
        self.placeholder.setObjectName("reportPlaceholder")
        self.placeholder.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.placeholder.setWordWrap(True)

        self.placeholder_wrap = QWidget()
        ph_layout = QVBoxLayout(self.placeholder_wrap)
        ph_layout.setContentsMargins(0, 0, 0, 0)
        ph_layout.setSpacing(0)
        ph_layout.addWidget(self.placeholder)
        ph_layout.addStretch()

        self.content_stack.addWidget(self.placeholder_wrap)
        right_layout.addWidget(self.content_stack, 1)

        root.addWidget(left_wrap)
        root.addWidget(right_wrap, 1)

        self.list_reports.currentRowChanged.connect(self._on_row_changed)
        self.list_reports.setCurrentRow(0)

        self.setStyleSheet("""
        QFrame#reportLeftPanel {
            background: #f7f8fa;
            border: 1px solid #e4e7ec;
            border-radius: 8px;
        }

        QLabel#reportLeftTitle {
            font-size: 15px;
            font-weight: 700;
            color: #111827;
            padding: 2px;
        }

        QListWidget#reportList {
            background: transparent;
            border: none;
            outline: none;
        }

        QListWidget#reportList::item {
            padding: 0px;
            margin: 0px;
            border: none;
            background: transparent;
        }

        QLabel#reportRowLabel {
            font-size: 13px;
            color: #111827;
            padding: 0px;
        }

        QToolButton#reportFilterBtn {
            border: none;
            background: transparent;
            font-size: 13px;
            padding: 2px 4px;
        }

        QToolButton#reportFilterBtn:hover {
            background: #eef2f7;
            border-radius: 6px;
        }

        QFrame#reportRightPanel {
            background: #ffffff;
            border: 1px solid #e4e7ec;
            border-left: none;
            border-radius: 0px;
        }

        QLabel#reportPlaceholder {
            font-size: 14px;
            color: #667085;
            padding: 8px;
        }
        """)

    def _add_report_row(self, name: str):
        item = QListWidgetItem()
        item.setSizeHint(QSize(0, 34))
        item.setData(Qt.UserRole, name)
        self.list_reports.addItem(item)

        row_widget = QWidget()
        row_layout = QHBoxLayout(row_widget)
        row_layout.setContentsMargins(8, 2, 8, 2)
        row_layout.setSpacing(4)

        label = QLabel(name)
        label.setObjectName("reportRowLabel")

        btn_filter = QToolButton()
        btn_filter.setText("🔎")
        btn_filter.setObjectName("reportFilterBtn")
        btn_filter.clicked.connect(lambda _, n=name: self.open_filter_for_report(n))

        row_layout.addWidget(label, 1)
        row_layout.addWidget(btn_filter, 0)

        self.list_reports.setItemWidget(item, row_widget)

    def _on_row_changed(self, row: int):
        if row < 0:
            self.placeholder.setText("")
            self.content_stack.setCurrentIndex(0)
            return

        item = self.list_reports.item(row)
        if not item:
            return

        name = item.data(Qt.UserRole) or ""
        self.placeholder.setText("")
        self.content_stack.setCurrentIndex(0)

    def open_filter_for_report(self, report_name: str):
        if report_name in ("Resumen de ventas", "Resumen De Ventas", "Control de ventas"):
            self.open_report_requested.emit("ventas_resumen", {})
            return

        if report_name in ("Analistas de venta", "Analizar Venta"):
            dlg = AnalizarVentasFilterDialog(self)
            if dlg.exec() == QDialog.Accepted:
                self.open_report_requested.emit("analizar_ventas", dlg.values())
            return

        if report_name == "Ventas Con Detalle":
            dlg = VentasConDetalleFilterDialog(self)
            if dlg.exec() == QDialog.Accepted:
                self.open_report_requested.emit("ventas_con_detalle", dlg.values())
            return

        if report_name == "Informe de Producción":
            self.open_report_requested.emit("informe_produccion", {})
            return

        QMessageBox.information(
            self,
            "Filtro",
            f"El reporte '{report_name}' aún no tiene filtro configurado."
        )

    def set_report_widget(self, widget, title: str):
        while self.content_stack.count() > 1:
            old = self.content_stack.widget(1)
            self.content_stack.removeWidget(old)
            old.setParent(None)

        self.content_stack.addWidget(widget)
        self.content_stack.setCurrentWidget(widget)

    def generar_reporte(self):
        selected_item = self.list_reports.currentItem()
        if not selected_item:
            QMessageBox.information(self, "Reportes", "Seleccione un reporte.")
            return

        selected = (selected_item.data(Qt.UserRole) or "").strip()

        if selected in ("Resumen de ventas", "Resumen De Ventas", "Control de ventas"):
            self.open_report_requested.emit("ventas_resumen", {})
            return

        if selected in ("Analistas de venta", "Analizar Venta"):
            dlg = AnalizarVentasFilterDialog(self)
            if dlg.exec() == QDialog.Accepted:
                self.open_report_requested.emit("analizar_ventas", dlg.values())
            return

        if selected == "Ventas Con Detalle":
            dlg = VentasConDetalleFilterDialog(self)
            if dlg.exec() == QDialog.Accepted:
                self.open_report_requested.emit("ventas_con_detalle", dlg.values())
            return

        if selected == "Informe de Producción":
            self.open_report_requested.emit("informe_produccion", {})
            return

        QMessageBox.information(
            self,
            "Reportes",
            f"El reporte '{selected}' aún no está conectado."
        )
 
    def open_informe_produccion(self):
        self.w = InformeProduccionScreen()
        self.w.show()

class InformeProduccionScreen(QWidget):
    open_hoja_requested = Signal(str)

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Informe de Producción")

        layout = QVBoxLayout(self)

        # --- FILTROS ---
        filtros_layout = QHBoxLayout()

        self.fecha_desde = QDateEdit()
        self.fecha_desde.setCalendarPopup(True)
        self.fecha_desde.setDate(QDate.currentDate().addDays(-7))

        self.fecha_hasta = QDateEdit()
        self.fecha_hasta.setCalendarPopup(True)
        self.fecha_hasta.setDate(QDate.currentDate())

        self.input_saco = QLineEdit()
        self.input_saco.setPlaceholderText("Saco")

        self.input_barcode = QLineEdit()
        self.input_barcode.setPlaceholderText("Barcode")

        btn_buscar = QPushButton("Buscar")
        btn_buscar.clicked.connect(self.buscar)

        filtros_layout.addWidget(QLabel("Desde"))
        filtros_layout.addWidget(self.fecha_desde)
        filtros_layout.addWidget(QLabel("Hasta"))
        filtros_layout.addWidget(self.fecha_hasta)
        filtros_layout.addWidget(self.input_saco)
        filtros_layout.addWidget(self.input_barcode)
        filtros_layout.addWidget(btn_buscar)

        layout.addLayout(filtros_layout)

        # --- TABLA ---
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Producción",
            "Fecha",
            "Sucursal",
            "Cantidad",
            "Kg",
            "Total",
            "Usuario"
        ])

        layout.addWidget(self.table)
        self.table.cellDoubleClicked.connect(self._open_hoja_entrada)
        QTimer.singleShot(0, self.buscar)
        

    def buscar(self):
        desde = self.fecha_desde.date().toString("yyyy-MM-dd")
        hasta = self.fecha_hasta.date().toString("yyyy-MM-dd")
        saco = (self.input_saco.text() or "").strip()
        barcode = (self.input_barcode.text() or "").strip()

        data = fetch_production_report(
            fecha_desde=desde,
            fecha_hasta=hasta,
            saco=saco,
            barcode=barcode
        )

        if data is None:
            data = []

        self.table.setRowCount(len(data))

        for row, r in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(r["production_no"])))

            created_at = str(r.get("created_at", "") or "").strip()
            fecha_txt = ""

            if created_at:
                fecha_parte = created_at.split(" ")[0].strip()
                try:
                    y, m, d = fecha_parte.split("-")
                    fecha_txt = f"{d}.{m}.{y}"
                except Exception:
                    fecha_txt = fecha_parte

            self.table.setItem(row, 1, QTableWidgetItem(fecha_txt))
            self.table.setItem(row, 2, QTableWidgetItem(str(r["sucursal_nombre"])))
            self.table.setItem(row, 3, QTableWidgetItem(str(r["cantidad"])))
            self.table.setItem(row, 4, QTableWidgetItem(str(r["total_kg"])))
            self.table.setItem(row, 5, QTableWidgetItem(str(r["total_precio"])))
            self.table.setItem(row, 6, QTableWidgetItem(str(r["usuario"])))

    def _open_hoja_entrada(self, row, column):
        item = self.table.item(row, 0)
        if not item:
            return

        production_no = (item.text() or "").strip()
        if not production_no:
            return

        QTimer.singleShot(0, lambda pn=production_no: self.open_hoja_requested.emit(pn))