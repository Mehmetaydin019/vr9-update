from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox
)

import db


class BolsasScreen(QWidget):

    def __init__(self):
        super().__init__()

        layout = QVBoxLayout(self)

        title = QLabel("Bolsas - Precios")
        title.setStyleSheet("font-size:18px;font-weight:700;")
        layout.addWidget(title)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels([
            "Código", "Descripción", "Precio"
        ])

        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.ResizeToContents)

        layout.addWidget(self.table)

        btn_row = QHBoxLayout()

        self.btn_guardar = QPushButton("Guardar")
        self.btn_guardar.clicked.connect(self.guardar)

        self.btn_refresh = QPushButton("Actualizar")
        self.btn_refresh.clicked.connect(self.load_data)

        btn_row.addWidget(self.btn_guardar)
        btn_row.addWidget(self.btn_refresh)

        layout.addLayout(btn_row)

        self.load_data()

    def load_data(self):

        rows = db.get_bolsas()

        self.table.setRowCount(0)

        for i, r in enumerate(rows):

            self.table.insertRow(i)

            self.table.setItem(i, 0, QTableWidgetItem(str(r["codigo"])))
            self.table.setItem(i, 1, QTableWidgetItem(str(r["descripcion"])))

            price = QTableWidgetItem(str(r["precio"]))
            self.table.setItem(i, 2, price)

    def guardar(self):

        for r in range(self.table.rowCount()):

            codigo = self.table.item(r, 0).text()
            precio = int(self.table.item(r, 2).text())

            db.update_quick_price(codigo, precio)

        QMessageBox.information(self, "OK", "Precios actualizados")