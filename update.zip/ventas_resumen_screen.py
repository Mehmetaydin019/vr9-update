from __future__ import annotations

from typing import List, Dict, Any, Optional

from PySide6.QtCore import Qt, QDate
from PySide6.QtGui import QFont, QColor
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QDateEdit, QComboBox, QLineEdit, QMessageBox, QDialog,
    QFormLayout, QDialogButtonBox, QAbstractSpinBox, QAbstractItemView
)

import db


def _money(n: int) -> str:
    try:
        return f"{int(n):,}".replace(",", ".")
    except Exception:
        return str(n)


class EditarPagoDialog(QDialog):
    def __init__(self, parent=None, venta: Optional[Dict[str, Any]] = None):
        super().__init__(parent)
        self.setWindowTitle("Guardar")
        self.setModal(True)
        self.resize(360, 220)

        venta = venta or {}

        root = QVBoxLayout(self)
        form = QFormLayout()
        form.setSpacing(10)

        self.cb_medio = QComboBox()
        self.cb_medio.addItems(["Efectivo", "Debito", "Credito", "Transferencia"])

        medio = str(venta.get("medio_pago", "") or "").strip().capitalize()
        idx = self.cb_medio.findText(medio)
        if idx >= 0:
            self.cb_medio.setCurrentIndex(idx)

        self.ed_promo = QLineEdit(str(int(venta.get("promo", 0) or 0)))
        self.ed_promo.setPlaceholderText("0")

        form.addRow("Medio pago:", self.cb_medio)
        form.addRow("Promoción:", self.ed_promo)
        root.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.setStyleSheet("""
            QDialog { background:#ffffff; }
            QLineEdit, QComboBox {
                min-height:36px;
                border:1px solid #cbd5e1;
                border-radius:10px;
                padding:6px 8px;
                background:#ffffff;
                font-weight:700;
            }
            QPushButton {
                min-height:38px;
                padding:8px 12px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:800;
            }
            QTableWidget {
                alternate-background-color: #f7fbff;
                background: #ffffff;
                gridline-color: #e5e7eb;
            }
        """)

    def get_data(self):
        try:
            promo = int((self.ed_promo.text() or "0").strip())
        except Exception:
            promo = 0

        return {
            "medio_pago": self.cb_medio.currentText().strip(),
            "promo": promo,
        }


class VentasResumenScreen(QWidget):
    def __init__(self):
        super().__init__()

        self.current_rows: List[Dict[str, Any]] = []
        self.current_venta_id: Optional[int] = None

        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(2)

        self.btn_buscar = QPushButton("Buscar")
        self.btn_limpiar = QPushButton("Limpiar")
        self.btn_exportar = QPushButton("Exportar Excel")
        self.btn_editar = QPushButton("Guardar")
        self.btn_reimprimir = QPushButton("Reimprimir")
        self.btn_anular = QPushButton("Anular venta")

        # Title
        head = QHBoxLayout()
        title = QLabel("Resumen de Ventas")
        title.setFont(QFont("Segoe UI", 18, 900))
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(self.btn_exportar)
        head.addWidget(self.btn_editar)
        head.addWidget(self.btn_reimprimir)
        head.addWidget(self.btn_anular)
        root.addLayout(head)

        # Filters
        filters_box = QFrame()
        filters_box.setObjectName("FiltersBox")
        filters_lay = QHBoxLayout(filters_box)
        filters_lay.setContentsMargins(6, 6, 6, 6)
        filters_lay.setSpacing(2)

        self.dt_desde = QDateEdit()
        self.dt_desde.setCalendarPopup(True)
        self.dt_desde.setDisplayFormat("dd.MM.yyyy")
        self.dt_desde.setDate(QDate.currentDate())
        self.dt_desde.setButtonSymbols(QAbstractSpinBox.NoButtons)
        self.dt_desde.setCalendarPopup(True)
        self.dt_desde.setFixedWidth(135)

        self.dt_hasta = QDateEdit()
        self.dt_hasta.setCalendarPopup(True)
        self.dt_hasta.setDisplayFormat("dd.MM.yyyy")
        self.dt_hasta.setDate(QDate.currentDate())
        self.dt_hasta.setButtonSymbols(QAbstractSpinBox.NoButtons)
        self.dt_hasta.setCalendarPopup(True)
        self.dt_hasta.setFixedWidth(135)

        self.cb_sucursal = QComboBox()
        self.cb_sucursal.setMinimumWidth(135)

        self.cb_usuario = QComboBox()
        self.cb_usuario.setMinimumWidth(135)

        self.ed_barcode = QLineEdit()
        self.ed_barcode.setPlaceholderText("Buscar por barcode / código")
        self.ed_barcode.returnPressed.connect(self.buscar_por_barcode)
        self.ed_barcode.setMaximumWidth(240)

        self.btn_buscar.setObjectName("Primary")
        self.btn_buscar.clicked.connect(self.buscar_por_barcode)
        self.btn_limpiar.clicked.connect(self.clear_filters)
        self.btn_exportar.clicked.connect(self.exportar_excel)
        self.btn_editar.clicked.connect(self.guardar_pago_editado)
        self.btn_reimprimir.clicked.connect(self.reimprimir)
        self.btn_anular.clicked.connect(self.anular_venta)

        filters_lay.addWidget(QLabel("Desde"))
        filters_lay.addWidget(self.dt_desde)
        filters_lay.addWidget(QLabel("Hasta"))
        filters_lay.addWidget(self.dt_hasta)
        filters_lay.addWidget(QLabel("Sucursal"))
        filters_lay.addWidget(self.cb_sucursal)
        filters_lay.addWidget(QLabel("Usuario"))
        filters_lay.addWidget(self.cb_usuario)
        filters_lay.addWidget(self.ed_barcode, 1)
        filters_lay.addWidget(self.btn_buscar)
        filters_lay.addWidget(self.btn_limpiar)

        root.addWidget(filters_box)

        # Top table
        self.tbl_ventas = QTableWidget(0, 12)
        self.tbl_ventas.setHorizontalHeaderLabels([
            "ID",
            "Folio",
            "Fecha",
            "Sucursal",
            "Cantidad",
            "Total",
            "Efectivo",
            "Débito",
            "Crédito",
            "Transferencia",
            "Promoción",
            "Usuario",
        ])
        self.tbl_ventas.verticalHeader().setVisible(False)
        self.tbl_ventas.setEditTriggers(self.tbl_ventas.EditTrigger.NoEditTriggers)
        self.tbl_ventas.setSelectionBehavior(self.tbl_ventas.SelectionBehavior.SelectRows)
        self.tbl_ventas.setSelectionMode(self.tbl_ventas.SelectionMode.SingleSelection)
        self.tbl_ventas.itemSelectionChanged.connect(self.load_detalle)
        self.tbl_ventas.itemDoubleClicked.connect(self.on_tbl_ventas_double_clicked)
        self.tbl_ventas.setEditTriggers(
            QAbstractItemView.DoubleClicked |
            QAbstractItemView.SelectedClicked
        )
        self.tbl_ventas.setAlternatingRowColors(True)

        hh = self.tbl_ventas.horizontalHeader()
        for i in range(12):
            hh.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)

        root.addWidget(self.tbl_ventas, 3)

        self.lbl_totales = QLabel("")
        self.lbl_totales.setObjectName("ResumenTotales")
        root.addWidget(self.lbl_totales)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        root.addWidget(line)

        det_title = QLabel("Detalle de venta")
        det_title.setFont(QFont("Segoe UI", 12, 800))
        root.addWidget(det_title)

        self.tbl_detalle = QTableWidget(0, 6)
        self.tbl_detalle.setHorizontalHeaderLabels([
            "Código",
            "Producto",
            "Cantidad",
            "Precio",
            "Valor",
            "Kg",
        ])
        self.tbl_detalle.verticalHeader().setVisible(False)
        self.tbl_detalle.setEditTriggers(self.tbl_detalle.EditTrigger.NoEditTriggers)
        self.tbl_detalle.setSelectionBehavior(self.tbl_detalle.SelectionBehavior.SelectRows)
        self.tbl_detalle.setSelectionMode(self.tbl_detalle.SelectionMode.SingleSelection)

        hh2 = self.tbl_detalle.horizontalHeader()
        for i in range(6):
            hh2.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)

        root.addWidget(self.tbl_detalle, 2)

        self.lbl_info = QLabel("")
        self.lbl_info.setStyleSheet("color:#64748b;font-size:12px;font-weight:700;")
        root.addWidget(self.lbl_info)

        self.setStyleSheet("""
            QWidget { background:#ffffff; }
            QFrame#FiltersBox {
                background:transparent;
                border:1px solid #e2e8f0;
                border-radius:10px;
            }
            QTableWidget {
                background:#ffffff;
                border:1px solid #e2e8f0;
                border-radius:12px;
                font-size:13px;
                font-weight:700;
            }
            QHeaderView::section {
                background:#f8fafc;
                padding:4px;
                font-weight:800;
                border:0px;
                border-bottom:1px solid #e2e8f0;
            }
            QLineEdit, QComboBox, QDateEdit {
                min-height:30px;
                border:1px solid #cbd5e1;
                border-radius:8px;
                padding:4px 10px;
                background:#f8fafc;
                font-weight:700;
                color:#111827;
            }
            QPushButton {
                min-height:30px;
                padding:4px 10px;
                border-radius:8px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:800;
            }
            QLabel#ResumenTotales {
                border-top: 1px solid #dbe2ea;
                padding: 6px 2px 4px 2px;
                font-size: 11px;
                font-weight: 700;
                color: #334155;
            }
            QPushButton#Primary {
                background:#2563eb;
                color:#ffffff;
                border:1px solid #2563eb;
            }
        """)

        self.load_filter_values()
        self.load_ventas()

    def load_filter_values(self):
        try:
            sucursales = db.fetch_sucursales_resumen_filter()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"No se pudieron cargar sucursales:\n{e}")
            sucursales = []

        try:
            usuarios = db.fetch_usuarios_resumen_filter()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"No se pudieron cargar usuarios:\n{e}")
            usuarios = []

        self.cb_sucursal.clear()
        self.cb_sucursal.addItem("TODAS")
        for s in sucursales:
            self.cb_sucursal.addItem(str(s))

        self.cb_usuario.clear()
        self.cb_usuario.addItem("TODOS")
        for u in usuarios:
            self.cb_usuario.addItem(str(u))

    def clear_filters(self):
        self.dt_desde.setDate(QDate.currentDate())
        self.dt_hasta.setDate(QDate.currentDate())
        self.cb_sucursal.setCurrentIndex(0)
        self.cb_usuario.setCurrentIndex(0)
        self.ed_barcode.clear()
        self.load_ventas()

    def load_ventas(self):
        try:
            rows = db.fetch_ventas_resumen(
                desde=self.dt_desde.date().toString("yyyy-MM-dd"),
                hasta=self.dt_hasta.date().toString("yyyy-MM-dd"),
                sucursal=self.cb_sucursal.currentText().strip(),
                caja="TODAS",
                usuario=self.cb_usuario.currentText().strip(),
            )
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo cargar ventas:\n{e}")
            return

        self.current_rows = rows
        self.tbl_ventas.setRowCount(0)
        self.tbl_detalle.setRowCount(0)
        self.current_venta_id = None

        for i, r in enumerate(rows):
            self.tbl_ventas.insertRow(i)

            self.tbl_ventas.setItem(i, 0, QTableWidgetItem(str(r.get("id", ""))))
            self.tbl_ventas.setItem(i, 1, QTableWidgetItem(str(r.get("folio", ""))))

            fecha_raw = str(r.get("fecha", ""))[:10]
            try:
                from datetime import datetime
                fecha_obj = datetime.strptime(fecha_raw, "%Y-%m-%d")
                fecha_fmt = fecha_obj.strftime("%d-%m-%Y")
            except Exception:
                fecha_fmt = fecha_raw

            self.tbl_ventas.setItem(i, 2, QTableWidgetItem(fecha_fmt))
            self.tbl_ventas.setItem(i, 3, QTableWidgetItem(str(r.get("sucursal", ""))))
            self.tbl_ventas.setItem(i, 4, QTableWidgetItem(str(r.get("cantidad", ""))))
            self.tbl_ventas.setItem(i, 5, QTableWidgetItem(_money(r.get("total", 0))))
            total_item = self.tbl_ventas.item(i, 5)
            if total_item:
                total_item.setBackground(QColor("#e8f7ea"))
            self.tbl_ventas.setItem(i, 6, QTableWidgetItem(_money(r.get("efectivo", 0))))
            self.tbl_ventas.setItem(i, 7, QTableWidgetItem(_money(r.get("debito", 0))))
            self.tbl_ventas.setItem(i, 8, QTableWidgetItem(_money(r.get("credito", 0))))
            self.tbl_ventas.setItem(i, 9, QTableWidgetItem(_money(r.get("transferencia", 0))))
            self.tbl_ventas.setItem(i, 10, QTableWidgetItem(_money(r.get("promo", 0))))
            self.tbl_ventas.setItem(i, 11, QTableWidgetItem(str(r.get("usuario", ""))))

            for col in range(self.tbl_ventas.columnCount()):
                item = self.tbl_ventas.item(i, col)
                if not item:
                    continue

                if col in (2, 6, 7, 8, 9, 11):
                    item.setFlags(item.flags() | Qt.ItemIsEditable)
                else:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)

            for col in (0, 4, 5, 6, 7, 8, 9, 10):
                it = self.tbl_ventas.item(i, col)
                if it:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

        self.lbl_info.setText(f"Registros: {len(rows)}")
        self.actualizar_totales()

    def load_detalle(self):
        row = self.tbl_ventas.currentRow()
        if row < 0:
            return

        try:
            venta_id = int(self.tbl_ventas.item(row, 0).text())
        except Exception:
            return

        self.current_venta_id = venta_id

        try:
            rows = db.fetch_venta_detalle(venta_id)
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo cargar detalle:\n{e}")
            return

        self.tbl_detalle.setRowCount(0)
        for i, r in enumerate(rows):
            self.tbl_detalle.insertRow(i)
            self.tbl_detalle.setItem(i, 0, QTableWidgetItem(str(r.get("codigo", ""))))
            self.tbl_detalle.setItem(i, 1, QTableWidgetItem(str(r.get("producto", ""))))
            self.tbl_detalle.setItem(i, 2, QTableWidgetItem(str(r.get("cantidad", ""))))
            self.tbl_detalle.setItem(i, 3, QTableWidgetItem(_money(r.get("precio", 0))))
            self.tbl_detalle.setItem(i, 4, QTableWidgetItem(_money(r.get("valor", 0))))
            self.tbl_detalle.setItem(i, 5, QTableWidgetItem(f"{float(r.get('kg', 0) or 0):.2f}"))

            for col in (2, 3, 4, 5):
                it = self.tbl_detalle.item(i, col)
                if it:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

    def _money_to_int(self, text: str) -> int:
        text = str(text or "").strip()
        digits = "".join(ch for ch in text if ch.isdigit())
        return int(digits) if digits else 0

    def on_tbl_ventas_double_clicked(self, item):
        if not item:
            return

        if item.column() == 2:
            self.editar_fecha_con_calendario(item.row())

    def editar_fecha_con_calendario(self, row: int):
        item = self.tbl_ventas.item(row, 2)
        if not item:
            return

        fecha_txt = (item.text() or "").strip()

        dlg = QDialog(self)
        dlg.setWindowTitle("Seleccionar fecha")
        dlg.setModal(True)

        lay = QVBoxLayout(dlg)

        de = QDateEdit()
        de.setCalendarPopup(True)
        de.setDisplayFormat("dd.MM.yyyy")

        parsed = None
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d.%m.%Y"):
            try:
                from datetime import datetime
                parsed = datetime.strptime(fecha_txt, fmt)
                break
            except Exception:
                pass

        if parsed:
            de.setDate(QDate(parsed.year, parsed.month, parsed.day))
        else:
            de.setDate(QDate.currentDate())

        de.calendarWidget().setSelectedDate(QDate.currentDate())

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(dlg.accept)
        buttons.rejected.connect(dlg.reject)

        lay.addWidget(de)
        lay.addWidget(buttons)

        if dlg.exec() == QDialog.Accepted:
            item.setText(de.date().toString("yyyy-MM-dd"))

    def guardar_pago_editado(self):
        row = self.tbl_ventas.currentRow()
        if row < 0:
            QMessageBox.information(self, "Info", "Seleccione una venta.")
            return

        try:
            venta_id = int(self.tbl_ventas.item(row, 0).text())
        except Exception:
            QMessageBox.warning(self, "Error", "No se pudo leer el ID de la venta.")
            return

        fecha_txt = (self.tbl_ventas.item(row, 2).text() if self.tbl_ventas.item(row, 2) else "").strip()
        usuario_txt = (self.tbl_ventas.item(row, 11).text() if self.tbl_ventas.item(row, 11) else "").strip()

        from datetime import datetime
        try:
            fecha_ok = datetime.strptime(fecha_txt, "%Y-%m-%d").strftime("%Y-%m-%d")
        except Exception:
            QMessageBox.warning(self, "Fecha", "La fecha debe tener formato YYYY-MM-DD.")
            return

        if not usuario_txt:
            QMessageBox.warning(self, "Usuario", "El usuario no puede quedar vacío.")
            return

        efectivo = self._money_to_int(self.tbl_ventas.item(row, 6).text() if self.tbl_ventas.item(row, 6) else "0")
        debito = self._money_to_int(self.tbl_ventas.item(row, 7).text() if self.tbl_ventas.item(row, 7) else "0")
        credito = self._money_to_int(self.tbl_ventas.item(row, 8).text() if self.tbl_ventas.item(row, 8) else "0")
        transferencia = self._money_to_int(self.tbl_ventas.item(row, 9).text() if self.tbl_ventas.item(row, 9) else "0")

        total = self._money_to_int(self.tbl_ventas.item(row, 5).text() if self.tbl_ventas.item(row, 5) else "0")
        suma_pagos = efectivo + debito + credito + transferencia

        if suma_pagos != total:
            QMessageBox.warning(
                self,
                "Validación",
                f"La suma de pagos ({suma_pagos}) no coincide con el total ({total})."
            )
            return

        partes = []
        if efectivo > 0:
            partes.append(f"Efectivo:{efectivo}")
        if debito > 0:
            partes.append(f"Débito:{debito}")
        if credito > 0:
            partes.append(f"Crédito:{credito}")
        if transferencia > 0:
            partes.append(f"Transferencia:{transferencia}")

        medio_pago = " | ".join(partes) if partes else "Efectivo:0"

        try:
            db.update_venta_resumen_fields(
                venta_id=venta_id,
                medio_pago=medio_pago,
                fecha=fecha_ok,
                usuario=usuario_txt,
            )
            QMessageBox.information(self, "OK", "Venta actualizada correctamente.")
            self.load_ventas()
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo guardar:\n{e}")

    def buscar_por_barcode(self):
        barcode = (self.ed_barcode.text() or "").strip()
        if not barcode:
            self.load_ventas()
            return

        try:
            venta_id = db.find_venta_id_by_barcode(barcode)
        except Exception as e:
            QMessageBox.warning(self, "DB", f"No se pudo buscar barcode:\n{e}")
            return

        if not venta_id:
            QMessageBox.information(self, "Info", "No se encontró venta para ese barcode.")
            return

        try:
            rows = db.fetch_ventas_resumen(
                desde=self.dt_desde.date().toString("yyyy-MM-dd"),
                hasta=self.dt_hasta.date().toString("yyyy-MM-dd"),
                sucursal=self.cb_sucursal.currentText().strip(),
                caja="TODAS",
                usuario=self.cb_usuario.currentText().strip(),
                venta_id=venta_id,
            )
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo cargar ventas:\n{e}")
            return

        self.current_rows = rows
        self.tbl_ventas.setRowCount(0)
        self.tbl_detalle.setRowCount(0)
        self.current_venta_id = None

        for i, r in enumerate(rows):
            self.tbl_ventas.insertRow(i)

            self.tbl_ventas.setItem(i, 0, QTableWidgetItem(str(r.get("id", ""))))
            self.tbl_ventas.setItem(i, 1, QTableWidgetItem(str(r.get("folio", ""))))
            self.tbl_ventas.setItem(i, 2, QTableWidgetItem(str(r.get("fecha", ""))))
            self.tbl_ventas.setItem(i, 3, QTableWidgetItem(str(r.get("sucursal", ""))))
            self.tbl_ventas.setItem(i, 4, QTableWidgetItem(str(r.get("cantidad", ""))))
            self.tbl_ventas.setItem(i, 5, QTableWidgetItem(_money(r.get("total", 0))))
            self.tbl_ventas.setItem(i, 6, QTableWidgetItem(_money(r.get("efectivo", 0))))
            self.tbl_ventas.setItem(i, 7, QTableWidgetItem(_money(r.get("debito", 0))))
            self.tbl_ventas.setItem(i, 8, QTableWidgetItem(_money(r.get("credito", 0))))
            self.tbl_ventas.setItem(i, 9, QTableWidgetItem(_money(r.get("transferencia", 0))))
            self.tbl_ventas.setItem(i, 10, QTableWidgetItem(_money(r.get("promo", 0))))
            self.tbl_ventas.setItem(i, 11, QTableWidgetItem(str(r.get("usuario", ""))))

            for col in (0, 4, 5, 6, 7, 8, 9, 10):
                it = self.tbl_ventas.item(i, col)
                if it:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

        self.lbl_info.setText(f"Registros: {len(rows)}")
        self.actualizar_totales()

        if rows:
            self.tbl_ventas.selectRow(0)
            self.load_detalle()

    def get_selected_row_data(self) -> Optional[Dict[str, Any]]:
        row = self.tbl_ventas.currentRow()
        if row < 0:
            return None

        try:
            venta_id = int(self.tbl_ventas.item(row, 0).text())
        except Exception:
            return None

        for r in self.current_rows:
            if int(r.get("id", 0) or 0) == venta_id:
                return r
        return None

    def editar_pago(self):
        venta = self.get_selected_row_data()
        if not venta:
            QMessageBox.information(self, "Info", "Selecciona una venta.")
            return

        dlg = EditarPagoDialog(self, venta)
        if dlg.exec() != QDialog.Accepted:
            return

        data = dlg.get_data()

        try:
            db.update_venta_pago(
                venta_id=int(venta["id"]),
                medio_pago=data["medio_pago"],
                promo=int(data["promo"]),
            )
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo actualizar pago:\n{e}")
            return

        QMessageBox.information(self, "OK", "Pago actualizado.")
        self.load_ventas()

    def reimprimir(self):
        venta = self.get_selected_row_data()
        if not venta:
            QMessageBox.information(self, "Info", "Selecciona una venta.")
            return
        QMessageBox.information(self, "Info", f"Reimprimir venta ID {venta['id']} (pendiente conectar impresora).")

    def anular_venta(self):
        venta = self.get_selected_row_data()
        if not venta:
            QMessageBox.information(self, "Info", "Selecciona una venta.")
            return

        ans = QMessageBox.question(
            self,
            "Confirmar",
            f"¿Anular venta ID {venta['id']}?"
        )
        if ans != QMessageBox.Yes:
            return

        try:
            db.anular_venta(int(venta["id"]))
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo anular venta:\n{e}")
            return

        QMessageBox.information(self, "OK", "Venta anulada.")
        self.load_ventas()

    def exportar_excel(self):
        QMessageBox.information(self, "Info", "Exportar Excel (lo conectamos en el siguiente paso).")

    def actualizar_totales(self):
        rows = getattr(self, "current_rows", []) or []

        total_boletas = len(rows)
        total_productos = sum(int(r.get("cantidad", 0) or 0) for r in rows)
        total_ventas = sum(int(r.get("total", 0) or 0) for r in rows)
        total_efectivo = sum(int(r.get("efectivo", 0) or 0) for r in rows)
        total_debito = sum(int(r.get("debito", 0) or 0) for r in rows)
        total_credito = sum(int(r.get("credito", 0) or 0) for r in rows)
        total_transferencia = sum(int(r.get("transferencia", 0) or 0) for r in rows)
        total_promocion = sum(int(r.get("promo", 0) or 0) for r in rows)

        self.lbl_totales.setText(
            "Boletas: {boletas}   |   "
            "Productos: {productos}   |   "
            "Total ventas: {ventas}   |   "
            "Efectivo: {efectivo}   |   "
            "Débito: {debito}   |   "
            "Crédito: {credito}   |   "
            "Transferencia: {transferencia}   |   "
            "Promoción: {promo}".format(
                boletas=total_boletas,
                productos=total_productos,
                ventas=_money(total_ventas),
                efectivo=_money(total_efectivo),
                debito=_money(total_debito),
                credito=_money(total_credito),
                transferencia=_money(total_transferencia),
                promo=_money(total_promocion),
            )
        )


if __name__ == "__main__":
    import sys
    from PySide6.QtWidgets import QApplication

    app = QApplication(sys.argv)
    window = VentasResumenScreen()
    window.show()
    sys.exit(app.exec())