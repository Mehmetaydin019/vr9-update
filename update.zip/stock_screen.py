from __future__ import annotations

import db

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
        QSplitter
    )
except Exception:
    from PyQt5.QtCore import Qt
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
        QSplitter
    )


def _fmt_clp(n: int) -> str:
    try:
        n = int(n)
    except Exception:
        n = 0
    return f"{n:,}".replace(",", ".")


class StockScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(10)

        title = QLabel("Stock")
        title.setStyleSheet("font-size:26px;font-weight:900;")
        root.addWidget(title)

        desc = QLabel("Sacos guardados en stock y detalle de líneas.")
        desc.setStyleSheet("color:#64748b;font-size:14px;")
        root.addWidget(desc)

        top = QHBoxLayout()
        self.btn_reload = QPushButton("🔄 Actualizar")
        self.btn_reload.clicked.connect(self.load_batches)
        top.addStretch(1)
        top.addWidget(self.btn_reload)
        root.addLayout(top)

        splitter = QSplitter(Qt.Vertical)

        # -------------------------
        # TOP TABLE = batches
        # -------------------------
        self.tbl = QTableWidget(0, 7)
        self.tbl.setHorizontalHeaderLabels([
            "ID", "Fecha", "Sucursal", "Saco", "Categoría", "Items", "Total"
        ])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl.itemSelectionChanged.connect(self.on_pick_batch)

        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(6, QHeaderView.ResizeToContents)

        splitter.addWidget(self.tbl)

        # -------------------------
        # BOTTOM AREA
        # -------------------------
        bottom = QWidget()
        bottom_lay = QVBoxLayout(bottom)
        bottom_lay.setContentsMargins(0, 0, 0, 0)
        bottom_lay.setSpacing(8)

        self.lbl_detail = QLabel("Detalle del saco seleccionado")
        self.lbl_detail.setStyleSheet("font-size:18px;font-weight:900;")
        bottom_lay.addWidget(self.lbl_detail)

        self.tbl_lines = QTableWidget(0, 5)
        self.tbl_lines.setHorizontalHeaderLabels([
            "Barcode", "Producto", "Género", "Descripción", "Precio"
        ])
        self.tbl_lines.verticalHeader().setVisible(False)

        hh2 = self.tbl_lines.horizontalHeader()
        hh2.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh2.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        hh2.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        hh2.setSectionResizeMode(3, QHeaderView.Stretch)
        hh2.setSectionResizeMode(4, QHeaderView.ResizeToContents)

        bottom_lay.addWidget(self.tbl_lines, 1)

        splitter.addWidget(bottom)
        splitter.setSizes([320, 320])

        root.addWidget(splitter, 1)

        self.load_batches()

    def load_batches(self):
        try:
            rows = db.list_stock_batches()
        except Exception as e:
            QMessageBox.critical(self, "DB Error", str(e))
            return

        self.tbl.setRowCount(0)
        self.tbl_lines.setRowCount(0)
        self.lbl_detail.setText("Detalle del saco seleccionado")

        for i, r in enumerate(rows):
            self.tbl.insertRow(i)

            sucursal_nombre = ""
            sid = r.get("sucursal_id")
            if sid:
                try:
                    s = db.get_sucursal_by_id(int(sid))
                    if s:
                        sucursal_nombre = s.get("nombre", "")
                except Exception:
                    sucursal_nombre = ""

            item_id = QTableWidgetItem(str(r.get("id6", "")))
            item_id.setData(Qt.UserRole, str(r.get("id6", "")))

            self.tbl.setItem(i, 0, item_id)
            self.tbl.setItem(i, 1, QTableWidgetItem(str(r.get("created_at", ""))))
            self.tbl.setItem(i, 2, QTableWidgetItem(sucursal_nombre))
            self.tbl.setItem(i, 3, QTableWidgetItem(str(r.get("saco_codigo", ""))))
            self.tbl.setItem(i, 4, QTableWidgetItem(str(r.get("categoria", ""))))
            self.tbl.setItem(i, 5, QTableWidgetItem(str(r.get("total_items", 0))))
            self.tbl.setItem(i, 6, QTableWidgetItem(_fmt_clp(r.get("total_precio", 0))))

    def on_pick_batch(self):
        row = self.tbl.currentRow()
        if row < 0:
            return

        item = self.tbl.item(row, 0)
        if not item:
            return

        batch_id6 = item.data(Qt.UserRole)
        if not batch_id6:
            return

        try:
            lines = db.get_stock_batch_lines(str(batch_id6))
        except Exception as e:
            QMessageBox.critical(self, "DB Error", str(e))
            return

        self.tbl_lines.setRowCount(0)
        self.lbl_detail.setText(f"Detalle del saco: {batch_id6}")

        for i, r in enumerate(lines):
            self.tbl_lines.insertRow(i)
            self.tbl_lines.setItem(i, 0, QTableWidgetItem(str(r.get("barcode", ""))))
            self.tbl_lines.setItem(i, 1, QTableWidgetItem(str(r.get("producto", ""))))
            self.tbl_lines.setItem(i, 2, QTableWidgetItem(str(r.get("genero", ""))))
            self.tbl_lines.setItem(i, 3, QTableWidgetItem(str(r.get("descripcion", ""))))
            self.tbl_lines.setItem(i, 4, QTableWidgetItem(_fmt_clp(r.get("precio", 0))))