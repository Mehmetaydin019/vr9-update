from licensing.methods import Key, Helpers

TOKEN = "WyIxMTg0OTQxMzAiLCJWWGI3OHpsZEJOQjRUckRtRFZlL0tNQXd4WFZubWhhRE1Ra2ZlMFZBIl0="
PRODUCT_ID = 32337
RSA_PUB_KEY = """<RSAKeyValue><Modulus>zAju6XVLCGQXhfHiVxfmZh0yGVLj5hhfye/NAr948meKQU2EOEBOTrS7geD4gEoYL7+M6KEGrXqImOuWmLL5wHRVhzfsl3vUcG9ULRMRSYHTB66Wfmxg8cd0DWKdECUCPgKnGPFoJho2jK/SHRtVYApdEf60eP8VJzcnFRMqrhjMFYydleDxWJodOHYn9B1PmqCq4W2SHBR25iTRVrUPZAtrfh2XCMCacYG4lo/CAjN3idXE5WKtspGP1RGI2rIVbcSQPDhv3j/o1nK99Bfiv12wMb3wgVFa5JiXCIniLTk0GgWf0LngVsx2f/xnBKPsIoHtanAW8KntXRqzD7PZuQ==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>"""

def check_license(license_key: str) -> bool:
    print("DEBUG RSA len:", len(RSA_PUB_KEY))
    print("DEBUG RSA start:", RSA_PUB_KEY[:40])
    print("DEBUG RSA end:", RSA_PUB_KEY[-40:])

    result = Key.activate(
        token=TOKEN,
        rsa_pub_key=RSA_PUB_KEY,
        product_id=PRODUCT_ID,
        key=license_key,
        machine_code=Helpers.GetMachineCode(v=2),
    )

    if result is None or result[0] is None:
        return False

    if not Helpers.IsOnRightMachine(result[0], v=2):
        return False

    return True