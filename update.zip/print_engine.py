from __future__ import annotations

import win32print
from PySide6.QtGui import QPixmap, QPainter, QPen, QFont
from PySide6.QtCore import Qt, QRect


def get_default_printer() -> str | None:
    try:
        return win32print.GetDefaultPrinter()
    except Exception:
        return None


def detect_printer_language(printer_name: str | None = None) -> str:
    name = (printer_name or get_default_printer() or "").lower()

    if "zebra" in name:
        return "ZPL"

    if any(x in name for x in ["tsc", "xprinter", "godex", "gprinter", "gp-"]):
        return "TSPL"

    return "ZPL"


def send_raw(raw_data: bytes, printer_name: str | None = None, doc_name: str = "ETIQUETA") -> None:
    printer = printer_name or get_default_printer()
    if not printer:
        raise RuntimeError("Varsayılan yazıcı bulunamadı.")

    hprinter = win32print.OpenPrinter(printer)
    try:
        win32print.StartDocPrinter(hprinter, 1, (doc_name, None, "RAW"))
        win32print.StartPagePrinter(hprinter)
        win32print.WritePrinter(hprinter, raw_data)
        win32print.EndPagePrinter(hprinter)
        win32print.EndDocPrinter(hprinter)
    finally:
        win32print.ClosePrinter(hprinter)


def _safe_text(v) -> str:
    return str(v or "").replace("\n", " ").replace("\r", " ").strip()


def _kg_text(v) -> str:
    try:
        x = float(v or 0)
        return f"{x:.3f}".rstrip("0").rstrip(".")
    except Exception:
        return "0"


def _split_desc_words(text: str, max_len: int = 24) -> tuple[str, str]:
    words = _safe_text(text).split()
    line1 = ""
    line2 = ""

    for w in words:
        test1 = w if not line1 else f"{line1} {w}"
        if len(test1) <= max_len:
            line1 = test1
            continue

        test2 = w if not line2 else f"{line2} {w}"
        if len(test2) <= max_len:
            line2 = test2
            continue

        break

    return line1, line2


# --------------------------------------------------
# SHARED LAYOUT VALUES
# Bunlar preview için de kullanılabilir
# --------------------------------------------------
LABEL_W = 410
LABEL_H = 840

X_PROD = 125
Y_PROD = 110

X_SACO = 30
Y_SACO = 160

X_TALLA = 280
Y_TALLA = 160

BOX_X1 = 30
BOX_Y1 = 195
BOX_X2 = 335
BOX_Y2 = 245

MID_X = 195
MID_Y = 195
MID_W = 1
MID_H = 50

X_FECHA = 55
Y_FECHA = 210

X_KG = 255
Y_KG = 210

X_DESC = 30
Y_DESC1 = 255
Y_DESC2 = 285

X_BARCODE = 55
Y_BARCODE = 700
BARCODE_H = 100

X_BARCODE_TEXT = 30
Y_BARCODE_TEXT = 605

X_PRECIO = 75
Y_PRECIO = 735


def build_tspl_label(row: dict) -> bytes:
    saco = _safe_text(row.get("saco"))
    talla = _safe_text(row.get("talla"))
    production_no = str(row.get("production_no", "") or "").strip()
    kg_txt = _kg_text(row.get("kg"))
    desc = _safe_text(row.get("descripcion"))
    precio = _safe_text(row.get("precio"))
    barcode = _safe_text(row.get("barcode"))
    fecha = _safe_text(row.get("fecha"))

    line1, line2 = _split_desc_words(desc, 24)

    tspl = f"""
SIZE 45 mm,105 mm
GAP 2 mm,0 mm
DIRECTION 1
CLS

TEXT {X_PROD},{Y_PROD},"0",0,10,10,"{production_no}"

TEXT {X_SACO},{Y_SACO},"0",0,10,10,"{saco}"


BOX {BOX_X1},{BOX_Y1},{BOX_X2},{BOX_Y2},1
BAR {MID_X},{MID_Y},{MID_W},{MID_H}

TEXT {X_FECHA},{Y_FECHA},"0",0,10,10,"{fecha}"
TEXT {X_KG},{Y_KG},"0",0,10,10,"{kg_txt}"

TEXT {X_DESC},{Y_DESC1},"0",0,10,10,"{line1}"
TEXT {X_DESC},{Y_DESC2},"0",0,10,10,"{line2}"

BARCODE {X_BARCODE},{Y_BARCODE},"128",{BARCODE_H},0,270,3,0,"{barcode}"
TEXT {X_BARCODE_TEXT},{Y_BARCODE_TEXT},"0",270,10,10,"{barcode}"

TEXT {X_PRECIO},{Y_PRECIO},"0",0,22,22,"$ {precio}"

PRINT 1,1
"""
    return tspl.encode("utf-8", errors="ignore")


def build_zpl_label(row: dict) -> bytes:
    saco = _safe_text(row.get("saco"))
    talla = _safe_text(row.get("talla"))
    production_no = str(row.get("production_no", "") or "").strip()
    kg_txt = _kg_text(row.get("kg"))
    desc = _safe_text(row.get("descripcion"))
    precio = _safe_text(row.get("precio"))
    barcode = _safe_text(row.get("barcode"))
    fecha = _safe_text(row.get("fecha"))

    line1, line2 = _split_desc_words(desc, 24)

    zpl = f"""
^XA
^PW360
^LL840
^LH0,0
^LS50,0

^FO180,110^A0N,28,28^FD{production_no}^FS

^FO70,160^A0N,28,28^FD{saco}^FS

^FO60,200^GB320,50,2^FS
^FO260,200^GB0,50,2^FS

^FO95,215^A0N,26,26^FD{fecha}^FS
^FO310,215^A0N,26,26^FD{kg_txt}^FS

^FO60,255^A0N,26,26^FD{line1}^FS
^FO60,285^A0N,26,26^FD{line2}^FS

^BY2,2,90
^FO95,320^BCB,100,N,N,N^FD{barcode}^FS
^FO60,420^A0B,28,28^FD{barcode}^FS

^FO130,705^A0N,58,58^FD$ {precio}^FS

^XZ
"""
    return zpl.encode("utf-8", errors="ignore")


def print_label(row: dict, printer_name: str | None = None) -> None:
    printer = printer_name or get_default_printer()
    if not printer:
        raise RuntimeError("Varsayılan yazıcı bulunamadı.")

    lang = detect_printer_language(printer)

    if lang == "ZPL":
        raw = build_zpl_label(row)
    else:
        raw = build_tspl_label(row)

    send_raw(raw, printer_name=printer)


# --------------------------------------------------
# Preview (yaklaşık görsel)
# Not: Bu baskının kendisi değil, sadece ön izleme için
# --------------------------------------------------
def build_label_preview_pixmap(row: dict) -> QPixmap:
    saco = _safe_text(row.get("saco"))
    talla = _safe_text(row.get("talla"))
    production_no = str(row.get("production_no", "") or "").strip()
    kg_txt = _kg_text(row.get("kg"))
    desc = _safe_text(row.get("descripcion"))
    precio = _safe_text(row.get("precio"))
    barcode = _safe_text(row.get("barcode"))
    fecha = _safe_text(row.get("fecha"))

    line1, line2 = _split_desc_words(desc, 24)

    w, h = LABEL_W, LABEL_H
    pix = QPixmap(w, h)
    pix.fill(Qt.white)

    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.TextAntialiasing, True)

    # dış sınır
    p.setPen(QPen(Qt.lightGray, 1, Qt.DashLine))
    p.drawRect(1, 1, w - 2, h - 2)

    p.setPen(QPen(Qt.black, 2))

    # production no
    f = QFont("Arial", 16, QFont.Bold)
    p.setFont(f)
    p.drawText(X_PROD, Y_PROD, production_no)

    # saco / talla
    f = QFont("Arial", 22, QFont.Bold)
    p.setFont(f)
    p.drawText(X_SACO, Y_SACO, saco)

    # kutu
    p.drawRect(BOX_X1, BOX_Y1, BOX_X2 - BOX_X1, BOX_Y2 - BOX_Y1)

    # orta çizgi
    p.fillRect(MID_X, MID_Y, MID_W, MID_H, Qt.black)

    # fecha / kg
    f = QFont("Arial", 16, QFont.Bold)
    p.setFont(f)
    p.drawText(X_FECHA, Y_FECHA + 10, fecha)
    p.drawText(X_KG, Y_KG + 10, kg_txt)

    # açıklama
    f = QFont("Arial", 15, QFont.Bold)
    p.setFont(f)
    p.drawText(X_DESC, Y_DESC1, line1)
    p.drawText(X_DESC, Y_DESC2, line2)

    # barkod alanı placeholder
    barcode_area_x = X_BARCODE
    barcode_area_y = Y_BARCODE - BARCODE_H
    barcode_area_w = 170
    barcode_area_h = BARCODE_H

    pattern = [2, 1, 3, 2, 1, 1, 4, 2, 1, 3, 2, 2, 1, 4, 2, 1, 3, 1, 2, 4, 1, 2, 3, 1, 2, 2, 4, 1]
    x = barcode_area_x

    p.setPen(Qt.NoPen)
    for i, bw in enumerate(pattern * 4):
        if x > barcode_area_x + barcode_area_w:
            break
        if i % 2 == 0:
            p.fillRect(x, barcode_area_y, bw * 2, barcode_area_h, Qt.black)
        x += bw * 2

    # barkod numarası
    p.setPen(QPen(Qt.black, 1))
    f = QFont("Arial", 11, QFont.Bold)
    p.setFont(f)
    text_rect = QRect(X_BARCODE_TEXT, Y_BARCODE_TEXT - 18, 170, 24)
    p.drawText(text_rect, Qt.AlignCenter, barcode)

    # fiyat
    f = QFont("Arial", 42, QFont.Bold)
    p.setFont(f)
    p.drawText(X_PRECIO, Y_PRECIO + 25, f"$ {precio}")

    p.end()
    return pix