from __future__ import annotations

from typing import Dict, Any, List

from PySide6.QtCore import Qt, QDate
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame,
    QComboBox, QDateEdit, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QGridLayout
)

import db


class OfertasScreen(QWidget):
    def __init__(self):
        super().__init__()

        self.current_edit_id = None
        self._row_map = {}

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)

        # ================= FILTER CARD =================
        filter_card = QFrame()
        filter_card.setObjectName("offerFilterCard")
        filter_layout = QVBoxLayout(filter_card)
        filter_layout.setContentsMargins(18, 16, 18, 16)
        filter_layout.setSpacing(12)

        filter_title = QLabel("Configuración de Oferta")
        filter_title.setObjectName("offerSectionTitle")
        filter_layout.addWidget(filter_title)

        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(10)

        self.dt_desde = QDateEdit()
        self.dt_desde.setCalendarPopup(True)
        self.dt_desde.setDisplayFormat("dd.MM.yyyy")
        self.dt_desde.setDate(QDate.currentDate())
        self.dt_desde.setMinimumHeight(38)

        self.dt_hasta = QDateEdit()
        self.dt_hasta.setCalendarPopup(True)
        self.dt_hasta.setDisplayFormat("dd.MM.yyyy")
        self.dt_hasta.setDate(QDate.currentDate())
        self.dt_hasta.setMinimumHeight(38)

        self.cb_saco = QComboBox()
        self.cb_categoria = QComboBox()
        self.cb_producto = QComboBox()

        self.cb_desc = QComboBox()
        self.cb_desc.addItems([
            "20%",
            "30%",
            "40%",
            "50%",
            "60%",
            "70%",
            "2x1",
            "3x1",
            "3x2",
            "4x3",
            "2do %30",
            "2do %50",
            "2do %70"
        ])
        self.cb_desc.setCurrentText("50%")
        self.cb_desc.setMinimumHeight(38)

        self.btn_guardar = QPushButton("Guardar Oferta")
        self.btn_guardar.setObjectName("Primary")
        self.btn_guardar.setMinimumHeight(38)
        self.btn_guardar.clicked.connect(self.guardar_oferta)

        self.btn_cancel_edit = QPushButton("Cancelar Edición")
        self.btn_cancel_edit.setObjectName("GhostBtn")
        self.btn_cancel_edit.setMinimumHeight(38)
        self.btn_cancel_edit.clicked.connect(self.reset_form)
        self.btn_cancel_edit.hide()

        def make_label(text: str):
            lbl = QLabel(text)
            lbl.setObjectName("offerFieldLabel")
            return lbl

        fields = [
            (0, 0, make_label("Desde"), self.dt_desde),
            (0, 1, make_label("Hasta"), self.dt_hasta),
            (0, 2, make_label("Saco"), self.cb_saco),
            (0, 3, make_label("Categoría"), self.cb_categoria),
            (0, 4, make_label("Producto"), self.cb_producto),
            (0, 5, make_label("Descuento"), self.cb_desc),
        ]

        for row, col, lbl, widget in fields:
            cell = QVBoxLayout()
            cell.setSpacing(5)
            cell.addWidget(lbl)
            cell.addWidget(widget)
            wrap = QWidget()
            wrap.setLayout(cell)
            grid.addWidget(wrap, row, col)

        right_actions = QVBoxLayout()
        right_actions.setSpacing(8)
        right_actions.addStretch(1)
        right_actions.addWidget(self.btn_guardar)
        right_actions.addWidget(self.btn_cancel_edit)
        right_actions.addStretch(1)

        right_actions_widget = QWidget()
        right_actions_widget.setLayout(right_actions)

        grid.addWidget(right_actions_widget, 0, 6)

        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        grid.setColumnStretch(2, 1)
        grid.setColumnStretch(3, 1)
        grid.setColumnStretch(4, 1)
        grid.setColumnStretch(5, 1)
        grid.setColumnStretch(6, 0)

        filter_layout.addLayout(grid)
        root.addWidget(filter_card)

        # ================= TABLE CARD =================
        table_card = QFrame()
        table_card.setObjectName("offerTableCard")
        table_layout = QVBoxLayout(table_card)
        table_layout.setContentsMargins(14, 14, 14, 14)
        table_layout.setSpacing(10)

        table_top = QHBoxLayout()
        table_top.setSpacing(10)

        table_title = QLabel("Ofertas Registradas")
        table_title.setObjectName("offerSectionTitle")
        table_top.addWidget(table_title)

        table_top.addStretch(1)

        estado_label = QLabel("Estado")
        estado_label.setObjectName("offerFieldLabel")
        table_top.addWidget(estado_label)

        self.cb_estado = QComboBox()
        self.cb_estado.addItems(["TODOS", "ACTIVAS", "INACTIVAS"])
        self.cb_estado.setCurrentText("TODOS")
        self.cb_estado.setMinimumWidth(150)
        self.cb_estado.setMaximumWidth(170)
        self.cb_estado.setMinimumHeight(38)
        self.cb_estado.currentTextChanged.connect(self.load_table)

        table_top.addWidget(self.cb_estado)
        table_layout.addLayout(table_top)

        self.table = QTableWidget(0, 10)
        self.table.setObjectName("offerTable")
        self.table.setHorizontalHeaderLabels([
            "ID", "Desde", "Hasta", "Saco", "Categoría", "Producto", "Tipo", "Valor", "Desc %", "Activo"
        ])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setFocusPolicy(Qt.StrongFocus)
        self.table.itemDoubleClicked.connect(self.edit_selected_oferta)

        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(8, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(9, QHeaderView.ResizeMode.ResizeToContents)

        table_layout.addWidget(self.table, 1)
        root.addWidget(table_card, 1)

        # ================= ACTION BAR =================
        action_card = QFrame()
        action_card.setObjectName("offerActionCard")
        action_layout = QHBoxLayout(action_card)
        action_layout.setContentsMargins(14, 12, 14, 12)
        action_layout.setSpacing(10)

        self.btn_activar = QPushButton("Activar / Desactivar")
        self.btn_eliminar = QPushButton("Eliminar")
        self.btn_refresh = QPushButton("Actualizar")

        self.btn_activar.setObjectName("SuccessBtn")
        self.btn_eliminar.setObjectName("DangerBtn")
        self.btn_refresh.setObjectName("GhostBtn")

        self.btn_activar.setMinimumHeight(40)
        self.btn_eliminar.setMinimumHeight(40)
        self.btn_refresh.setMinimumHeight(40)

        self.btn_activar.clicked.connect(self.toggle_oferta)
        self.btn_eliminar.clicked.connect(self.delete_oferta)
        self.btn_refresh.clicked.connect(self.load_data)

        action_layout.addWidget(self.btn_activar)
        action_layout.addWidget(self.btn_eliminar)
        action_layout.addStretch(1)
        action_layout.addWidget(self.btn_refresh)

        root.addWidget(action_card)

        self.setStyleSheet("""
            QFrame#offerFilterCard, QFrame#offerTableCard, QFrame#offerActionCard {
                background: #ffffff;
                border: 1px solid #dbe2ea;
                border-radius: 18px;
            }

            QLabel#offerSectionTitle {
                font-size: 18px;
                font-weight: 900;
                color: #0f172a;
            }

            QLabel#offerFieldLabel {
                font-size: 12px;
                font-weight: 800;
                color: #64748b;
                padding-left: 2px;
            }

            QComboBox, QDateEdit, QLineEdit {
                min-height: 38px;
                max-height: 38px;
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                padding: 4px 10px;
                background: #ffffff;
                color: #0f172a;
                font-size: 14px;
                font-weight: 700;
            }

            QComboBox:focus, QDateEdit:focus, QLineEdit:focus {
                border: 2px solid #2563eb;
            }

            QComboBox::drop-down, QDateEdit::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 22px;
                border: none;
                margin-right: 6px;
                background: transparent;
            }

            QPushButton {
                min-height: 38px;
                max-height: 38px;
                padding: 6px 14px;
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
                color: #0f172a;
                font-size: 14px;
                font-weight: 900;
            }

            QPushButton:hover {
                background: #f8fafc;
            }

            QPushButton#Primary {
                background: #2563eb;
                border: 1px solid #2563eb;
                color: white;
                padding: 6px 18px;
            }

            QPushButton#Primary:hover {
                background: #1d4ed8;
            }

            QPushButton#SuccessBtn {
                background: #ffffff;
                border: 1px solid #bbf7d0;
                color: #166534;
            }

            QPushButton#SuccessBtn:hover {
                background: #f0fdf4;
            }

            QPushButton#DangerBtn {
                background: #ffffff;
                border: 1px solid #fecaca;
                color: #b91c1c;
            }

            QPushButton#DangerBtn:hover {
                background: #fef2f2;
            }

            QPushButton#GhostBtn {
                background: #ffffff;
                border: 1px solid #cbd5e1;
                color: #334155;
            }

            QPushButton#GhostBtn:hover {
                background: #f8fafc;
            }

            QTableWidget#offerTable {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                font-size: 14px;
                color: #0f172a;
                gridline-color: transparent;
                alternate-background-color: #f8fafc;
                selection-background-color: #bfdbfe;
                selection-color: #0f172a;
            }

            QTableWidget#offerTable::item {
                padding: 8px;
                border-bottom: 1px solid #eef2f7;
            }

            QTableWidget#offerTable::item:selected {
                background: #bfdbfe;
                color: #0f172a;
            }

            QHeaderView::section {
                background: #f8fafc;
                padding: 10px;
                font-weight: 900;
                color: #334155;
                border: 0px;
                border-bottom: 1px solid #e2e8f0;
            }
        """)

        self.load_data()

    def _fmt_date(self, value: str) -> str:
        value = (value or "").strip()
        if not value:
            return ""
        parts = value.split("-")
        if len(parts) == 3:
            yyyy, mm, dd = parts
            return f"{dd}.{mm}.{yyyy}"
        return value

    def _date_to_qdate(self, value: str) -> QDate:
        value = (value or "").strip()
        if not value:
            return QDate.currentDate()

        dt = QDate.fromString(value, "yyyy-MM-dd")
        if dt.isValid():
            return dt

        dt = QDate.fromString(value, "dd.MM.yyyy")
        if dt.isValid():
            return dt

        return QDate.currentDate()

    def _ensure_combo_value(self, combo: QComboBox, value: str):
        value = (value or "").strip()
        if not value:
            combo.setCurrentIndex(0)
            return

        idx = combo.findText(value, Qt.MatchFixedString)
        if idx >= 0:
            combo.setCurrentIndex(idx)
        else:
            combo.addItem(value)
            combo.setCurrentText(value)

    def _selection_to_offer_parts(self, sel: str):
        sel = (sel or "").strip()

        tipo_oferta = "PCT"
        valor_oferta = ""
        descuento_pct = 0

        if sel.endswith("%") and not sel.startswith("2do "):
            tipo_oferta = "PCT"
            descuento_pct = int(sel.replace("%", "").strip())
            valor_oferta = str(descuento_pct)

        elif sel in ("2x1", "3x1", "3x2", "4x3"):
            tipo_oferta = "XFOR"
            valor_oferta = sel
            descuento_pct = 0

        elif sel.startswith("2do "):
            tipo_oferta = "SECOND_PCT"
            valor_oferta = sel.replace("2do ", "").strip()
            descuento_pct = int(valor_oferta.replace("%", "").strip())

        return tipo_oferta, valor_oferta, descuento_pct

    def _row_to_desc_text(self, row: dict) -> str:
        tipo = str(row.get("tipo_oferta", "PCT") or "PCT")
        valor = str(row.get("valor_oferta", "") or "")
        desc = str(row.get("descuento_pct", 0) or 0)

        if tipo == "PCT":
            return f"{desc}%"
        if tipo == "XFOR":
            return valor
        if tipo == "SECOND_PCT":
            if valor and not valor.startswith("2do "):
                return f"2do {valor}"
            return valor or f"2do %{desc}"
        return valor or f"{desc}%"

    def reset_form(self):
        self.current_edit_id = None
        self.dt_desde.setDate(QDate.currentDate())
        self.dt_hasta.setDate(QDate.currentDate())

        if self.cb_saco.count() > 0:
            self.cb_saco.setCurrentIndex(0)
        if self.cb_categoria.count() > 0:
            self.cb_categoria.setCurrentIndex(0)
        if self.cb_producto.count() > 0:
            self.cb_producto.setCurrentIndex(0)

        self.cb_desc.setCurrentText("50%")
        self.btn_guardar.setText("Guardar Oferta")
        self.btn_cancel_edit.hide()
        self.table.clearSelection()

    def load_filters(self):
        self.cb_categoria.clear()
        self.cb_categoria.addItem("TODOS")

        try:
            for r in db.list_categorias():
                nombre = r.get("nombre") if isinstance(r, dict) else str(r)
                if nombre:
                    self.cb_categoria.addItem(str(nombre))
        except Exception:
            pass

        self.cb_saco.clear()
        self.cb_producto.clear()

        self.cb_saco.addItem("TODOS")
        self.cb_producto.addItem("TODOS")

        try:
            for r in db.list_sacos():
                self.cb_saco.addItem(str(r.get("codigo", "")))
        except Exception:
            pass

        try:
            for r in db.list_productos():
                nombre = r.get("nombre") if isinstance(r, dict) else str(r)
                if nombre:
                    self.cb_producto.addItem(str(nombre))
        except Exception:
            pass

    def load_table(self):
        try:
            rows = db.list_ofertas()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"Ofertas yüklenemedi:\n{e}")
            rows = []

        estado = self.cb_estado.currentText().strip() if hasattr(self, "cb_estado") else "TODOS"

        if estado == "ACTIVAS":
            rows = [r for r in rows if int(r.get("activo", 1) or 0) == 1]
        elif estado == "INACTIVAS":
            rows = [r for r in rows if int(r.get("activo", 1) or 0) == 0]

        self._row_map = {}
        self.table.setRowCount(0)

        for i, row in enumerate(rows):
            oferta_id = int(row.get("id", 0) or 0)
            self._row_map[oferta_id] = row

            self.table.insertRow(i)

            tipo = str(row.get("tipo_oferta", "PCT") or "PCT")
            valor = str(row.get("valor_oferta", "") or "")
            desc = str(row.get("descuento_pct", 0) or 0)

            self.table.setItem(i, 0, QTableWidgetItem(str(oferta_id)))
            self.table.setItem(i, 1, QTableWidgetItem(self._fmt_date(str(row.get("fecha_desde", "")))))
            self.table.setItem(i, 2, QTableWidgetItem(self._fmt_date(str(row.get("fecha_hasta", "")))))
            self.table.setItem(i, 3, QTableWidgetItem(str(row.get("saco", ""))))
            self.table.setItem(i, 4, QTableWidgetItem(str(row.get("categoria", ""))))
            self.table.setItem(i, 5, QTableWidgetItem(str(row.get("producto", ""))))
            self.table.setItem(i, 6, QTableWidgetItem(tipo))
            self.table.setItem(i, 7, QTableWidgetItem(valor))
            self.table.setItem(i, 8, QTableWidgetItem(desc))
            self.table.setItem(i, 9, QTableWidgetItem("Sí" if int(row.get("activo", 1) or 0) == 1 else "No"))

    def load_data(self):
        self.load_filters()
        self.load_table()
        self.reset_form()

    def edit_selected_oferta(self):
        oferta_id = self._current_id()
        if oferta_id is None:
            return

        row = self._row_map.get(oferta_id)
        if not row:
            return

        self.current_edit_id = oferta_id
        self.dt_desde.setDate(self._date_to_qdate(str(row.get("fecha_desde", ""))))
        self.dt_hasta.setDate(self._date_to_qdate(str(row.get("fecha_hasta", ""))))

        self._ensure_combo_value(self.cb_saco, str(row.get("saco", "")))
        self._ensure_combo_value(self.cb_categoria, str(row.get("categoria", "")))
        self._ensure_combo_value(self.cb_producto, str(row.get("producto", "")))

        self.cb_desc.setCurrentText(self._row_to_desc_text(row))

        self.btn_guardar.setText("Actualizar Oferta")
        self.btn_cancel_edit.show()

    def guardar_oferta(self):
        fecha_desde = self.dt_desde.date().toString("yyyy-MM-dd")
        fecha_hasta = self.dt_hasta.date().toString("yyyy-MM-dd")
        saco = self.cb_saco.currentText().strip()
        categoria = self.cb_categoria.currentText().strip()
        producto = self.cb_producto.currentText().strip()

        sel = self.cb_desc.currentText().strip()
        tipo_oferta, valor_oferta, descuento_pct = self._selection_to_offer_parts(sel)

        try:
            if self.current_edit_id is None:
                db.create_oferta(
                    fecha_desde=fecha_desde,
                    fecha_hasta=fecha_hasta,
                    saco=saco,
                    categoria=categoria,
                    producto=producto,
                    descuento_pct=descuento_pct,
                    tipo_oferta=tipo_oferta,
                    valor_oferta=valor_oferta,
                )
                QMessageBox.information(self, "OK", "Oferta guardada ✅")
            else:
                self.update_oferta_db(
                    oferta_id=int(self.current_edit_id),
                    fecha_desde=fecha_desde,
                    fecha_hasta=fecha_hasta,
                    saco=saco,
                    categoria=categoria,
                    producto=producto,
                    descuento_pct=descuento_pct,
                    tipo_oferta=tipo_oferta,
                    valor_oferta=valor_oferta,
                )
                QMessageBox.information(self, "OK", "Oferta actualizada ✅")
        except Exception as e:
            QMessageBox.warning(self, "DB", f"Guardar/Actualizar oferta hatası:\n{e}")
            return

        self.load_table()
        self.reset_form()

    def update_oferta_db(
        self,
        oferta_id: int,
        fecha_desde: str,
        fecha_hasta: str,
        saco: str,
        categoria: str,
        producto: str,
        descuento_pct: int,
        tipo_oferta: str,
        valor_oferta: str,
    ):
        if hasattr(db, "update_oferta"):
            db.update_oferta(
                oferta_id=oferta_id,
                fecha_desde=fecha_desde,
                fecha_hasta=fecha_hasta,
                saco=saco,
                categoria=categoria,
                producto=producto,
                descuento_pct=descuento_pct,
                tipo_oferta=tipo_oferta,
                valor_oferta=valor_oferta,
            )
            return

        db.init_db()
        with db.connect() as con:
            con.execute("""
                UPDATE ofertas
                SET
                    fecha_desde = ?,
                    fecha_hasta = ?,
                    saco = ?,
                    categoria = ?,
                    producto = ?,
                    descuento_pct = ?,
                    tipo_oferta = ?,
                    valor_oferta = ?
                WHERE id = ?
            """, (
                fecha_desde,
                fecha_hasta,
                saco,
                categoria,
                producto,
                descuento_pct,
                tipo_oferta,
                valor_oferta,
                int(oferta_id),
            ))
            con.commit()

    def _current_id(self):
        row = self.table.currentRow()
        if row < 0:
            return None
        it = self.table.item(row, 0)
        if not it:
            return None
        try:
            return int(it.text())
        except Exception:
            return None

    def toggle_oferta(self):
        oferta_id = self._current_id()
        if oferta_id is None:
            QMessageBox.information(self, "Info", "Bir oferta seç.")
            return
        try:
            db.toggle_oferta(oferta_id)
            self.load_table()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"Toggle hatası:\n{e}")

    def delete_oferta(self):
        oferta_id = self._current_id()
        if oferta_id is None:
            QMessageBox.information(self, "Info", "Bir oferta seç.")
            return

        if QMessageBox.question(self, "Confirmar", "¿Eliminar oferta seleccionada?") != QMessageBox.Yes:
            return

        try:
            db.delete_oferta(oferta_id)
            self.load_table()
            self.reset_form()
        except Exception as e:
            QMessageBox.warning(self, "DB", f"Delete hatası:\n{e}")