# main.py (VR9 - LOGIN + PERMISOS + AJUSTES/USUARIOS + COLLAPSIBLE SIDEBAR)
# - Login: Usuario + Clave (lista + manual)
# - Sidebar: menüler her zaman görünür, yetkiye göre disable
# - Stock alt menüleri: başlangıçta gizli, Stock'a basınca aç/kapa
# - Ajustes > Usuarios: kullanıcı/rol/izin yönetimi (db.py tek kaynak)
# - Informes: ventas_report.py (Tkinter) subprocess ile açılır (en stabil)

import sys
import os
import subprocess
import importlib
import hashlib
import datetime
import json
import psycopg2
import db
from upgrade import run_upgrade
from pathlib import Path
from typing import Optional, Type, Dict, Any, List
from hoja_entrada_screen import HojaEntradaScreen
from report_manager import ReportManagerPage, InformeProduccionScreen
from analizar_ventas import AnalizarVentasScreen
from ventas_con_detalle import VentasConDetalleWidget
from ventas_resumen_screen import VentasResumenScreen
from ofertas_screen import OfertasScreen
from bolsas_screen import BolsasScreen
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QIcon, QPixmap, QGuiApplication
from PySide6.QtWidgets import (
    QApplication, QWidget, QMainWindow, QDialog,
    QHBoxLayout, QVBoxLayout, QStackedWidget, QGridLayout,
    QPushButton, QLabel, QFrame, QMessageBox,
    QLineEdit, QListWidget, QListWidgetItem, QComboBox,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QGroupBox, QFormLayout, QCheckBox, QToolButton, QSpinBox,
    QTabBar, QCompleter
)

# ✅ EXE/Python fark etmez: bu argümanla sadece ventas_report aç
if "--ventas-report" in sys.argv:
    import ventas_report
    ventas_report.open_ventas_report()
    raise SystemExit(0)

# -----------------------------
# Optional imports (pages)
# -----------------------------
def import_first_class(module_names: list[str], class_names: list[str]) -> Optional[Type]:
    for m in module_names:
        try:
            mod = importlib.import_module(m)
        except Exception:
            continue
        for c in class_names:
            if hasattr(mod, c):
                return getattr(mod, c)
    return None


import traceback

try:
    from production_wizard import ProductionWizard  # QWidget
except Exception as e:
    print("=== PRODUCTION IMPORT ERROR ===")
    traceback.print_exc()
    ProductionWizard = None


# -----------------------------
# Helpers
# -----------------------------
class PlaceholderPage(QWidget):
    def __init__(self, title: str, subtitle: str = ""):
        super().__init__()
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 28, 28, 28)
        v.setSpacing(10)
        t = QLabel(title)
        t.setStyleSheet("font-size:26px;font-weight:800;")
        v.addWidget(t)
        if subtitle:
            s = QLabel(subtitle)
            s.setStyleSheet("color:#64748b;font-size:15px;")
            s.setWordWrap(True)
            v.addWidget(s)
        v.addStretch(1)


def make_qwidget(maybe_cls_or_obj, fallback_title="Page"):
    try:
        if maybe_cls_or_obj is None:
            return PlaceholderPage(fallback_title, "Bu sayfa yüklenemedi (import edilemedi).")

        obj = maybe_cls_or_obj() if isinstance(maybe_cls_or_obj, type) else maybe_cls_or_obj
        if isinstance(obj, QWidget):
            return obj

        return PlaceholderPage(
            fallback_title,
            f"Widget değil: {type(obj)}\nBu sayfanın QWidget (PySide6) olması gerekiyor."
        )
    except Exception as e:
        return PlaceholderPage(fallback_title, f"Açılırken hata:\n{e}")


def sha256_hex(s: str) -> str:
    return hashlib.sha256((s or "").encode("utf-8")).hexdigest()


# -----------------------------
# USERS API (TEK KAYNAK: db.py)
# -----------------------------
def list_usuarios():
    return db.list_usuarios(active_only=True)


def get_usuario_by_login(login: str):
    login = (login or "").strip().upper()
    if not login:
        return None
    for u in db.list_usuarios(active_only=False):
        if (u.get("usuario") or "").strip().upper() == login:
            return u
    return None


def verify_login(login: str, password: str):
    return db.authenticate_usuario(login, password)


def upsert_usuario(
    *,
    usuario: str,
    nombre: str,
    apellido: str,
    password: Optional[str],
    is_admin: bool,
    can_pos: bool,
    can_stock: bool,
    can_produccion: bool,
    can_informes: bool,
    can_ajustes: bool,
    can_database: bool,
    sucursal_id: Optional[int] = None,
):
   
    usuario = (usuario or "").strip().upper()
    if not usuario:
        raise ValueError("Usuario vacío.")

    role = "admin" if is_admin else "user"
    perms = dict(
        can_pos=1 if can_pos else 0,
        can_stock=1 if can_stock else 0,
        can_production=1 if can_produccion else 0,  # db.py column: can_production
        can_informes=1 if can_informes else 0,
        can_ajustes=1 if can_ajustes else 0,
        can_database=1 if can_database else 0,
    )

    existing = get_usuario_by_login(usuario)
    if existing:
        db.update_usuario(
            user_id=int(existing["id"]),
            usuario=usuario,
            nombre=nombre,
            apellido=apellido,
            role=role,
            is_active=1,
            perms=perms,
            sucursal_id=sucursal_id,
        )
        if password:
            db.set_usuario_password(int(existing["id"]), password)
    else:
        if not password:
            raise ValueError("Nuevo usuario requiere clave.")
        db.create_usuario(
            usuario=usuario,
            nombre=nombre,
            apellido=apellido,
            clave=password,
            role=role,
            perms=perms,
            is_active=1,
            sucursal_id=sucursal_id,
        )


def delete_usuario(usuario: str):
    usuario = (usuario or "").strip().upper()
    existing = get_usuario_by_login(usuario)
    if not existing:
        return

    # Last admin protection
    if existing.get("role") == "admin":
        admins = [u for u in db.list_usuarios(active_only=False) if u.get("role") == "admin" and int(u.get("is_active", 1)) == 1]
        if len(admins) <= 1:
            raise ValueError("Son admin silinemez.")

    db.delete_usuario(int(existing["id"]))

# -----------------------------
# Settings Dialog
# -----------------------------
class DBSettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Ajustes de Base de Datos")
        self.setModal(True)
        self.resize(520, 360)

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(12)

        title = QLabel("Configuración PostgreSQL")
        title.setStyleSheet("font-size:22px;font-weight:900;color:#ffffff;")
        root.addWidget(title)

        box = QGroupBox("Conexión")
        box.setStyleSheet("""
            QGroupBox {
                color: white;
                font-size: 14px;
                font-weight: 900;
                border: 1px solid rgba(255,255,255,0.08);
                border-radius: 16px;
                margin-top: 10px;
                padding: 14px;
                background: rgba(255,255,255,0.03);
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
            }
        """)
        form = QFormLayout(box)
        form.setVerticalSpacing(12)

        self.ed_host = QLineEdit(str(db.PG_CONFIG.get("host", "")))
        self.ed_port = QLineEdit(str(db.PG_CONFIG.get("port", 5432)))
        self.ed_dbname = QLineEdit(str(db.PG_CONFIG.get("dbname", "")))
        self.ed_user = QLineEdit(str(db.PG_CONFIG.get("user", "")))
        self.ed_pass = QLineEdit(str(db.PG_CONFIG.get("password", "")))
        self.ed_pass.setEchoMode(QLineEdit.Password)

        for w in [self.ed_host, self.ed_port, self.ed_dbname, self.ed_user, self.ed_pass]:
            w.setMinimumHeight(42)
            w.setStyleSheet("""
                QLineEdit {
                    border: 1px solid #475569;
                    border-radius: 12px;
                    padding: 8px 12px;
                    background: #334155;
                    color: #ffffff;
                    font-size: 15px;
                }
                QLineEdit:focus {
                    border: 2px solid #2563eb;
                    background: #3b4b5f;
                }
            """)

        form.addRow("Host:", self.ed_host)
        form.addRow("Port:", self.ed_port)
        form.addRow("Database:", self.ed_dbname)
        form.addRow("User:", self.ed_user)
        form.addRow("Password:", self.ed_pass)

        root.addWidget(box)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)

        self.btn_test = QPushButton("Probar conexión")
        self.btn_test.setMinimumHeight(42)
        self.btn_test.clicked.connect(self.test_connection)

        self.btn_save = QPushButton("Guardar")
        self.btn_save.setMinimumHeight(42)
        self.btn_save.clicked.connect(self.save_and_close)

        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.setMinimumHeight(42)
        self.btn_cancel.clicked.connect(self.reject)

        self.btn_test.setStyleSheet("""
            QPushButton {
                border-radius: 12px;
                padding: 10px 14px;
                font-weight: 900;
                font-size: 14px;
                background: #ffffff;
                color: #0f172a;
                border: 1px solid #cbd5e1;
            }
            QPushButton:hover {
                background: #f1f5f9;
            }
        """)

        self.btn_cancel.setStyleSheet("""
            QPushButton {
                border-radius: 12px;
                padding: 10px 14px;
                font-weight: 900;
                font-size: 14px;
                background: #ffffff;
                color: #0f172a;
                border: 1px solid #cbd5e1;
            }
            QPushButton:hover {
                background: #f1f5f9;
            }
        """)

        self.btn_save.setStyleSheet("""
            QPushButton {
                border-radius: 12px;
                padding: 10px 14px;
                font-weight: 900;
                font-size: 14px;
                background: #2563eb;
                color: #ffffff;
                border: 1px solid #2563eb;
            }
            QPushButton:hover {
                background: #1d4ed8;
            }
        """)

        btn_row.addWidget(self.btn_test)
        btn_row.addWidget(self.btn_cancel)
        btn_row.addWidget(self.btn_save)
        root.addLayout(btn_row)

        self.setStyleSheet("""
            QDialog {
                background:qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0f1d2b,
                    stop:0.5 #13283a,
                    stop:1 #183247
                );
            }
            QLabel {
                color: white;
            }
        """)

    def get_data(self):
        return {
            "host": self.ed_host.text().strip(),
            "port": int((self.ed_port.text() or "5432").strip()),
            "dbname": self.ed_dbname.text().strip(),
            "user": self.ed_user.text().strip(),
            "password": self.ed_pass.text(),
        }

    def test_connection(self):
        cfg = self.get_data()
        try:
            con = psycopg2.connect(
                host=cfg["host"],
                port=cfg["port"],
                dbname=cfg["dbname"],
                user=cfg["user"],
                password=cfg["password"],
            )
            con.close()
            QMessageBox.information(self, "OK", "Conexión exitosa.")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"No se pudo conectar:\n{e}")

    def save_and_close(self):
        cfg = self.get_data()
        db.save_pg_config(cfg)
        db.PG_CONFIG = cfg
        self.accept()

# -----------------------------
# Login Dialog
# -----------------------------
class LoginDialog(QDialog):
    def __init__(self, parent=None, settings_callback=None):
        super().__init__(parent)
        self.setWindowTitle("VR9 · Iniciar sesión")
        self.setModal(True)
        self.resize(700, 360)

        self.user: Optional[Dict[str, Any]] = None
        self.settings_callback = settings_callback
        self.users_cache: List[Dict[str, Any]] = []

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)

        topbar = QHBoxLayout()
        topbar.setSpacing(10)

        title_box = QVBoxLayout()
        title_box.setSpacing(2)

        title = QLabel("Inicio de sesión")
        title.setObjectName("MainTitle")
        title_box.addWidget(title)

        subtitle = QLabel("Ingresa tus credenciales para acceder al sistema.")
        subtitle.setObjectName("Hint")
        subtitle.setWordWrap(True)
        title_box.addWidget(subtitle)

        topbar.addLayout(title_box, 1)

        self.btn_settings = QPushButton("⚙ Ajustes")
        self.btn_settings.setMinimumHeight(40)
        self.btn_settings.setMinimumWidth(130)
        self.btn_settings.setObjectName("GhostButton")
        self.btn_settings.clicked.connect(self.open_settings)
        topbar.addWidget(self.btn_settings, 0, Qt.AlignTop)

        root.addLayout(topbar)

        card = QFrame()
        card.setObjectName("MainCard")
        card_wrap = QVBoxLayout(card)
        card_wrap.setContentsMargins(22, 22, 22, 22)
        card_wrap.setSpacing(14)

        cred_box = QGroupBox("Credenciales")
        cred_box.setObjectName("CredBox")
        fl = QFormLayout(cred_box)
        fl.setLabelAlignment(Qt.AlignLeft)
        fl.setFormAlignment(Qt.AlignTop)
        fl.setVerticalSpacing(12)
        fl.setHorizontalSpacing(12)

        usuario_row = QHBoxLayout()
        usuario_row.setSpacing(8)

        self.ed_usuario = QLineEdit()
        self.ed_usuario.setPlaceholderText("Usuario")
        self.ed_usuario.setMinimumHeight(48)
        self.ed_usuario.returnPressed.connect(lambda: self.ed_clave.setFocus())

        self.btn_pick_user = QPushButton("👤")
        self.btn_pick_user.setObjectName("IconButton")
        self.btn_pick_user.setFixedSize(48, 48)
        self.btn_pick_user.clicked.connect(self.open_user_picker)

        usuario_row.addWidget(self.ed_usuario, 1)
        usuario_row.addWidget(self.btn_pick_user, 0)

        self.ed_clave = QLineEdit()
        self.ed_clave.setEchoMode(QLineEdit.Password)
        self.ed_clave.setPlaceholderText("Clave")
        self.ed_clave.setMinimumHeight(48)
        self.ed_clave.returnPressed.connect(self.do_login)

        fl.addRow("Usuario:", usuario_row)
        fl.addRow("Clave:", self.ed_clave)

        card_wrap.addWidget(cred_box)

        btnrow = QHBoxLayout()
        btnrow.setSpacing(10)
        btnrow.addStretch(1)

        self.btn_cancel = QPushButton("Cancelar")
        self.btn_cancel.setMinimumHeight(46)
        self.btn_cancel.setMinimumWidth(120)
        self.btn_cancel.setObjectName("GhostButton")
        self.btn_cancel.clicked.connect(self.reject)

        self.btn_ok = QPushButton("Entrar")
        self.btn_ok.setMinimumHeight(46)
        self.btn_ok.setMinimumWidth(140)
        self.btn_ok.setObjectName("Primary")
        self.btn_ok.clicked.connect(self.do_login)

        btnrow.addWidget(self.btn_cancel)
        btnrow.addWidget(self.btn_ok)

        card_wrap.addLayout(btnrow)
        root.addWidget(card, 1)

        self.setStyleSheet("""
            QDialog {
                background:qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0f1d2b,
                    stop:0.5 #13283a,
                    stop:1 #183247
                );
            }

            QFrame#MainCard {
                background: rgba(43, 58, 72, 0.92);
                border: 1px solid rgba(255,255,255,0.08);
                border-radius: 22px;
            }

            QLabel#MainTitle {
                color: #ffffff;
                font-size: 24px;
                font-weight: 900;
            }

            QLabel#Hint {
                color: #cbd5e1;
                font-size: 13px;
            }

            QGroupBox#CredBox {
                color: #ffffff;
                font-size: 14px;
                font-weight: 900;
                border: 1px solid rgba(255,255,255,0.08);
                border-radius: 16px;
                margin-top: 10px;
                padding: 14px;
                background: rgba(255,255,255,0.03);
            }

            QGroupBox#CredBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
            }

            QLineEdit {
                border: 1px solid #475569;
                border-radius: 12px;
                padding: 8px 12px;
                background: #334155;
                color: #ffffff;
                font-size: 16px;
            }

            QLineEdit:focus {
                border: 2px solid #2563eb;
                background: #3b4b5f;
            }

            QPushButton {
                border-radius: 12px;
                padding: 10px 14px;
                font-weight: 900;
                font-size: 14px;
            }

            QPushButton#Primary {
                background: #2563eb;
                border: 1px solid #2563eb;
                color: #ffffff;
            }

            QPushButton#Primary:hover {
                background: #1d4ed8;
            }

            QPushButton#GhostButton {
                background: #ffffff;
                border: 1px solid #cbd5e1;
                color: #0f172a;
            }

            QPushButton#GhostButton:hover {
                background: #f1f5f9;
            }

            QPushButton#IconButton {
                background: #ffffff;
                border: 1px solid #cbd5e1;
                color: #0f172a;
                font-size: 18px;
                padding: 0px;
            }

            QPushButton#IconButton:hover {
                background: #f1f5f9;
            }

            QLabel {
                color: #ffffff;
                font-size: 14px;
            }
        """)

        self.load_users()

    def open_settings(self):
        if callable(self.settings_callback):
            self.settings_callback()
        else:
            QMessageBox.information(
                self,
                "Ajustes",
                "Buraya conexión/DB ayar ekranı bağlanacak."
            )

    def load_users(self):
        try:
            self.users_cache = list_usuarios()
            print("LOGIN USERS:", self.users_cache)
        except Exception as e:
            QMessageBox.warning(self, "DB", f"Usuarios yüklenemedi:\n{e}")
            self.users_cache = []

    def open_user_picker(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Seleccionar usuario")
        dlg.setModal(True)
        dlg.resize(520, 520)

        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(10)

        title = QLabel("Usuarios")
        title.setStyleSheet("font-size:18px;font-weight:900;color:#ffffff;")
        lay.addWidget(title)

        search = QLineEdit()
        search.setPlaceholderText("Buscar usuario...")
        search.setMinimumHeight(42)
        lay.addWidget(search)

        listw = QListWidget()
        lay.addWidget(listw, 1)

        btn_close = QPushButton("Cerrar")
        btn_close.setMinimumHeight(42)
        btn_close.clicked.connect(dlg.reject)
        lay.addWidget(btn_close)

        dlg.setStyleSheet("""
            QDialog {
                background:#13283a;
            }
            QLineEdit {
                border:1px solid #475569;
                border-radius:12px;
                padding:8px 12px;
                background:#334155;
                color:#ffffff;
                font-size:15px;
            }
            QListWidget {
                background:#ffffff;
                border:1px solid #dbe3ec;
                border-radius:14px;
                font-size:15px;
                padding:6px;
            }
            QListWidget::item {
                padding:10px;
                margin:4px;
                border-radius:10px;
                border:1px solid #e2e8f0;
                color:#0f172a;
                background:#ffffff;
            }
            QListWidget::item:selected {
                background:#dbeafe;
                border:2px solid #2563eb;
                color:#0f172a;
            }
            QPushButton {
                border:1px solid #cbd5e1;
                border-radius:12px;
                background:#ffffff;
                font-weight:900;
                padding:10px 14px;
            }
        """)

        def refresh_list(filter_text=""):
            listw.clear()
            f = (filter_text or "").strip().lower()

            for u in self.users_cache:
                usuario = u.get("usuario", "")
                nombre = (u.get("nombre") or "").strip()
                apellido = (u.get("apellido") or "").strip()
                admin = (u.get("role") == "admin")

                text = f"{usuario}"
                if nombre or apellido:
                    text += f"  ·  {nombre} {apellido}".strip()
                if admin:
                    text += "  (admin)"

                if f and f not in text.lower():
                    continue

                it = QListWidgetItem(text)
                it.setData(Qt.UserRole, usuario)
                listw.addItem(it)

        def choose_user(item: QListWidgetItem):
            usuario = item.data(Qt.UserRole) or ""
            self.ed_usuario.setText(str(usuario))
            dlg.accept()
            self.ed_clave.setFocus()

        search.textChanged.connect(refresh_list)
        listw.itemDoubleClicked.connect(choose_user)
        listw.itemClicked.connect(lambda item: None)

        refresh_list()
        dlg.exec()

    def do_login(self):
        usuario = (self.ed_usuario.text() or "").strip()
        clave = (self.ed_clave.text() or "")

        if not usuario:
            QMessageBox.warning(self, "Error", "Usuario boş olamaz.")
            return

        if not clave:
            QMessageBox.warning(self, "Error", "Clave boş olamaz.")
            return

        u = verify_login(usuario, clave)
        if not u:
            QMessageBox.warning(self, "Error", "Usuario o clave incorrectos.")
            return

        self.user = u
        self.accept()

class StyledMessageBox(QDialog):
    def __init__(self, parent=None, title="Mensaje", message="", kind="info", buttons=("ok",)):
        super().__init__(parent)
        self.setModal(True)
        self.setWindowTitle(title)
        self.resize(430, 195)
        self.result_value = None

        kinds = {
            "success": {"icon": "✅", "accent": "#16a34a"},
            "error": {"icon": "⚠️", "accent": "#dc2626"},
            "warning": {"icon": "⚠️", "accent": "#d97706"},
            "info": {"icon": "ℹ️", "accent": "#2563eb"},
            "question": {"icon": "❓", "accent": "#2563eb"},
        }
        cfg = kinds.get(kind, kinds["info"])

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 18, 20, 18)
        root.setSpacing(14)

        top = QHBoxLayout()
        top.setSpacing(14)

        icon_lbl = QLabel(cfg["icon"])
        icon_lbl.setFixedWidth(42)
        icon_lbl.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        icon_lbl.setStyleSheet("font-size:28px;")
        top.addWidget(icon_lbl)

        txt_col = QVBoxLayout()
        txt_col.setSpacing(6)

        ttl = QLabel(title)
        ttl.setStyleSheet("font-size:20px;font-weight:900;color:#ffffff;")
        txt_col.addWidget(ttl)

        msg = QLabel(message)
        msg.setWordWrap(True)
        msg.setStyleSheet("font-size:14px;color:#cbd5e1;line-height:1.4;")
        txt_col.addWidget(msg)

        top.addLayout(txt_col, 1)
        root.addLayout(top)

        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet(f"background:{cfg['accent']};border:none;")
        root.addWidget(line)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)

        if "no" in buttons:
            btn_no = QPushButton("No")
            btn_no.setObjectName("ghostBtn")
            btn_no.clicked.connect(self._no)
            btn_row.addWidget(btn_no)

        if "yes" in buttons:
            btn_yes = QPushButton("Sí")
            btn_yes.setObjectName("primaryBtn")
            btn_yes.clicked.connect(self._yes)
            btn_row.addWidget(btn_yes)

        if "ok" in buttons:
            btn_ok = QPushButton("Aceptar")
            btn_ok.setObjectName("primaryBtn")
            btn_ok.clicked.connect(self._ok)
            btn_row.addWidget(btn_ok)

        root.addLayout(btn_row)

        self.setStyleSheet(f"""
            QDialog {{
                background:qlineargradient(
                    x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0f172a,
                    stop:1 #162235
                );
                border:1px solid #22304a;
                border-radius:18px;
            }}
            QPushButton {{
                min-height:40px;
                min-width:96px;
                border-radius:12px;
                font-size:14px;
                font-weight:900;
                padding:8px 14px;
            }}
            QPushButton#primaryBtn {{
                background:{cfg['accent']};
                color:#ffffff;
                border:1px solid {cfg['accent']};
            }}
            QPushButton#primaryBtn:hover {{
                background:{cfg['accent']};
            }}
            QPushButton#ghostBtn {{
                background:#ffffff;
                color:#0f172a;
                border:1px solid #cbd5e1;
            }}
            QPushButton#ghostBtn:hover {{
                background:#f8fafc;
            }}
        """)

    def _ok(self):
        self.result_value = "ok"
        self.accept()

    def _yes(self):
        self.result_value = "yes"
        self.accept()

    def _no(self):
        self.result_value = "no"
        self.reject()


def show_success(parent, title, message):
    dlg = StyledMessageBox(parent, title=title, message=message, kind="success", buttons=("ok",))
    dlg.exec()


def show_error(parent, title, message):
    dlg = StyledMessageBox(parent, title=title, message=message, kind="error", buttons=("ok",))
    dlg.exec()


def show_info(parent, title, message):
    dlg = StyledMessageBox(parent, title=title, message=message, kind="info", buttons=("ok",))
    dlg.exec()


def ask_confirm(parent, title, message):
    dlg = StyledMessageBox(parent, title=title, message=message, kind="question", buttons=("no", "yes"))
    dlg.exec()
    return dlg.result_value == "yes"

# ------------------------------------------------------------
# Crear Screens
# ------------------------------------------------------------
class SucursalesAdminScreen(QWidget):
    def __init__(self):
        super().__init__()

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)

        body = QHBoxLayout()
        body.setSpacing(16)

        left_card = QFrame()
        left_card.setObjectName("adminPanelCard")
        left_lay = QVBoxLayout(left_card)
        left_lay.setContentsMargins(18, 18, 18, 18)
        left_lay.setSpacing(12)

        left_title = QLabel("Sucursales")
        left_title.setObjectName("adminSectionTitle")
        left_lay.addWidget(left_title)

        self.tbl = QTableWidget(0, 3)
        self.tbl.setObjectName("adminTable")
        self.tbl.setHorizontalHeaderLabels(["Código", "Nombre", "Comuna"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl.setShowGrid(False)

        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)

        self.tbl.itemSelectionChanged.connect(self.on_pick_row)
        left_lay.addWidget(self.tbl, 1)

        body.addWidget(left_card, 2)

        right_card = QFrame()
        right_card.setObjectName("adminPanelCard")
        right_lay = QVBoxLayout(right_card)
        right_lay.setContentsMargins(18, 18, 18, 18)
        right_lay.setSpacing(14)

        form_title = QLabel("Edición")
        form_title.setObjectName("adminSectionTitle")
        right_lay.addWidget(form_title)

        form_box = QGroupBox("Datos de la sucursal")
        form_box.setObjectName("adminGroup")
        form = QFormLayout(form_box)
        form.setVerticalSpacing(12)
        form.setHorizontalSpacing(14)

        self.ed_codigo = QLineEdit()
        self.ed_nombre = QLineEdit()
        self.ed_direccion = QLineEdit()
        self.ed_region = QLineEdit()
        self.ed_comuna = QLineEdit()
        self.ed_api_token = QLineEdit()
        self.ed_api_url = QLineEdit()

        for w in [
            self.ed_codigo, self.ed_nombre, self.ed_direccion,
            self.ed_region, self.ed_comuna, self.ed_api_token, self.ed_api_url
        ]:
            w.setMinimumHeight(42)

        self.ed_codigo.setPlaceholderText("Ej: CRC-SHP")
        self.ed_nombre.setPlaceholderText("Nombre de la sucursal")
        self.ed_direccion.setPlaceholderText("Dirección")
        self.ed_region.setPlaceholderText("Región")
        self.ed_comuna.setPlaceholderText("Comuna")
        self.ed_api_token.setPlaceholderText("Token API")
        self.ed_api_url.setPlaceholderText("https://...")

        form.addRow("Código:", self.ed_codigo)
        form.addRow("Nombre:", self.ed_nombre)
        form.addRow("Dirección:", self.ed_direccion)
        form.addRow("Región:", self.ed_region)
        form.addRow("Comuna:", self.ed_comuna)
        form.addRow("API Token:", self.ed_api_token)
        form.addRow("API URL:", self.ed_api_url)

        right_lay.addWidget(form_box, 1)

        btnrow = QHBoxLayout()
        btnrow.setSpacing(10)

        self.btn_new = QPushButton("Nuevo")
        self.btn_save = QPushButton("Guardar")
        self.btn_del = QPushButton("Eliminar")
        self.btn_reload = QPushButton("Actualizar")

        self.btn_new.setObjectName("adminGhostBtn")
        self.btn_save.setObjectName("adminPrimaryBtn")
        self.btn_del.setObjectName("adminDangerBtn")
        self.btn_reload.setObjectName("adminGhostBtn")

        for b in [self.btn_new, self.btn_save, self.btn_del, self.btn_reload]:
            b.setMinimumHeight(42)

        self.btn_new.clicked.connect(self.clear_form)
        self.btn_save.clicked.connect(self.save_sucursal)
        self.btn_del.clicked.connect(self.delete_sucursal)
        self.btn_reload.clicked.connect(self.load)

        btnrow.addWidget(self.btn_new)
        btnrow.addWidget(self.btn_save)
        btnrow.addWidget(self.btn_del)
        btnrow.addStretch(1)
        btnrow.addWidget(self.btn_reload)

        right_lay.addLayout(btnrow)

        body.addWidget(right_card, 2)
        root.addLayout(body, 1)

        self.current_id = None

        self.setStyleSheet("""
            QFrame#adminPanelCard {
                background: #ffffff;
                border: 1px solid #dbe2ea;
                border-radius: 20px;
            }
            QLabel#adminSectionTitle {
                font-size: 18px;
                font-weight: 900;
                color: #0f172a;
            }
            QGroupBox#adminGroup {
                border: 1px solid #e2e8f0;
                border-radius: 16px;
                margin-top: 10px;
                padding: 14px;
                background: #f8fafc;
                font-weight: 900;
                color: #0f172a;
            }
            QGroupBox#adminGroup::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
            }
            QLineEdit {
                min-height: 40px;
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                padding: 8px 12px;
                background: #ffffff;
                color: #0f172a;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 2px solid #2563eb;
                background: #ffffff;
            }
            QTableWidget#adminTable {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 14px;
                gridline-color: transparent;
                selection-background-color: #dbeafe;
                selection-color: #0f172a;
                alternate-background-color: #f8fafc;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eef2f7;
            }
            QHeaderView::section {
                background: #f8fafc;
                padding: 10px;
                font-weight: 900;
                color: #334155;
                border: 0px;
                border-bottom: 1px solid #e2e8f0;
            }
            QPushButton#adminGhostBtn {
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
                color: #0f172a;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminGhostBtn:hover {
                background: #f8fafc;
            }
            QPushButton#adminPrimaryBtn {
                border-radius: 12px;
                border: 1px solid #2563eb;
                background: #2563eb;
                color: #ffffff;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminPrimaryBtn:hover {
                background: #1d4ed8;
            }
            QPushButton#adminDangerBtn {
                border-radius: 12px;
                border: 1px solid #fecaca;
                background: #ffffff;
                color: #b91c1c;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminDangerBtn:hover {
                background: #fef2f2;
            }
        """)

        self.load()

    def load(self):
        try:
            rows = db.list_sucursales(active_only=False)
        except Exception as e:
            show_error(self, "DB Error", str(e))
            rows = []

        self.tbl.setRowCount(0)
        for i, r in enumerate(rows):
            self.tbl.insertRow(i)
            self.tbl.setItem(i, 0, QTableWidgetItem(str(r.get("codigo", ""))))
            self.tbl.setItem(i, 1, QTableWidgetItem(str(r.get("nombre", ""))))
            self.tbl.setItem(i, 2, QTableWidgetItem(str(r.get("comuna", ""))))

    def clear_form(self):
        self.current_id = None
        self.tbl.clearSelection()
        self.ed_codigo.clear()
        self.ed_nombre.clear()
        self.ed_direccion.clear()
        self.ed_region.clear()
        self.ed_comuna.clear()
        self.ed_api_token.clear()
        self.ed_api_url.clear()

    def on_pick_row(self):
        items = self.tbl.selectedItems()
        if not items:
            return

        codigo = self.tbl.item(self.tbl.currentRow(), 0).text()

        try:
            rows = db.list_sucursales(active_only=False)
        except Exception:
            rows = []

        row_data = None
        for r in rows:
            if str(r.get("codigo", "")) == codigo:
                row_data = r
                break

        if not row_data:
            return

        self.current_id = row_data.get("id")
        self.ed_codigo.setText(str(row_data.get("codigo", "")))
        self.ed_nombre.setText(str(row_data.get("nombre", "")))
        self.ed_direccion.setText(str(row_data.get("direccion", "")))
        self.ed_region.setText(str(row_data.get("region", "")))
        self.ed_comuna.setText(str(row_data.get("comuna", "")))
        self.ed_api_token.setText(str(row_data.get("api_token", "")))
        self.ed_api_url.setText(str(row_data.get("api_url", "")))

    def save_sucursal(self):
        codigo = (self.ed_codigo.text() or "").strip().upper()
        nombre = (self.ed_nombre.text() or "").strip()
        direccion = (self.ed_direccion.text() or "").strip()
        region = (self.ed_region.text() or "").strip()
        comuna = (self.ed_comuna.text() or "").strip()
        api_token = (self.ed_api_token.text() or "").strip()
        api_url = (self.ed_api_url.text() or "").strip()

        if not codigo:
            show_error(self, "Error", "Código vacío.")
            return
        if not nombre:
            show_error(self, "Error", "Nombre vacío.")
            return

        try:
            if self.current_id:
                db.update_sucursal(
                    sucursal_id=int(self.current_id),
                    codigo=codigo,
                    nombre=nombre,
                    direccion=direccion,
                    region=region,
                    comuna=comuna,
                    api_token=api_token,
                    api_url=api_url,
                )
            else:
                db.create_sucursal(
                    codigo=codigo,
                    nombre=nombre,
                    direccion=direccion,
                    region=region,
                    comuna=comuna,
                    api_token=api_token,
                    api_url=api_url,
                )
        except Exception as e:
            show_error(self, "Error", str(e))
            return

        show_success(self, "Guardado", "Sucursal guardada correctamente.")
        self.load()
        self.clear_form()

    def delete_sucursal(self):
        if not self.current_id:
            show_info(self, "Información", "Selecciona una sucursal para eliminar.")
            return

        if not ask_confirm(self, "Confirmar eliminación", "¿Eliminar la sucursal seleccionada?"):
            return

        try:
            db.delete_sucursal(int(self.current_id))
        except Exception as e:
            show_error(self, "Error", str(e))
            return

        show_success(self, "Eliminado", "Sucursal eliminada correctamente.")
        self.load()
        self.clear_form()

class UsuariosAdminScreen(QWidget):
    def __init__(self):
        super().__init__()

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)

        content = QHBoxLayout()
        content.setSpacing(16)

        left_card = QFrame()
        left_card.setObjectName("adminPanelCard")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(18, 18, 18, 18)
        left_layout.setSpacing(12)

        left_title = QLabel("Usuarios")
        left_title.setObjectName("adminSectionTitle")
        left_layout.addWidget(left_title)

        self.tbl = QTableWidget(0, 4)
        self.tbl.setObjectName("adminTable")
        self.tbl.setHorizontalHeaderLabels(["Usuario", "Nombre", "Apellido", "Rol"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl.setShowGrid(False)

        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setSectionResizeMode(3, QHeaderView.ResizeToContents)

        self.tbl.itemSelectionChanged.connect(self.on_pick_row)
        left_layout.addWidget(self.tbl, 1)

        content.addWidget(left_card, 2)

        right_card = QFrame()
        right_card.setObjectName("adminPanelCard")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(18, 18, 18, 18)
        right_layout.setSpacing(14)

        form_title = QLabel("Edición")
        form_title.setObjectName("adminSectionTitle")
        right_layout.addWidget(form_title)

        form_box = QGroupBox("Datos del usuario")
        form_box.setObjectName("adminGroup")
        form = QFormLayout(form_box)
        form.setVerticalSpacing(12)
        form.setHorizontalSpacing(14)

        self.ed_usuario = QLineEdit()
        self.ed_usuario.setPlaceholderText("Login")

        self.ed_nombre = QLineEdit()
        self.ed_apellido = QLineEdit()

        self.ed_pass = QLineEdit()
        self.ed_pass.setEchoMode(QLineEdit.Password)
        self.ed_pass.setPlaceholderText("Nueva clave (opcional en editar)")

        self.ed_pass2 = QLineEdit()
        self.ed_pass2.setEchoMode(QLineEdit.Password)
        self.ed_pass2.setPlaceholderText("Confirmar clave")

        self.cb_sucursal = QComboBox()

        for w in [self.ed_usuario, self.ed_nombre, self.ed_apellido, self.ed_pass, self.ed_pass2, self.cb_sucursal]:
            w.setMinimumHeight(42)

        self.chk_admin = QCheckBox("Admin")

        self.p_pos = QCheckBox("POS")
        self.p_stock = QCheckBox("Stock")
        self.p_prod = QCheckBox("Producción")
        self.p_inf = QCheckBox("Informes")
        self.p_aj = QCheckBox("Ajustes")
        self.p_db = QCheckBox("Database")

        perm_grid = QWidget()
        pg = QGridLayout(perm_grid)
        pg.setContentsMargins(0, 0, 0, 0)
        pg.setHorizontalSpacing(18)
        pg.setVerticalSpacing(10)
        pg.addWidget(self.p_pos, 0, 0)
        pg.addWidget(self.p_stock, 0, 1)
        pg.addWidget(self.p_prod, 1, 0)
        pg.addWidget(self.p_inf, 1, 1)
        pg.addWidget(self.p_aj, 2, 0)
        pg.addWidget(self.p_db, 2, 1)

        form.addRow("Usuario:", self.ed_usuario)
        form.addRow("Nombre:", self.ed_nombre)
        form.addRow("Apellido:", self.ed_apellido)
        form.addRow("Clave:", self.ed_pass)
        form.addRow("Confirmar:", self.ed_pass2)
        form.addRow("Sucursal:", self.cb_sucursal)
        form.addRow("", self.chk_admin)
        form.addRow("Permisos:", perm_grid)

        right_layout.addWidget(form_box, 1)

        btnrow = QHBoxLayout()
        btnrow.setSpacing(10)

        self.btn_new = QPushButton("Nuevo")
        self.btn_save = QPushButton("Guardar")
        self.btn_del = QPushButton("Eliminar")
        self.btn_reload = QPushButton("Actualizar")

        self.btn_new.setObjectName("adminGhostBtn")
        self.btn_save.setObjectName("adminPrimaryBtn")
        self.btn_del.setObjectName("adminDangerBtn")
        self.btn_reload.setObjectName("adminGhostBtn")

        for b in [self.btn_new, self.btn_save, self.btn_del, self.btn_reload]:
            b.setMinimumHeight(42)

        self.btn_new.clicked.connect(self.clear_form)
        self.btn_save.clicked.connect(self.save_user)
        self.btn_del.clicked.connect(self.delete_user)
        self.btn_reload.clicked.connect(self.load)

        btnrow.addWidget(self.btn_new)
        btnrow.addWidget(self.btn_save)
        btnrow.addWidget(self.btn_del)
        btnrow.addStretch(1)
        btnrow.addWidget(self.btn_reload)

        right_layout.addLayout(btnrow)

        content.addWidget(right_card, 2)
        root.addLayout(content, 1)

        self.setStyleSheet("""
            QFrame#adminPanelCard {
                background: #ffffff;
                border: 1px solid #dbe2ea;
                border-radius: 20px;
            }
            QLabel#adminSectionTitle {
                font-size: 18px;
                font-weight: 900;
                color: #0f172a;
            }
            QGroupBox#adminGroup {
                border: 1px solid #e2e8f0;
                border-radius: 16px;
                margin-top: 10px;
                padding: 14px;
                background: #f8fafc;
                font-weight: 900;
                color: #0f172a;
            }
            QGroupBox#adminGroup::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
            }
            QLineEdit, QComboBox {
                min-height: 40px;
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                padding: 8px 12px;
                background: #ffffff;
                color: #0f172a;
                font-size: 14px;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 2px solid #2563eb;
                background: #ffffff;
            }
            QTableWidget#adminTable {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 14px;
                gridline-color: transparent;
                selection-background-color: #dbeafe;
                selection-color: #0f172a;
                alternate-background-color: #f8fafc;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eef2f7;
            }
            QHeaderView::section {
                background: #f8fafc;
                padding: 10px;
                font-weight: 900;
                color: #334155;
                border: 0px;
                border-bottom: 1px solid #e2e8f0;
            }
            QCheckBox {
                spacing: 8px;
                color: #0f172a;
                font-size: 14px;
            }
            QPushButton#adminGhostBtn {
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
                color: #0f172a;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminGhostBtn:hover {
                background: #f8fafc;
            }
            QPushButton#adminPrimaryBtn {
                border-radius: 12px;
                border: 1px solid #2563eb;
                background: #2563eb;
                color: #ffffff;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminPrimaryBtn:hover {
                background: #1d4ed8;
            }
            QPushButton#adminDangerBtn {
                border-radius: 12px;
                border: 1px solid #fecaca;
                background: #ffffff;
                color: #b91c1c;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminDangerBtn:hover {
                background: #fef2f2;
            }
        """)

        self.load_sucursales()
        self.load()

    def load_sucursales(self):
        self.cb_sucursal.clear()
        self.cb_sucursal.addItem("— Sin sucursal —", None)

        try:
            rows = db.list_sucursales(active_only=False)
        except Exception as e:
            print("load_sucursales error:", e)
            rows = []

        for r in rows:
            codigo = str(r.get("codigo", "") or "").strip()
            nombre = str(r.get("nombre", "") or "").strip()
            activo = int(r.get("activo", 1) or 0)

            label = f"{codigo} - {nombre}" if codigo else nombre
            if activo == 0:
                label += " (inactivo)"

            self.cb_sucursal.addItem(label, r.get("id"))

    def load(self):
        try:
            users = list_usuarios()
        except Exception as e:
            show_error(self, "DB Error", str(e))
            users = []

        self.tbl.setRowCount(0)
        for i, u in enumerate(users):
            self.tbl.insertRow(i)
            rol = "admin" if (u.get("role") == "admin") else "user"
            self.tbl.setItem(i, 0, QTableWidgetItem(u.get("usuario","")))
            self.tbl.setItem(i, 1, QTableWidgetItem(u.get("nombre","") or ""))
            self.tbl.setItem(i, 2, QTableWidgetItem(u.get("apellido","") or ""))
            self.tbl.setItem(i, 3, QTableWidgetItem(rol))

    def clear_form(self):
        self.tbl.clearSelection()
        self.ed_usuario.setText("")
        self.ed_nombre.setText("")
        self.ed_apellido.setText("")
        self.ed_pass.setText("")
        self.ed_pass2.setText("")
        self.chk_admin.setChecked(False)
        for cb in (self.p_pos, self.p_stock, self.p_prod, self.p_inf, self.p_aj, self.p_db):
            cb.setChecked(False)
        self.p_pos.setChecked(True)
        self.cb_sucursal.setCurrentIndex(0)

    def on_pick_row(self):
        items = self.tbl.selectedItems()
        if not items:
            return

        usuario = items[0].text()
        u = get_usuario_by_login(usuario)
        if not u:
            return

        sid = u.get("sucursal_id")
        idx = self.cb_sucursal.findData(sid)
        if idx >= 0:
            self.cb_sucursal.setCurrentIndex(idx)
        else:
            self.cb_sucursal.setCurrentIndex(0)

        self.ed_usuario.setText(u.get("usuario",""))
        self.ed_nombre.setText(u.get("nombre","") or "")
        self.ed_apellido.setText(u.get("apellido","") or "")
        self.ed_pass.setText("")
        self.ed_pass2.setText("")
        self.chk_admin.setChecked(u.get("role") == "admin")

        self.p_pos.setChecked(bool(u.get("can_pos")))
        self.p_stock.setChecked(bool(u.get("can_stock")))
        self.p_prod.setChecked(bool(u.get("can_production")))
        self.p_inf.setChecked(bool(u.get("can_informes")))
        self.p_aj.setChecked(bool(u.get("can_ajustes")))
        self.p_db.setChecked(bool(u.get("can_database")))

    def save_user(self):
        usuario = (self.ed_usuario.text() or "").strip().upper()
        nombre = (self.ed_nombre.text() or "").strip()
        apellido = (self.ed_apellido.text() or "").strip()
        p1 = self.ed_pass.text() or ""
        p2 = self.ed_pass2.text() or ""

        if not usuario:
            show_error(self, "Error", "Usuario vacío.")
            return

        if p1 or p2:
            if p1 != p2:
                show_error(self, "Error", "Clave ve Confirmar aynı değil.")
                return
            if len(p1) < 3:
                show_error(self, "Error", "Clave çok kısa.")
                return
            password = p1
        else:
            password = None

        try:
            upsert_usuario(
                usuario=usuario,
                nombre=nombre,
                apellido=apellido,
                password=password,
                is_admin=self.chk_admin.isChecked(),
                can_pos=self.p_pos.isChecked(),
                can_stock=self.p_stock.isChecked(),
                can_produccion=self.p_prod.isChecked(),
                can_informes=self.p_inf.isChecked(),
                can_ajustes=self.p_aj.isChecked(),
                can_database=self.p_db.isChecked(),
                sucursal_id=self.cb_sucursal.currentData(),
            )
        except Exception as e:
            show_error(self, "Error", str(e))
            return

        show_success(self, "Guardado", "Usuario guardado correctamente.")
        self.load_sucursales()
        self.load()
        self.clear_form()

    def delete_user(self):
        usuario = (self.ed_usuario.text() or "").strip().upper()
        if not usuario:
            show_info(self, "Información", "Selecciona un usuario para eliminar.")
            return

        if not ask_confirm(self, "Confirmar eliminación", f"¿Eliminar el usuario {usuario}?"):
            return

        try:
            delete_usuario(usuario)
        except Exception as e:
            show_error(self, "Error", str(e))
            return

        show_success(self, "Eliminado", "Usuario eliminado correctamente.")
        self.clear_form()
        self.load()

class ClientesAdminScreen(QWidget):
    def __init__(self):
        super().__init__()

        self._all_rows = []
        self._region_to_comunas = {}
        self._giros_master = []
        self._regiones_master = []
        self._comunas_master = []

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)

        content = QHBoxLayout()
        content.setSpacing(16)

        # LEFT
        left_card = QFrame()
        left_card.setObjectName("adminPanelCard")
        left_layout = QVBoxLayout(left_card)
        left_layout.setContentsMargins(18, 18, 18, 18)
        left_layout.setSpacing(12)

        top_row = QHBoxLayout()
        top_row.setSpacing(10)

        left_title = QLabel("Clientes")
        left_title.setObjectName("adminSectionTitle")
        top_row.addWidget(left_title)

        top_row.addStretch(1)

        self.ed_filter = QLineEdit()
        self.ed_filter.setPlaceholderText("Buscar Cliente")
        self.ed_filter.setClearButtonEnabled(True)
        self.ed_filter.setMinimumHeight(40)
        self.ed_filter.setMaximumWidth(420)
        self.ed_filter.textChanged.connect(self.apply_filter)
        top_row.addWidget(self.ed_filter)
        self.ed_filter.setFixedWidth(350)

        left_layout.addLayout(top_row)

        self.tbl = QTableWidget(0, 6)
        self.tbl.setObjectName("adminTable")
        self.tbl.setHorizontalHeaderLabels([
            "RUT", "Razón Social", "Giro", "Dirección", "Región", "Comuna"
        ])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl.setSelectionMode(QTableWidget.SingleSelection)
        self.tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl.setShowGrid(False)

        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        hh.setSectionResizeMode(3, QHeaderView.Stretch)
        hh.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(5, QHeaderView.ResizeToContents)

        self.tbl.itemSelectionChanged.connect(self.on_pick_row)
        left_layout.addWidget(self.tbl, 1)

        content.addWidget(left_card, 4)

        # RIGHT
        right_card = QFrame()
        right_card.setObjectName("adminPanelCard")
        right_layout = QVBoxLayout(right_card)
        right_layout.setContentsMargins(18, 18, 18, 18)
        right_layout.setSpacing(14)

        form_title = QLabel("Edición")
        form_title.setObjectName("adminSectionTitle")
        right_layout.addWidget(form_title)

        form_box = QGroupBox("Datos del cliente")
        form_box.setObjectName("adminGroup")
        form = QFormLayout(form_box)
        form.setVerticalSpacing(12)
        form.setHorizontalSpacing(14)

        self.ed_rut = QLineEdit()
        self.ed_razon = QLineEdit()

        self.cb_giro = QComboBox()
        self.cb_giro.setEditable(True)
        self.cb_giro.setInsertPolicy(QComboBox.NoInsert)

        self.ed_direccion = QLineEdit()

        self.cb_region = QComboBox()
        self.cb_region.setEditable(True)
        self.cb_region.setInsertPolicy(QComboBox.NoInsert)

        self.cb_comuna = QComboBox()
        self.cb_comuna.setEditable(True)
        self.cb_comuna.setInsertPolicy(QComboBox.NoInsert)

        for w in [
            self.ed_rut,
            self.ed_razon,
            self.cb_giro,
            self.ed_direccion,
            self.cb_region,
            self.cb_comuna,
        ]:
            w.setMinimumHeight(42)
            w.setMaximumWidth(520)

        self.ed_rut.setPlaceholderText("Ej: 12.345.678-9")
        self.ed_razon.setPlaceholderText("Razón social")
        self.cb_giro.lineEdit().setPlaceholderText("Giro")
        self.ed_direccion.setPlaceholderText("Dirección")
        self.cb_region.lineEdit().setPlaceholderText("Región")
        self.cb_comuna.lineEdit().setPlaceholderText("Comuna")

        form.addRow("RUT:", self.ed_rut)
        form.addRow("Razón Social:", self.ed_razon)
        form.addRow("Giro:", self.cb_giro)
        form.addRow("Dirección:", self.ed_direccion)
        form.addRow("Región:", self.cb_region)
        form.addRow("Comuna:", self.cb_comuna)

        right_layout.addWidget(form_box, 0)
        right_layout.addStretch(1)

        btnrow = QHBoxLayout()
        btnrow.setSpacing(10)

        self.btn_new = QPushButton("Nuevo")
        self.btn_save = QPushButton("Guardar")
        self.btn_del = QPushButton("Eliminar")
        self.btn_reload = QPushButton("Actualizar")

        self.btn_new.setObjectName("adminGhostBtn")
        self.btn_save.setObjectName("adminPrimaryBtn")
        self.btn_del.setObjectName("adminDangerBtn")
        self.btn_reload.setObjectName("adminGhostBtn")

        for b in [self.btn_new, self.btn_save, self.btn_del, self.btn_reload]:
            b.setMinimumHeight(42)

        self.btn_new.clicked.connect(self.clear_form)
        self.btn_save.clicked.connect(self.save_cliente)
        self.btn_del.clicked.connect(self.delete_cliente_ui)
        self.btn_reload.clicked.connect(self.load)

        btnrow.addWidget(self.btn_new)
        btnrow.addWidget(self.btn_save)
        btnrow.addWidget(self.btn_del)
        btnrow.addStretch(1)
        btnrow.addWidget(self.btn_reload)

        right_layout.addLayout(btnrow)

        content.addWidget(right_card, 3)

        root.addLayout(content, 1)

        self.setStyleSheet("""
            QFrame#adminPanelCard {
                background: #ffffff;
                border: 1px solid #dbe2ea;
                border-radius: 20px;
            }
            QLabel#adminSectionTitle {
                font-size: 18px;
                font-weight: 900;
                color: #0f172a;
            }
            QGroupBox#adminGroup {
                border: 1px solid #e2e8f0;
                border-radius: 16px;
                margin-top: 10px;
                padding: 14px;
                background: #f8fafc;
                font-weight: 900;
                color: #0f172a;
            }
            QGroupBox#adminGroup::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 6px;
            }
            QLineEdit, QComboBox {
                min-height: 40px;
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                padding: 8px 12px;
                background: #ffffff;
                color: #0f172a;
                font-size: 14px;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 2px solid #2563eb;
                background: #ffffff;
            }
            QTableWidget#adminTable {
                background: #ffffff;
                border: 1px solid #e2e8f0;
                border-radius: 14px;
                gridline-color: transparent;
                selection-background-color: #dbeafe;
                selection-color: #0f172a;
                alternate-background-color: #f8fafc;
            }
            QTableWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eef2f7;
            }
            QHeaderView::section {
                background: #f8fafc;
                padding: 10px;
                font-weight: 900;
                color: #334155;
                border: 0px;
                border-bottom: 1px solid #e2e8f0;
            }
            QPushButton#adminGhostBtn {
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                background: #ffffff;
                color: #0f172a;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminGhostBtn:hover {
                background: #f8fafc;
            }
            QPushButton#adminPrimaryBtn {
                border-radius: 12px;
                border: 1px solid #2563eb;
                background: #2563eb;
                color: #ffffff;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminPrimaryBtn:hover {
                background: #1d4ed8;
            }
            QPushButton#adminDangerBtn {
                border-radius: 12px;
                border: 1px solid #fecaca;
                background: #ffffff;
                color: #b91c1c;
                font-weight: 900;
                padding: 10px 14px;
            }
            QPushButton#adminDangerBtn:hover {
                background: #fef2f2;
            }
        """)

        self.cb_region.currentTextChanged.connect(self.on_region_changed)
        self.cb_region.lineEdit().editingFinished.connect(self.on_region_changed)

        self.load()

    def _norm(self, value):
        return (value or "").strip().lower()

    def _unique_sorted(self, values):
        vals = sorted({(v or "").strip() for v in values if (v or "").strip()})
        return vals

    def _setup_editable_combo(self, combo: QComboBox, values):
        current = combo.currentText().strip()
        combo.blockSignals(True)
        combo.clear()
        combo.addItem("")
        for v in values:
            combo.addItem(v)
        combo.setCurrentText(current)
        combo.blockSignals(False)

        comp = QCompleter(values, combo)
        comp.setCaseSensitivity(Qt.CaseInsensitive)
        comp.setFilterMode(Qt.MatchContains)
        combo.setCompleter(comp)

    def rebuild_catalogs(self):
        self.load_master_files()

        giros = self._giros_master[:]
        regiones = self._regiones_master[:]
        comunas = self._comunas_master[:]

        # Güvenlik için DB'deki mevcut verileri de ekleyelim
        try:
            rows_clientes = db.list_clientes(limit=2000)
        except Exception:
            rows_clientes = []

        giros += [r.get("giro", "") for r in rows_clientes]
        regiones += [r.get("region", "") for r in rows_clientes]
        comunas += [r.get("comuna", "") for r in rows_clientes]

        self._setup_editable_combo(self.cb_giro, self._unique_sorted(giros))
        self._setup_editable_combo(self.cb_region, self._unique_sorted(regiones))
        self._setup_editable_combo(self.cb_comuna, self._unique_sorted(comunas))

        self._set_combo_style_fix()

    def load(self):
        try:
            rows = db.list_clientes(limit=2000)
        except Exception as e:
            show_error(self, "DB Error", str(e))
            rows = []

        self._all_rows = rows
        self.populate_table(rows)
        self.rebuild_catalogs()
        self._set_combo_style_fix()

    def populate_table(self, rows):
        self.tbl.setRowCount(0)
        for i, r in enumerate(rows):
            self.tbl.insertRow(i)
            self.tbl.setItem(i, 0, QTableWidgetItem(str(r.get("rut", ""))))
            self.tbl.setItem(i, 1, QTableWidgetItem(str(r.get("razon_social", ""))))
            self.tbl.setItem(i, 2, QTableWidgetItem(str(r.get("giro", ""))))
            self.tbl.setItem(i, 3, QTableWidgetItem(str(r.get("direccion", ""))))
            self.tbl.setItem(i, 4, QTableWidgetItem(str(r.get("region", ""))))
            self.tbl.setItem(i, 5, QTableWidgetItem(str(r.get("comuna", ""))))

    def apply_filter(self):
        q = self._norm(self.ed_filter.text())
        if not q:
            self.populate_table(self._all_rows)
            return

        filtered = []
        for r in self._all_rows:
            haystack = " | ".join([
                str(r.get("rut", "")),
                str(r.get("razon_social", "")),
                str(r.get("giro", "")),
                str(r.get("direccion", "")),
                str(r.get("region", "")),
                str(r.get("comuna", "")),
            ]).lower()

            if q in haystack:
                filtered.append(r)

        self.populate_table(filtered)

    def on_region_changed(self):
        region_txt = (self.cb_region.currentText() or "").strip().lower()

        if not region_txt:
            self._setup_editable_combo(self.cb_comuna, self._unique_sorted(self._comunas_master))
            self._set_combo_style_fix()
            return

        comunas = sorted(self._region_to_comunas.get(region_txt, set()))

        if not comunas:
            # fallback: DB’de varsa onları kullan
            comunas = self._unique_sorted([
                r.get("comuna", "")
                for r in self._all_rows
                if (r.get("region", "") or "").strip().lower() == region_txt
            ])

        self._setup_editable_combo(self.cb_comuna, comunas)
        self._set_combo_style_fix()

    def clear_form(self):
        self.tbl.clearSelection()
        self.ed_rut.clear()
        self.ed_razon.clear()
        self.cb_giro.setCurrentText("")
        self.ed_direccion.clear()
        self.cb_region.setCurrentText("")
        self.cb_comuna.setCurrentText("")

    def on_pick_row(self):
        items = self.tbl.selectedItems()
        if not items:
            return

        rut = self.tbl.item(self.tbl.currentRow(), 0).text()
        row = db.get_cliente_by_rut(rut)
        if not row:
            return

        self.ed_rut.setText(str(row.get("rut", "")))
        self.ed_razon.setText(str(row.get("razon_social", "")))
        self.cb_giro.setCurrentText(str(row.get("giro", "")))
        self.ed_direccion.setText(str(row.get("direccion", "")))
        self.cb_region.setCurrentText(str(row.get("region", "")))
        self.on_region_changed()
        self.cb_comuna.setCurrentText(str(row.get("comuna", "")))

    def save_cliente(self):
        rut = (self.ed_rut.text() or "").strip()
        razon = (self.ed_razon.text() or "").strip()
        giro = (self.cb_giro.currentText() or "").strip()
        direccion = (self.ed_direccion.text() or "").strip()
        region = (self.cb_region.currentText() or "").strip()
        comuna = (self.cb_comuna.currentText() or "").strip()

        if not rut:
            show_error(self, "Error", "RUT vacío.")
            return
        if not razon:
            show_error(self, "Error", "Razón Social vacía.")
            return

        try:
            db.upsert_cliente(
                rut=rut,
                razon_social=razon,
                giro=giro,
                direccion=direccion,
                region=region,
                comuna=comuna,
            )
        except Exception as e:
            show_error(self, "Error", str(e))
            return

        show_success(self, "Guardado", "Cliente guardado correctamente.")
        self.load()
        self.clear_form()

    def delete_cliente_ui(self):
        rut = (self.ed_rut.text() or "").strip()
        if not rut:
            show_info(self, "Información", "Selecciona un cliente para eliminar.")
            return

        if not ask_confirm(self, "Confirmar eliminación", f"¿Eliminar el cliente {rut}?"):
            return

        try:
            db.delete_cliente(rut)
        except Exception as e:
            show_error(self, "Error", str(e))
            return

        show_success(self, "Eliminado", "Cliente eliminado correctamente.")
        self.load()
        self.clear_form()

    def _project_file(self, filename: str) -> Path:
        return Path(os.getcwd()) / filename

    def load_master_files(self):
        self._giros_master = []
        self._regiones_master = []
        self._comunas_master = []
        self._region_to_comunas = {}

        # --- GIROS
        giros_path = self._project_file("giros.txt")
        if giros_path.exists():
            try:
                with open(giros_path, "r", encoding="utf-8") as f:
                    self._giros_master = [
                        line.strip() for line in f.readlines() if line.strip()
                    ]
            except Exception as e:
                print("Giros load error:", e)

        # --- REGIONES / COMUNAS
        json_candidates = [
            self._project_file("comunas_regiones.json"),
            self._project_file("regiones_ciudades.json"),
        ]

        for p in json_candidates:
            if not p.exists():
                continue

            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)

                # formato 1:
                # {"regiones":[{"region":"...","comunas":[...]}]}
                if isinstance(data, dict) and "regiones" in data:
                    for item in data["regiones"]:
                        region = (item.get("region") or "").strip()
                        comunas = [str(x).strip() for x in item.get("comunas", []) if str(x).strip()]
                        if region:
                            self._region_to_comunas[region.lower()] = set(comunas)

                # formato 2:
                # {"Región X":[...], "Región Y":[...]}
                elif isinstance(data, dict):
                    for region, comunas in data.items():
                        region = str(region).strip()
                        comunas = [str(x).strip() for x in comunas if str(x).strip()]
                        if region:
                            self._region_to_comunas[region.lower()] = set(comunas)

            except Exception as e:
                print("Region/comuna load error:", p, e)

        self._regiones_master = sorted({
            region for region in [
                next((k for k in self._region_to_comunas.keys() if k == key), key)
                for key in self._region_to_comunas.keys()
            ]
        })

        # region adlarını düzgün case ile tekrar üret
        self._regiones_master = sorted([
            next(
                (r for r in self._collect_region_display_names() if r.lower() == key),
                key.title()
            )
            for key in self._region_to_comunas.keys()
        ])

        all_comunas = set()
        for vals in self._region_to_comunas.values():
            all_comunas.update(vals)
        self._comunas_master = sorted(all_comunas)

    def _collect_region_display_names(self):
        names = set()

        p1 = self._project_file("comunas_regiones.json")
        if p1.exists():
            try:
                with open(p1, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict) and "regiones" in data:
                    for item in data["regiones"]:
                        region = (item.get("region") or "").strip()
                        if region:
                            names.add(region)
            except Exception:
                pass

        p2 = self._project_file("regiones_ciudades.json")
        if p2.exists():
            try:
                with open(p2, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    for region in data.keys():
                        region = str(region).strip()
                        if region:
                            names.add(region)
            except Exception:
                pass

        return sorted(names)

    def _set_combo_style_fix(self):
        combo_style = """
            QComboBox {
                min-height: 40px;
                border-radius: 12px;
                border: 1px solid #cbd5e1;
                padding: 6px 34px 6px 12px;
                background: #ffffff;
                color: #0f172a;
                font-size: 14px;
            }
            QComboBox:focus {
                border: 2px solid #2563eb;
            }
            QComboBox::drop-down {
                subcontrol-origin: padding;
                subcontrol-position: top right;
                width: 28px;
                border: none;
                margin-right: 6px;
                background: transparent;
                border-top-right-radius: 12px;
                border-bottom-right-radius: 12px;
            }
            QComboBox::down-arrow {
                image: none;
                width: 10px;
                height: 10px;
                border-left: 2px solid #64748b;
                border-bottom: 2px solid #64748b;
                transform: rotate(-45deg);
                margin-right: 6px;
            }
            QComboBox QAbstractItemView {
                border: 1px solid #cbd5e1;
                background: #ffffff;
                selection-background-color: #dbeafe;
                selection-color: #0f172a;
                outline: 0;
            }
        """
        self.cb_giro.setStyleSheet(combo_style)
        self.cb_region.setStyleSheet(combo_style)
        self.cb_comuna.setStyleSheet(combo_style)

# ------------------------------------------------------------
# Articulos Screen
# ------------------------------------------------------------
class ArticulosScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("ArticulosScreen")

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(12)

        title = QLabel("Artículos")
        title.setStyleSheet("font-size:26px;font-weight:800;")
        root.addWidget(title)

        desc = QLabel("Sacos, Categorías, Productos, Tallas y Segmento/Género.")
        desc.setStyleSheet("color:#64748b;font-size:14px;")
        root.addWidget(desc)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color:#e2e8f0;")
        root.addWidget(line)

        top = QHBoxLayout()
        top.setSpacing(10)

        self.section = QComboBox()
        self.section.addItems(["Sacos", "Categorias", "Productos", "Tallas", "Generos"])
        self.section.currentIndexChanged.connect(self.refresh)

        top.addWidget(QLabel("Sección:"))
        top.addWidget(self.section, 1)
        root.addLayout(top)

        self.listw = QListWidget()
        self.listw.setStyleSheet("font-size:16px;")
        self.listw.itemClicked.connect(self._on_item_selected)
        root.addWidget(self.listw, 1)

        addrow = QHBoxLayout()
        addrow.setSpacing(10)

        self.inp1 = QLineEdit(); self.inp1.setMinimumHeight(46)
        self.inp2 = QLineEdit(); self.inp2.setMinimumHeight(46)
        self.inp3 = QLineEdit(); self.inp3.setMinimumHeight(46)

        self.btn_add = QPushButton("➕ Agregar"); self.btn_add.setMinimumHeight(48)
        self.btn_del = QPushButton("🗑 Eliminar"); self.btn_del.setMinimumHeight(48)

        self.btn_add.clicked.connect(self.add_item)
        self.btn_del.clicked.connect(self.delete_item)

        addrow.addWidget(self.inp1, 2)
        addrow.addWidget(self.inp2, 2)
        addrow.addWidget(self.inp3, 2)
        addrow.addWidget(self.btn_add, 1)
        addrow.addWidget(self.btn_del, 1)
        root.addLayout(addrow)

        self.refresh()

    def refresh(self):
        self.listw.clear()
        sec = self.section.currentText()

        if sec == "Sacos":
            self.inp1.setPlaceholderText("Saco código (ej: QBMC)")
            self.inp2.setPlaceholderText("KG (ej: 25)")
            self.inp3.setPlaceholderText("Precio saco (CLP) ej: 9990")
            self.inp3.show()
        elif sec == "Productos":
            self.inp1.setPlaceholderText("Producto (ej: Blusa)")
            self.inp2.setPlaceholderText("Categoría (Ropa/Calzado/Hogar/Accesorios)")
            self.inp3.hide()
        else:
            self.inp1.setPlaceholderText("Nombre")
            self.inp2.setPlaceholderText("(vacío)")
            self.inp3.hide()

        try:
            if sec == "Sacos":
                for r in db.list_sacos():
                    codigo = r.get("codigo", "")
                    kg = int(r.get("kg", 0) or 0)
                    precio = int(r.get("precio_saco", 0) or 0)
                    precio_txt = f"{precio:,}".replace(",", ".")
                    self.listw.addItem(f"{codigo}  | kg={kg}  | $ {precio_txt}")

            elif sec == "Categorias":
                for c in db.list_categorias():
                    self.listw.addItem(str(c.get("nombre") if isinstance(c, dict) else c))

            elif sec == "Productos":
                cats = db.list_categorias()
                flat = [(c.get("nombre") if isinstance(c, dict) else str(c)) for c in cats]
                for cat in flat:
                    for p in db.list_productos_by_categoria(cat):
                        nombre = p.get("nombre") if isinstance(p, dict) else str(p)
                        self.listw.addItem(f"[{cat}] {nombre}")

            elif sec == "Tallas":
                for t in db.list_tallas():
                    self.listw.addItem(str(t.get("nombre") if isinstance(t, dict) else t))

            elif sec == "Generos":
                for g in db.list_generos():
                    self.listw.addItem(str(g.get("nombre") if isinstance(g, dict) else g))

        except Exception as e:
            QMessageBox.warning(self, "DB Error", f"Artículos refresh hatası:\n{e}")

    def _on_item_selected(self, item):
        text = item.text()
        parts = text.split("|")
        if len(parts) >= 2:
            codigo = parts[0].strip()
            kg_part = parts[1].replace("kg=", "").strip()
            self.inp1.setText(codigo)
            self.inp2.setText(kg_part)
            if len(parts) >= 3 and hasattr(self, "inp3"):
                precio_part = parts[2].replace("$", "").strip().replace(".", "")
                self.inp3.setText(precio_part)

    def add_item(self):
        sec = self.section.currentText()
        a = (self.inp1.text() or "").strip()
        b = (self.inp2.text() or "").strip()
        if not a:
            QMessageBox.warning(self, "Error", "Boş değer eklenemez.")
            return

        pr_txt = (self.inp3.text() or "").replace(".", "").replace(",", "").strip() if self.inp3.isVisible() else ""

        try:
            if sec == "Sacos":
                codigo = a.strip().upper()
                kg = int(b) if b.isdigit() else 0
                precio = int(pr_txt) if pr_txt.isdigit() else 0
                db.upsert_saco(codigo, kg, precio)

            elif sec == "Categorias":
                db.insert_categoria(a)

            elif sec == "Productos":
                if not b:
                    QMessageBox.warning(self, "Error", "Categoría girmelisin (Ropa/Calzado/Hogar/Accesorios).")
                    return
                db.insert_producto(a, b)

            elif sec == "Tallas":
                db.insert_talla(a)

            elif sec == "Generos":
                db.insert_genero(a)

            self.inp1.clear(); self.inp2.clear(); self.inp3.clear()
            self.refresh()

        except Exception as e:
            QMessageBox.warning(self, "DB Error", f"Ekleme hatası:\n{e}")

    def delete_item(self):
        sec = self.section.currentText().strip()
        it = self.listw.currentItem()

        if not it:
            QMessageBox.information(self, "Info", "Silmek için listeden bir satır seçmelisin.")
            return

        text = it.text().strip()

        if sec == "Sacos":
            codigo = text.split("|")[0].strip()
            if QMessageBox.question(self, "Confirmar", f"Bu saco silinsin mi?\n\n{codigo}") != QMessageBox.Yes:
                return
            try:
                db.delete_saco(codigo)
                self.refresh()
            except Exception as e:
                QMessageBox.critical(self, "DB Error", f"Silme hatası:\n{e}")
            return

        elif sec == "Productos":
            try:
                producto = text
                categoria = None

                # Format örneği: [Ropa] Deneme
                if text.startswith("[") and "]" in text:
                    categoria = text[1:text.index("]")].strip()
                    producto = text[text.index("]") + 1:].strip()

                if QMessageBox.question(
                    self,
                    "Confirmar",
                    f"Bu producto silinsin mi?\n\n{text}"
                ) != QMessageBox.Yes:
                    return

                # Eğer sende db içinde böyle bir fonksiyon varsa:
                if categoria:
                    db.delete_producto(producto, categoria)
                else:
                    db.delete_producto(producto)

                self.refresh()

            except Exception as e:
                QMessageBox.critical(self, "DB Error", f"Silme hatası:\n{e}")
            return

        QMessageBox.information(self, "Info", f"Şu an '{sec}' için silme aktif değil.")

# ------------------------------------------------------------
# Stock container (Stock + Articulos + Producción)
# ------------------------------------------------------------
class StockContainer(QWidget):
    def __init__(self, stock_page: QWidget, articulos_page: QWidget, production_page: QWidget):
        super().__init__()
        self.stack = QStackedWidget(self)

        self.page_stock = stock_page
        self.page_articulos = articulos_page
        self.page_production = production_page

        self.stack.addWidget(self.page_stock)
        self.stack.addWidget(self.page_articulos)
        self.stack.addWidget(self.page_production)

        self.stack.setCurrentWidget(self.page_stock)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self.stack)

    def _refresh_current_page_layout(self):
        try:
            w = self.stack.currentWidget()
            if w:
                w.setMinimumSize(0, 0)
                w.updateGeometry()
                w.resize(self.stack.size())
                if w.layout():
                    w.layout().invalidate()
                    w.layout().activate()
                w.update()

            self.stack.updateGeometry()
            if self.layout():
                self.layout().invalidate()
                self.layout().activate()

            self.update()
        except Exception as e:
            print("StockContainer layout refresh error:", e)

    def show_stock(self):
        self.stack.setCurrentWidget(self.page_stock)
        QTimer.singleShot(0, self._refresh_current_page_layout)

    def show_articulos(self):
        self.stack.setCurrentWidget(self.page_articulos)
        QTimer.singleShot(0, self._refresh_current_page_layout)

    def show_production(self):
        self.stack.setCurrentWidget(self.page_production)
        QTimer.singleShot(0, self._refresh_current_page_layout)


# ------------------------------------------------------------
# Ajustes > Usuarios (Admin / Permisos)
# ------------------------------------------------------------
class BoletaSettingsScreen(QWidget):
    def __init__(self):
        super().__init__()

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(10)

        title = QLabel("Ajustes · Boleta / Factura")
        title.setStyleSheet("font-size:24px;font-weight:900;")
        root.addWidget(title)

        desc = QLabel("Configura los datos de la empresa y los textos impresos en boleta/factura.")
        desc.setStyleSheet("color:#64748b;")
        desc.setWordWrap(True)
        root.addWidget(desc)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color:#e2e8f0;")
        root.addWidget(line)

        form_box = QGroupBox("Datos de impresión")
        form = QFormLayout(form_box)
        form.setVerticalSpacing(10)

        self.ed_titulo = QLineEdit()
        self.ed_razon = QLineEdit()
        self.ed_rut = QLineEdit()
        self.ed_direccion = QLineEdit()
        self.ed_giro = QLineEdit()
        self.ed_telefono = QLineEdit()
        self.ed_email = QLineEdit()
        self.ed_msg1 = QLineEdit()
        self.ed_msg2 = QLineEdit()

        form.addRow("Título negocio:", self.ed_titulo)
        form.addRow("Razón social:", self.ed_razon)
        form.addRow("RUT:", self.ed_rut)
        form.addRow("Dirección:", self.ed_direccion)
        form.addRow("Giro:", self.ed_giro)
        form.addRow("Teléfono:", self.ed_telefono)
        form.addRow("Email:", self.ed_email)
        form.addRow("Mensaje 1:", self.ed_msg1)
        form.addRow("Mensaje 2:", self.ed_msg2)

        root.addWidget(form_box)

        btnrow = QHBoxLayout()
        self.btn_guardar = QPushButton("💾 Guardar")
        self.btn_guardar.setObjectName("Primary")
        self.btn_recargar = QPushButton("🔄 Recargar")

        self.btn_guardar.clicked.connect(self.save_data)
        self.btn_recargar.clicked.connect(self.load_data)

        btnrow.addWidget(self.btn_guardar)
        btnrow.addWidget(self.btn_recargar)
        btnrow.addStretch(1)

        root.addLayout(btnrow)
        root.addStretch(1)

        self.setStyleSheet("""
            QGroupBox { border:1px solid #e2e8f0; border-radius:14px; margin-top:8px; padding:10px; background:#ffffff; font-weight:900; }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding:0 6px; }
            QLineEdit { min-height:40px; border-radius:10px; border:1px solid #cbd5e1; padding:6px 10px; background:#ffffff; }
            QPushButton { border-radius:12px; border:1px solid #cbd5e1; background:#ffffff; font-weight:900; padding:10px 14px; }
            QPushButton#Primary { background:#2563eb; border:1px solid #2563eb; color:#ffffff; }
        """)

        self.load_data()

    def load_data(self):
        try:
            cfg = db.get_boleta_config()
        except Exception as e:
            QMessageBox.warning(self, "DB", str(e))
            cfg = {}

        self.ed_titulo.setText(str(cfg.get("titulo_negocio", "")))
        self.ed_razon.setText(str(cfg.get("razon_social", "")))
        self.ed_rut.setText(str(cfg.get("rut", "")))
        self.ed_direccion.setText(str(cfg.get("direccion", "")))
        self.ed_giro.setText(str(cfg.get("giro", "")))
        self.ed_telefono.setText(str(cfg.get("telefono", "")))
        self.ed_email.setText(str(cfg.get("email", "")))
        self.ed_msg1.setText(str(cfg.get("mensaje_cambio_1", "")))
        self.ed_msg2.setText(str(cfg.get("mensaje_cambio_2", "")))

    def save_data(self):
        try:
            db.save_boleta_config(
                titulo_negocio=(self.ed_titulo.text() or "").strip(),
                razon_social=(self.ed_razon.text() or "").strip(),
                rut=(self.ed_rut.text() or "").strip(),
                direccion=(self.ed_direccion.text() or "").strip(),
                giro=(self.ed_giro.text() or "").strip(),
                telefono=(self.ed_telefono.text() or "").strip(),
                email=(self.ed_email.text() or "").strip(),
                mensaje_cambio_1=(self.ed_msg1.text() or "").strip(),
                mensaje_cambio_2=(self.ed_msg2.text() or "").strip(),
            )
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
            return

        QMessageBox.information(self, "OK", "Guardado ✅")

class BoletaLayoutScreen(QWidget):

    def __init__(self):
        super().__init__()

        self.main_layout = QVBoxLayout()

        title = QLabel("Ajustes · Diseño de Boleta")
        title.setStyleSheet("font-size:24px;font-weight:900;")
        self.main_layout.addWidget(title)

        form = QFormLayout()

        self.header_align = QComboBox()
        self.header_align.addItems(["left", "center", "right"])

        self.header_width = QSpinBox()
        self.header_width.setRange(1, 4)

        self.header_height = QSpinBox()
        self.header_height.setRange(1, 4)

        self.empresa_width = QSpinBox()
        self.empresa_width.setRange(1, 4)

        self.empresa_height = QSpinBox()
        self.empresa_height.setRange(1, 4)

        self.rut_width = QSpinBox()
        self.rut_width.setRange(1, 4)

        self.rut_height = QSpinBox()
        self.rut_height.setRange(1, 4)

        self.direccion_width = QSpinBox()
        self.direccion_width.setRange(1, 4)

        self.direccion_height = QSpinBox()
        self.direccion_height.setRange(1, 4)

        self.item_spacing = QSpinBox()
        self.item_spacing.setRange(0, 5)

        self.footer_align = QComboBox()
        self.footer_align.addItems(["left", "center", "right"])

        self.footer_width = QSpinBox()
        self.footer_width.setRange(1, 4)

        self.footer_height = QSpinBox()
        self.footer_height.setRange(1, 4)

        self.footer_msg1 = QLineEdit()
        self.footer_msg2 = QLineEdit()

        form.addRow("Header Align", self.header_align)
        form.addRow("Header Width", self.header_width)
        form.addRow("Header Height", self.header_height)
        form.addRow("Empresa Width", self.empresa_width)
        form.addRow("Empresa Height", self.empresa_height)
        form.addRow("RUT Width", self.rut_width)
        form.addRow("RUT Height", self.rut_height)
        form.addRow("Direccion Width", self.direccion_width)
        form.addRow("Direccion Height", self.direccion_height)
        form.addRow("Item Spacing", self.item_spacing)
        form.addRow("Footer Align", self.footer_align)
        form.addRow("Footer Width", self.footer_width)
        form.addRow("Footer Height", self.footer_height)
        form.addRow("Footer Msg1", self.footer_msg1)
        form.addRow("Footer Msg2", self.footer_msg2)

        self.main_layout.addLayout(form)

        btn_guardar = QPushButton("Guardar")
        btn_guardar.clicked.connect(self.save)
        self.main_layout.addWidget(btn_guardar)

        btn_test = QPushButton("Imprimir prueba")
        btn_test.clicked.connect(self.test_print)
        self.main_layout.addWidget(btn_test)

        self.setLayout(self.main_layout)

        self.load()

    def load(self):

        cfg = db.get_boleta_layout()

        self.header_align.setCurrentText(cfg["header_align"])
        self.header_width.setValue(cfg["header_width"])
        self.header_height.setValue(cfg["header_height"])

        self.empresa_width.setValue(cfg["empresa_width"])
        self.empresa_height.setValue(cfg["empresa_height"])

        self.rut_width.setValue(cfg["rut_width"])
        self.rut_height.setValue(cfg["rut_height"])

        self.direccion_width.setValue(cfg["direccion_width"])
        self.direccion_height.setValue(cfg["direccion_height"])

        self.item_spacing.setValue(cfg["item_spacing"])

        self.footer_align.setCurrentText(cfg["footer_align"])
        self.footer_width.setValue(cfg["footer_width"])
        self.footer_height.setValue(cfg["footer_height"])

        self.footer_msg1.setText(cfg["footer_msg1"])
        self.footer_msg2.setText(cfg["footer_msg2"])

    def save(self):

        data = {
            "header_align": self.header_align.currentText(),
            "header_width": self.header_width.value(),
            "header_height": self.header_height.value(),

            "empresa_width": self.empresa_width.value(),
            "empresa_height": self.empresa_height.value(),

            "rut_width": self.rut_width.value(),
            "rut_height": self.rut_height.value(),

            "direccion_width": self.direccion_width.value(),
            "direccion_height": self.direccion_height.value(),

            "item_spacing": self.item_spacing.value(),

            "footer_align": self.footer_align.currentText(),
            "footer_width": self.footer_width.value(),
            "footer_height": self.footer_height.value(),

            "footer_msg1": self.footer_msg1.text(),
            "footer_msg2": self.footer_msg2.text()
        }

        db.save_boleta_layout(data)

        QMessageBox.information(self,"OK","Guardado")


class AjustesScreen(QWidget):
    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(10)

        title = QLabel("Ajustes")
        title.setStyleSheet("font-size:26px;font-weight:900;")
        root.addWidget(title)

        nav = QHBoxLayout()
        self.btn_usuarios = QPushButton("Usuarios")
        self.btn_sucursales = QPushButton("Sucursales")

        self.btn_usuarios.clicked.connect(lambda: self.stack.setCurrentWidget(self.page_usuarios))
        self.btn_sucursales.clicked.connect(lambda: self.stack.setCurrentWidget(self.page_sucursales))

        nav.addWidget(self.btn_usuarios)
        nav.addWidget(self.btn_sucursales)
        nav.addStretch(1)
        root.addLayout(nav)

        self.stack = QStackedWidget()
        root.addWidget(self.stack, 1)

        self.page_usuarios = UsuariosAdminScreen()
        self.page_sucursales = SucursalesAdminScreen()

        self.stack.addWidget(self.page_usuarios)
        self.stack.addWidget(self.page_sucursales)
        self.stack.setCurrentWidget(self.page_usuarios)

    def refresh(self):
        if hasattr(self.page_usuarios, "load_sucursales"):
            self.page_usuarios.load_sucursales()
        if hasattr(self.page_usuarios, "load"):
            self.page_usuarios.load()
        if hasattr(self.page_sucursales, "load"):
            self.page_sucursales.load()

class InicioPage(QWidget):
    def __init__(self):
        super().__init__()

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        center = QVBoxLayout()
        center.setAlignment(Qt.AlignCenter)

        self.title = QLabel("VR9")
        self.title.setAlignment(Qt.AlignCenter)
        self.title.setObjectName("inicioTitle")

        self.subtitle = QLabel("Retail System")
        self.subtitle.setAlignment(Qt.AlignCenter)
        self.subtitle.setObjectName("inicioSub")

        center.addWidget(self.title)
        center.addWidget(self.subtitle)

        root.addStretch(1)
        root.addLayout(center)
        root.addStretch(1)

        self.apply_style("light")

    def apply_style(self, theme="light"):
        if theme == "dark":
            self.setStyleSheet("""
                QLabel#inicioTitle {
                    font-size: 160px;
                    font-weight: 900;
                    letter-spacing: 4px;
                    color: qlineargradient(
                        x1:0, y1:0, x2:1, y2:0,
                        stop:0 rgba(59,130,246,0.12),
                        stop:1 rgba(37,99,235,0.18)
                    );
                }
                QLabel#inicioSub {
                    color: rgba(255,255,255,0.18);
                    font-size: 22px;
                    font-weight: 600;
                }
            """)
        else:
            self.setStyleSheet("""
                QLabel#inicioTitle {
                    color: rgba(15,23,42,0.12);
                    font-size: 160px;
                    letter-spacing: 4x;
                    font-weight: 900;
                }
                QLabel#inicioSub {
                    color: rgba(15,23,42,0.18);
                    font-size: 26px;
                    letter-spacing: 2x;
                    font-weight: 600;
                }
            """)
# ------------------------------------------------------------
# Main Window
# ------------------------------------------------------------

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VR9")
        self.setWindowIcon(QIcon("assets/logo/app_icon.ico"))
        screen = QGuiApplication.primaryScreen().availableGeometry()
        w = min(1360, screen.width() - 40)
        h = min(820, screen.height() - 60)
        self.resize(w, h)
        self.move(
            screen.x() + (screen.width() - w) // 2,
            screen.y() + (screen.height() - h) // 2
        )

        # ---- DB init
        try:
            db.init_db()
            if hasattr(db, "ensure_admin"):
                db.ensure_admin()
            if hasattr(db, "seed_defaults"):
                db.seed_defaults()
        except Exception as e:
            QMessageBox.warning(self, "DB Error", f"init_db / seed hatası:\n{e}")

        # ----- Login
        dlg = LoginDialog(self, settings_callback=self.open_db_settings)
        if dlg.exec() != QDialog.Accepted or not dlg.user:
            sys.exit(0)

        self.user = dlg.user
        self.sucursal_id = self.user.get("sucursal_id")

        role_txt = self.user.get("role", "user")

        # ---- Root
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ---- Top fixed navigation
        self.top_nav = QWidget()
        self.top_nav.setObjectName("topNav")
        top_nav_layout = QVBoxLayout(self.top_nav)
        top_nav_layout.setContentsMargins(10, 4, 10, 2)
        top_nav_layout.setSpacing(4)

        # Header
        header_row = QHBoxLayout()
        header_row.setSpacing(10)
        header_row.setContentsMargins(0, 0, 0, 0)

        self.menu_row = QHBoxLayout()
        self.menu_row.setSpacing(0)
        self.menu_row.setContentsMargins(0, 0, 0, 0)

        header_row.addLayout(self.menu_row, 1)
        header_row.addStretch(1)

        role_txt = self.user.get("role", "user")
        sucursal = ""
        if self.user.get("sucursal_id"):
            try:
               s = db.get_sucursal_by_id(int(self.user.get("sucursal_id")))
               if s:
                   sucursal = s.get("nombre", "")
            except Exception:
                sucursal = ""

        self.user_badge = QLabel(f"{self.user.get('usuario','')} · {sucursal}")
        self.user_badge.setObjectName("userBadge")
        header_row.addWidget(self.user_badge, 0, Qt.AlignVCenter)

        self.btn_theme = QToolButton()
        self.btn_theme.setText("🌙")
        self.btn_theme.setObjectName("themeBtn")
        self.btn_theme.setToolTip("Cambiar tema")
        self.btn_theme.clicked.connect(self.toggle_theme)
        header_row.addWidget(self.btn_theme, 0, Qt.AlignVCenter)
        self.btn_theme.setFixedSize(34, 34)

        btn_exit = QPushButton("Salir")
        btn_exit.setMinimumHeight(34)
        btn_exit.setMinimumWidth(72)
        btn_exit.setObjectName("exitBtn")
        btn_exit.clicked.connect(self.confirm_exit)
        header_row.addWidget(btn_exit, 0, Qt.AlignVCenter)

        top_nav_layout.addLayout(header_row)

        # Submenu holder
        self.submenu_holder = QWidget()
        self.submenu_holder.setObjectName("submenuHolder")
        self.submenu_holder_layout = QVBoxLayout(self.submenu_holder)
        self.submenu_holder_layout.setContentsMargins(0, 0, 0, 0)
        self.submenu_holder_layout.setSpacing(8)
        top_nav_layout.addWidget(self.submenu_holder)

        root.addWidget(self.top_nav, 0)

        # ---- Page tabs
        self.page_tabs = QTabBar()
        self.page_tabs.setObjectName("pageTabs")
        self.page_tabs.setDocumentMode(True)
        self.page_tabs.setMovable(True)
        self.page_tabs.setMinimumHeight(22)
        self.page_tabs.setTabsClosable(True)
        self.page_tabs.setExpanding(False)
        self.page_tabs.setUsesScrollButtons(True)
        self.page_tabs.setElideMode(Qt.ElideRight)
        self.page_tabs.currentChanged.connect(self._on_tab_changed)
        self.page_tabs.tabCloseRequested.connect(self._on_tab_close)
        self._current_page_key = None

        root.addWidget(self.page_tabs, 0)

        # ---- Content stack
        self.stacked = QStackedWidget()
        self.stacked.setObjectName("content")

        self.page_inicio = InicioPage()

        StockCls = import_first_class(
            module_names=["stock_screen", "stock", "stock_page"],
            class_names=["StockScreen", "StockPage"]
        )
        stock_main = make_qwidget(StockCls, "Stock") if StockCls else PlaceholderPage("Stock", "Stock ana ekranı (placeholder).")

        self.page_articulos = ArticulosScreen()
        self.page_transfer = PlaceholderPage("Transfer", "Transfer ekranı burada olacak.")
        self.page_resumen_ventas = VentasResumenScreen()
        self.page_production = ProductionWizard(usuario=self.user.get("usuario", ""))
        self.page_stock_container = StockContainer(stock_main, self.page_articulos, self.page_production)
        self.page_hoja_entrada = HojaEntradaScreen()
        self.page_hoja_entrada.production_editor_requested.connect(self.open_production_editor_from_entrada)

        # INFORMES
        self.page_report_manager = ReportManagerPage(self)
        self.page_report_manager.open_report_requested.connect(self.open_embedded_report)

        # CREAR
        self.page_crear_sucursal = SucursalesAdminScreen()
        self.page_crear_usuario = UsuariosAdminScreen()
        self.page_crear_cliente = ClientesAdminScreen()
        self.page_ofertas = OfertasScreen()

        # AJUSTES
        from boleta_designer import BoletaDesigner

        self.page_ajustes_boleta = BoletaDesigner()
        self.page_ajustes_impresora = PlaceholderPage("Ajustes · Impresora", "Impresora ayarları burada olacak.")
        self.page_ajustes_logo = PlaceholderPage("Ajustes · Logo", "Logo ayarları burada olacak.")

        # DATABASE
        self.page_database_empresa = PlaceholderPage("Database · Datos De Empresa", "Empresa verileri burada olacak.")
        self.page_bolsas = BolsasScreen()

        self.stacked.addWidget(self.page_inicio)                 # 0
        self.stacked.addWidget(self.page_stock_container)        # 1
        self.stacked.addWidget(self.page_transfer)               # 2
        self.stacked.addWidget(self.page_report_manager)         # 3
        self.stacked.addWidget(self.page_hoja_entrada)           # 4
        self.stacked.addWidget(self.page_crear_sucursal)         # 5
        self.stacked.addWidget(self.page_crear_usuario)          # 6
        self.stacked.addWidget(self.page_crear_cliente)          # 7
        self.stacked.addWidget(self.page_ofertas)                # 8
        self.stacked.addWidget(self.page_ajustes_boleta)         # 9
        self.stacked.addWidget(self.page_ajustes_impresora)      # 10
        self.stacked.addWidget(self.page_ajustes_logo)           # 11
        self.stacked.addWidget(self.page_database_empresa)       # 13
        self.stacked.addWidget(self.page_bolsas)                 # 14

        root.addWidget(self.stacked, 1)

        # ---- Menu buttons
        self.buttons: Dict[str, QPushButton] = {}
        self.sub_buttons: Dict[str, QPushButton] = {}
        self.group_containers: Dict[str, QWidget] = {}
        self.group_layouts: Dict[str, QHBoxLayout] = {}
        self.group_states: Dict[str, bool] = {}
        self.group_titles: Dict[str, str] = {}
        self.group_icons: Dict[str, str] = {}
        self.current_theme = "light"

        def menu_btn(text: str, key: str, fn, icon: str = ""):
            b = QPushButton(f"{icon}  {text}".strip())
            b.setMinimumHeight(32)
            b.setMinimumWidth(110)
            b.setObjectName("topMenuBtn")
            b.clicked.connect(fn)
            self.menu_row.addWidget(b, 0)
            self.buttons[key] = b
            return b

        def create_group(group_key: str, title: str, icon: str, click_fn=None):
            btn = QPushButton(f"{icon}  {title}")
            btn.setMinimumHeight(30)
            btn.setMinimumWidth(102)
            btn.setObjectName("topMenuBtn")

            if click_fn is not None:
                btn.clicked.connect(click_fn)
            else:
                btn.clicked.connect(lambda: self.toggle_group(group_key))

            self.menu_row.addWidget(btn, 0)

            cont = QWidget()
            cont.setObjectName("subContainer")
            lay = QHBoxLayout(cont)
            lay.setContentsMargins(6, 6, 6, 6)
            lay.setSpacing(2)
            cont.setVisible(False)
            self.submenu_holder_layout.addWidget(cont)

            self.buttons[group_key] = btn
            self.group_containers[group_key] = cont
            self.group_layouts[group_key] = lay
            self.group_states[group_key] = False
            self.group_titles[group_key] = title
            self.group_icons[group_key] = icon
            return btn, lay

        def sub_btn(group_key: str, text: str, key: str, fn):
            b = QPushButton(text)
            b.setMinimumHeight(42)
            b.setObjectName("subBtn")
            b.clicked.connect(fn)
            self.group_layouts[group_key].addWidget(b, 0)
            self.sub_buttons[key] = b
            return b

        def open_bolsas(self):
            self.stacked.setCurrentWidget(self.page_bolsas)

        # INICIO
        menu_btn("INICIO", "inicio", lambda: self.open_page("inicio"), "⌂")

        # STOCK
        create_group("stock", "STOCK", "📦")
        sub_btn("stock", "Artículos", "sub_articulos", lambda: self.open_page("articulos"))
        sub_btn("stock", "Hoja de Entrada", "sub_hoja_entrada", self.open_hoja_entrada_page)
        sub_btn("stock", "Transfer", "sub_transfer", lambda: self.open_page("transfer"))
        sub_btn("stock", "Producción", "sub_produccion", lambda: self.open_page("production"))

        # INFORMES
        create_group("informes", "INFORMES", "📊", click_fn=self.open_report_manager)

        # CREAR
        create_group("crear", "CREAR", "✨")
        sub_btn("crear", "Sucursal", "sub_crear_sucursal", lambda: self.open_page("crear_sucursal"))
        sub_btn("crear", "Usuario", "sub_crear_usuario", lambda: self.open_page("crear_usuario"))
        sub_btn("crear", "Cliente", "sub_crear_cliente", lambda: self.open_page("crear_cliente"))
        sub_btn("crear", "Ofertas", "sub_crear_ofertas", lambda: self.open_page("crear_ofertas"))

        # AJUSTES
        create_group("ajustes", "AJUSTES", "⚙️")
        sub_btn("ajustes", "Boleta/Factura", "sub_aj_boleta", lambda: self.open_page("aj_boleta"))
        sub_btn("ajustes", "Impresora", "sub_aj_impresora", lambda: self.open_page("aj_impresora"))
        sub_btn("ajustes", "Logo", "sub_aj_logo", lambda: self.open_page("aj_logo"))

        # DATABASE
        create_group("database", "DATABASE", "🗄️")
        sub_btn("database", "Datos De Empresa", "sub_db_empresa", lambda: self.open_page("db_empresa"))
        sub_btn("database", "Bolsas", "sub_db_bolsas", lambda: self.open_page("db_bolsas"))

        self.menu_row.addStretch(1)

        # POS / Upgrade right side
        menu_btn("POS", "pos", self.open_pos, "🧾")

        # UPGRADE
        menu_btn("UPGRADE", "upgrade", lambda: run_upgrade(self), "🚀")

        self.apply_styles()
        self.apply_permissions()

        self.open_page("inicio")
        self.showMaximized()
        QTimer.singleShot(0, self._fix_initial_layout)
        QTimer.singleShot(150, self._fix_initial_layout)

    # -------------------- Top menu groups --------------------
    def set_group_expanded(self, group_key: str, expanded: bool):
        expanded = bool(expanded)
        self.group_states[group_key] = expanded
        self.group_containers[group_key].setVisible(expanded)

    def collapse_all_groups(self):
        for key in self.group_containers.keys():
            self.set_group_expanded(key, False)

    def toggle_group(self, group_key: str):
        if not self.buttons[group_key].isEnabled():
            return
        current = self.group_states.get(group_key, False)
        self.collapse_all_groups()
        self.set_group_expanded(group_key, not current)

    def close_submenus(self):
        self.collapse_all_groups()

    def _tab_title_for_key(self, key: str) -> str:
        titles = {
            "inicio": "Inicio",
            "stock": "Stock",
            "articulos": "Artículos",
            "transfer": "Transfer",
            "production": "Producción",
            "report_manager": "Informes",
            "analizar_ventas": "Analizar Venta",
            "ventas_resumen": "Resumen De Ventas",
            "crear_sucursal": "Crear · Sucursal",
            "crear_usuario": "Crear · Usuario",
            "crear_cliente": "Crear · Cliente",
            "crear_ofertas": "Ofertas",
            "aj_boleta": "Boleta/Factura",
            "aj_impresora": "Ajustes · Impresora",
            "aj_logo": "Ajustes · Logo",
            "db_empresa": "Datos de empresa",
            "db_bolsas": "Bolsas",
        }
        return titles.get(key, key)

    def _find_tab_index(self, key: str) -> int:
        for i in range(self.page_tabs.count()):
            if self.page_tabs.tabData(i) == key:
                return i
        return -1

    def _ensure_tab(self, key: str):
        if key == "inicio":
            self.page_tabs.blockSignals(True)
            self.page_tabs.setCurrentIndex(-1)
            self.page_tabs.blockSignals(False)
            return

        idx = self._find_tab_index(key)
        if idx == -1:
            idx = self.page_tabs.addTab(self._tab_title_for_key(key))
            self.page_tabs.setTabData(idx, key)

        self.page_tabs.blockSignals(True)
        self.page_tabs.setCurrentIndex(idx)
        self.page_tabs.blockSignals(False)

    def _on_tab_changed(self, index: int):
        if index < 0:
            return
        key = self.page_tabs.tabData(index)
        if not key:
            return
        if key == self._current_page_key:
            return
        self.open_page(key, from_tab=True)

    def _on_tab_close(self, index: int):
        if index < 0:
            return
        was_current = (index == self.page_tabs.currentIndex())
        self.page_tabs.removeTab(index)
        if self.page_tabs.count() == 0:
            self._current_page_key = None
            self.open_page("inicio")
            return
        if was_current:
            new_index = min(index, self.page_tabs.count() - 1)
            self.page_tabs.setCurrentIndex(new_index)

    def open_db_settings(self):
        dlg = DBSettingsDialog(self)
        if dlg.exec() == QDialog.Accepted:
            QMessageBox.information(
                self,
                "Guardado",
                "Configuración guardada.\nReinicia el programa para usar la nueva conexión."
            )

    # -------------------- Style --------------------
    def apply_styles(self):
        self.setFont(QFont("Segoe UI", 10))
        if self.current_theme == "dark":
            palette = {
                "window": "#0b1220",
                "topnav": "#0d1625",
                "border": "#1f2b3d",
                "card": "#111b2d",
                "card_hover": "#172336",
                "text": "#e5e7eb",
                "muted": "#94a3b8",
                "primary": "#3b82f6",
                "sub_bg": "#0f1a2d",
                "sub_btn": "#162033",
                "danger_text": "#fecaca",
                "danger_border": "#7f1d1d",
                "danger_bg": "#2a1111"
            }

        else:
            palette = {
                "window": "#e9eef5", "topnav": "#f8fafc", "border": "#dbe2ea",
                "card": "#ffffff", "card_hover": "#eff6ff", "text": "#0f172a",
                "muted": "#64748b", "primary": "#2563eb", "sub_bg": "#ffffff",
                "sub_btn": "#f8fafc", "danger_text": "#b91c1c", "danger_border": "#fecaca", "danger_bg": "#ffffff"
            }

        self.setStyleSheet(f"""
            QMainWindow {{
                background: {palette['window']};
            }}
            QWidget#topNav {{
                background: {palette['topnav']};
                border-bottom: 1px solid {palette['border']};
            }}
            QStackedWidget#content {{
                background: {palette['window']};
            }}
            QLabel#userBadge {{
                background: {palette['card']};
                color: {palette['text']};
                border: 1px solid {palette['border']};
                border-radius: 02px;
                padding: 6px 16px;
                font-size: 11px;
                font-weight: 700;
            }}
            QToolButton#themeBtn {{
                background: {palette['card']};
                color: {palette['text']};
                border: 1px solid {palette['border']};
                border-radius: 10px;
                padding: 4px;
                font-size: 13px;
                font-weight: 700;
            }}
            QToolButton#themeBtn:hover {{
                background: {palette['card_hover']};
            }}
            QPushButton#topMenuBtn {{
                background: transparent;
                color: {palette['text']};
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0px;
                padding: 4px 8px;
                font-size: 12px;
                font-weight: 700;
            }}
            QPushButton#topMenuBtn:hover {{
                background: {palette['card_hover']};
            }}
            QPushButton#topMenuBtn[active="true"] {{
                color: {palette['primary']};
                border-bottom: 2px solid {palette['primary']};
                background: transparent;
            }}
            QWidget#submenuHolder {{
                background: transparent;
            }}
            QWidget#subContainer {{
                background: {palette['sub_bg']};
                border: 1px solid {palette['border']};
                border-radius: 14px;
            }}
            QPushButton#subBtn {{
                background: {palette['sub_btn']};
                color: {palette['text']};
                border: 1px solid {palette['border']};
                border-radius: 11px;
                padding: 8px 14px;
                font-size: 12px;
                font-weight: 800;
                text-align: center;
            }}
            QPushButton#subBtn:hover {{
                background: {palette['card_hover']};
                color: {palette['primary']};
                border: 1px solid #93c5fd;
            }}
            QPushButton#exitBtn {{
                background: {palette['danger_bg']};
                color: {palette['danger_text']};
                border: 1px solid {palette['danger_border']};
                border-radius: 10px;
                font-size: 12px;
                font-weight: 800;
                padding: 6px 12px;
            }}
            QPushButton#exitBtn:hover {{
                background: {palette['card_hover']};
            }}
            QPushButton:disabled {{
                color: {palette['muted']};
                background: {palette['sub_btn']};
                border: 1px solid {palette['border']};
            }}
            QTabBar#pageTabs {{
                background: {palette['topnav']};
            }}
            QTabBar#pageTabs::tab {{
                background: {palette['card']};
                color: {palette['text']};
                border: 1px solid {palette['border']};
                border-bottom: none;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                padding: 3px 8px;
                margin-right: 1px;
                min-width: 92px;
                min-height: 24px;
                font-size: 11px;
                font-weight: 700;
            }}
            QTabBar#pageTabs::tab:selected {{
                color: {palette['primary']};
                background: {palette['card_hover']};
            }}
            QTabBar#pageTabs::tab:hover {{
                background: {palette['card_hover']};
            }}
        """)

    def toggle_theme(self):
        self.current_theme = "dark" if self.current_theme == "light" else "light"
        self.apply_styles()
        self.set_active(getattr(self, "_active_key", "inicio"))

        # 👇 bunu ekle
        if hasattr(self, "page_inicio"):
            self.page_inicio.apply_style(self.current_theme)

    # -------------------- Permissions --------------------
    def apply_permissions(self):
        is_admin = (self.user.get("role") == "admin")

        can_pos = bool(self.user.get("can_pos")) or is_admin
        can_stock = bool(self.user.get("can_stock")) or is_admin
        can_prod = bool(self.user.get("can_production")) or is_admin
        can_inf = bool(self.user.get("can_informes")) or is_admin
        can_aj = bool(self.user.get("can_ajustes")) or is_admin
        can_db = bool(self.user.get("can_database")) or is_admin

        self.buttons["pos"].setEnabled(can_pos)
        self.buttons["stock"].setEnabled(can_stock)
        self.buttons["informes"].setEnabled(can_inf)
        self.buttons["crear"].setEnabled(can_aj or is_admin)
        self.buttons["ajustes"].setEnabled(can_aj)
        self.buttons["database"].setEnabled(can_db)
        self.buttons["upgrade"].setEnabled(is_admin)

        self.sub_buttons["sub_articulos"].setEnabled(can_stock)
        self.sub_buttons["sub_transfer"].setEnabled(can_stock)
        self.sub_buttons["sub_produccion"].setEnabled(can_stock and can_prod)

        if "informes" in self.buttons:
            self.buttons["informes"].setEnabled(can_inf)

        for key in ["sub_inf_ventas", "sub_inf_produccion", "sub_inf_analisis"]:
            if key in self.sub_buttons:
                self.sub_buttons[key].setEnabled(can_inf)

        self.sub_buttons["sub_crear_sucursal"].setEnabled(can_aj or is_admin)
        self.sub_buttons["sub_crear_usuario"].setEnabled(can_aj or is_admin)
        self.sub_buttons["sub_crear_cliente"].setEnabled(can_aj or is_admin)
        self.sub_buttons["sub_crear_ofertas"].setEnabled(is_admin)

        self.sub_buttons["sub_aj_boleta"].setEnabled(can_aj)
        self.sub_buttons["sub_aj_impresora"].setEnabled(can_aj)
        self.sub_buttons["sub_aj_logo"].setEnabled(can_aj)

        self.sub_buttons["sub_db_empresa"].setEnabled(can_db)
        self.sub_buttons["sub_db_bolsas"].setEnabled(can_db)

        self._can_pos = can_pos
        self._can_stock = can_stock
        self._can_prod = can_prod
        self._can_inf = can_inf
        self._can_aj = can_aj
        self._can_db = can_db

        self.close_submenus()

    # -------------------- Navigation --------------------
    def set_active(self, key: str):
        self._active_key = key
        for k, b in self.buttons.items():
            b.setProperty("active", k == key)
            b.style().unpolish(b)
            b.style().polish(b)

    def _refresh_visible_page_layout(self):
        try:
            current = self.stacked.currentWidget() if hasattr(self, "stacked") else None
            if current:
                current.setMinimumSize(0, 0)
                current.updateGeometry()
                current.resize(self.stacked.size())
                if current.layout():
                    current.layout().invalidate()
                    current.layout().activate()
                current.update()

            if self.centralWidget():
                self.centralWidget().updateGeometry()
                if self.centralWidget().layout():
                    self.centralWidget().layout().invalidate()
                    self.centralWidget().layout().activate()

            self.stacked.updateGeometry()
            self.stacked.update()
            self.updateGeometry()
            self.update()
        except Exception as e:
            print("Main layout refresh error:", e)

    def open_page(self, key: str, from_tab: bool = False):
        self.close_submenus()

        if not from_tab:
            self._ensure_tab(key)

        if key == "inicio":
            self.stacked.setCurrentWidget(self.page_inicio)
            self._current_page_key = key
            self.set_active("inicio")
            self.page_tabs.blockSignals(True)
            self.page_tabs.setCurrentIndex(-1)
            self.page_tabs.blockSignals(False)
            return

        if key == "stock":
            if not self._can_stock:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Stock.")
                return
            self.stacked.setCurrentWidget(self.page_stock_container)
            self.page_stock_container.show_stock()
            self._current_page_key = key
            self.set_active("stock")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "articulos":
            if not self._can_stock:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Stock.")
                return
            self.stacked.setCurrentWidget(self.page_stock_container)
            self.page_stock_container.show_articulos()
            self._current_page_key = key
            self.set_active("stock")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "production":
            if not (self._can_stock and self._can_prod):
                QMessageBox.information(self, "Permiso", "No tienes permiso para Producción.")
                return
            self.stacked.setCurrentWidget(self.page_stock_container)
            self.page_stock_container.show_production()
            self._current_page_key = key
            self.set_active("stock")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "transfer":
            if not self._can_stock:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Stock.")
                return
            self.stacked.setCurrentWidget(self.page_transfer)
            self._current_page_key = key
            self.set_active("stock")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "report_manager":
            if not self._can_inf:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Informes.")
                return
            self.stacked.setCurrentWidget(self.page_report_manager)
            self._current_page_key = key
            self.set_active("informes")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "crear_sucursal":
            self.stacked.setCurrentWidget(self.page_crear_sucursal)
            self._current_page_key = key
            self.set_active("crear")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "crear_usuario":
            self.stacked.setCurrentWidget(self.page_crear_usuario)
            self._current_page_key = key
            self.set_active("crear")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "crear_cliente":
            self.stacked.setCurrentWidget(self.page_crear_cliente)
            self._current_page_key = key
            self.set_active("crear")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "crear_ofertas":
            self.stacked.setCurrentWidget(self.page_ofertas)
            self._current_page_key = key
            self.set_active("crear")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "aj_boleta":
            if not self._can_aj:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Ajustes.")
                return
            self.stacked.setCurrentWidget(self.page_ajustes_boleta)
            self._current_page_key = key
            self.set_active("ajustes")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "aj_impresora":
            if not self._can_aj:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Ajustes.")
                return
            self.stacked.setCurrentWidget(self.page_ajustes_impresora)
            self._current_page_key = key
            self.set_active("ajustes")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "aj_logo":
            if not self._can_aj:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Ajustes.")
                return
            self.stacked.setCurrentWidget(self.page_ajustes_logo)
            self._current_page_key = key
            self.set_active("ajustes")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "db_empresa":
            if not self._can_db:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Database.")
                return
            self.stacked.setCurrentWidget(self.page_database_empresa)
            self._current_page_key = key
            self.set_active("database")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

        if key == "db_bolsas":
            if not self._can_db:
                QMessageBox.information(self, "Permiso", "No tienes permiso para Database.")
                return
            self.stacked.setCurrentWidget(self.page_bolsas)
            self._current_page_key = key
            self.set_active("database")
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            return

    def open_hoja_entrada_page(self):
        try:
            if hasattr(self, "page_hoja_entrada") and self.page_hoja_entrada:
                self.page_hoja_entrada._force_load_last()
                self.stacked.setCurrentWidget(self.page_hoja_entrada)
                self._current_page_key = "hoja_entrada"
                self.set_active("stock")
                return

            self.page_hoja_entrada = HojaEntradaScreen(modo="last")
            self.page_hoja_entrada.production_editor_requested.connect(
                self.open_production_editor_from_entrada
            )

            self.stacked.addWidget(self.page_hoja_entrada)

            # KRİTİK: ilk kez açarken de zorla son kaydı yükle
            self.page_hoja_entrada._force_load_last()

            self.stacked.setCurrentWidget(self.page_hoja_entrada)
            self._current_page_key = "hoja_entrada"
            self.set_active("stock")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Hoja de Entrada açılamadı:\n{e}")

    def open_production_editor_from_entrada(self, production_no: str):
        production_no = (production_no or "").strip()
        if not production_no:
            QMessageBox.information(
                self,
                "Producción Editor",
                "No hay número de producción."
            )
            return

        # Önce producción sayfasını aç
        self.open_page("production")
        prod = self.page_production

        try:
            if hasattr(prod, "load_production"):
                prod.load_production(production_no)
                return

            if hasattr(prod, "open_production"):
                prod.open_production(production_no)
                return

            if hasattr(prod, "set_production_no"):
                prod.set_production_no(production_no)

            if hasattr(prod, "set_edit_mode"):
                prod.set_edit_mode(True)

            if hasattr(prod, "load_by_production_no"):
                prod.load_by_production_no(production_no)
                return

            QMessageBox.information(
                self,
                "Producción Editor",
                f"La página de Producción se abrió.\n\nProducción No: {production_no}"
            )

        except Exception as e:
            QMessageBox.critical(
                self,
                "Producción Editor",
                f"No se pudo abrir Producción.\n\n{e}"
            )

    # -------------------- Informes (ventas_report.py Tkinter) --------------------
    def open_ventas_report(self):
        if not self._can_inf:
            QMessageBox.information(self, "Permiso", "No tienes permiso para Informes.")
            return

        script = os.path.join(os.getcwd(), "ventas_report.py")
        if not os.path.exists(script):
            QMessageBox.warning(self, "Informes", "ventas_report.py bulunamadı.")
            return

        try:
            self.set_active("informes")
            subprocess.Popen([sys.executable, script])
        except Exception as e:
            QMessageBox.critical(self, "Informes Error", str(e))

    def open_report_manager(self):
        try:
            self.open_page("report_manager")
            self.set_active("informes")
        except Exception as e:
            QMessageBox.critical(self, "Report Manager Error", str(e))

    def open_embedded_report(self, report_key: str, filters: dict):
        try:
            if report_key == "analizar_ventas":
                report_widget = AnalizarVentasScreen()
                report_widget.set_embedded_mode(True)
                report_widget.apply_external_filters(filters or {})

                self.page_report_manager.set_report_widget(report_widget, "Analistas de venta")
                self.stacked.setCurrentWidget(self.page_report_manager)
                self._current_page_key = "report_manager"
                self.set_active("informes")
                return

            if report_key == "ventas_resumen":
                report_widget = VentasResumenScreen()

                self.page_report_manager.set_report_widget(report_widget, "Resumen de ventas")
                self.stacked.setCurrentWidget(self.page_report_manager)
                self._current_page_key = "report_manager"
                self.set_active("informes")
                return

            if report_key == "ventas_con_detalle":
                report_widget = VentasConDetalleWidget()

                filtros = filters or {}
                fecha_desde = filtros.get("fecha_desde")
                fecha_hasta = filtros.get("fecha_hasta")
                sucursal = (filtros.get("sucursal") or "").strip()

                report_widget.load_data(
                    desde=fecha_desde,
                    hasta=fecha_hasta,
                    sucursal_id=None,
                    sucursal_nombre=sucursal
                )

                self.page_report_manager.set_report_widget(report_widget, "Ventas Con Detalle")
                self.stacked.setCurrentWidget(self.page_report_manager)
                self._current_page_key = "report_manager"
                self.set_active("informes")
                return

            if report_key == "informe_produccion":
                report_widget = InformeProduccionScreen()
                report_widget.open_hoja_requested.connect(self.open_hoja_entrada_from_report)

                self.page_report_manager.set_report_widget(report_widget, "Informe de Producción")
                self.stacked.setCurrentWidget(self.page_report_manager)
                self._current_page_key = "report_manager"
                self.set_active("informes")
                return

        except Exception as e:
            QMessageBox.critical(self, "Reporte Error", str(e))

    def open_hoja_entrada_from_report(self, production_no: str):
        try:
            if not hasattr(self, "page_hoja_entrada") or self.page_hoja_entrada is None:
                self.page_hoja_entrada = HojaEntradaScreen()
                self.page_hoja_entrada.production_editor_requested.connect(
                    self.open_production_editor_from_entrada
                )
                self.stacked.addWidget(self.page_hoja_entrada)

            ok = self.page_hoja_entrada.load_from_production(production_no)
            if not ok:
                return

            self.stacked.setCurrentWidget(self.page_hoja_entrada)
            self._current_page_key = "hoja_entrada"
            self.set_active("stock")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo abrir Hoja de Entrada:\n{e}")

    def _fix_initial_layout(self):
        try:
            if self.centralWidget():
                self.centralWidget().updateGeometry()
                if self.centralWidget().layout():
                    self.centralWidget().layout().invalidate()
                    self.centralWidget().layout().activate()

            if hasattr(self, "stacked") and self.stacked:
                current = self.stacked.currentWidget()
                if current:
                    current.setMinimumSize(0, 0)
                    current.resize(self.stacked.size())
                    current.updateGeometry()
                    if current.layout():
                        current.layout().invalidate()
                        current.layout().activate()
                    current.update()

                self.stacked.updateGeometry()
                self.stacked.update()

            self.updateGeometry()
            self.update()

        except Exception as e:
            print(">>> _fix_initial_layout error:", e)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        try:
            QTimer.singleShot(0, self._refresh_visible_page_layout)
            if hasattr(self, "page_stock_container") and self.page_stock_container:
                QTimer.singleShot(0, self.page_stock_container._refresh_current_page_layout)
        except Exception as e:
            print("resizeEvent error:", e)

    def open_pos(self):
        self.close_submenus()
        self.set_active("pos")

        if not self._can_pos:
            QMessageBox.information(self, "Permiso", "No tienes permiso para POS.")
            return

        runner = os.path.join(os.getcwd(), "pos_runner.py")
        if not os.path.exists(runner):
            QMessageBox.warning(
                self,
                "POS",
                "pos_runner.py bulunamadı.\nPOS'u açmak için proje klasörüne pos_runner.py eklemelisin."
            )
            return

        try:
            subprocess.Popen([
                sys.executable,
                runner,
                str(self.user.get("usuario", "")),
                str(self.sucursal_id or "")
            ], cwd=os.getcwd())
        except Exception as e:
            QMessageBox.critical(self, "POS Error", str(e))

    def do_upgrade(self):
        self.close_submenus()
        self.set_active("upgrade")

        try:
            ok = run_upgrade()
            if not ok:
                QMessageBox.information(self, "Upgrade", "VR9_Updater.exe bulunamadı.\nKlasörü açtım.")
        except Exception as e:
            QMessageBox.critical(self, "Upgrade Error", str(e))

    # -------------------- Exit confirm --------------------
    def confirm_exit(self):
        ans = QMessageBox.question(self, "Salir", "¿Estás seguro de que deseas salir?", QMessageBox.Yes | QMessageBox.No)
        if ans == QMessageBox.Yes:
            self.close()

def main():
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("assets/logo/app_icon.ico"))
    win = MainWindow()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()