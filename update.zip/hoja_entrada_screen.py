from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QDateEdit, QSizePolicy, QFrame
)
from PySide6.QtCore import Qt, Signal, QDate

import db


class HojaEntradaScreen(QWidget):
    volver_requested = Signal()
    production_editor_requested = Signal(str)

    def __init__(self, modo="last", production_no=None, entrada_no=None):
        super().__init__()

        self.modo = (modo or "last").strip().lower()
        self.production_no = (production_no or "").strip()
        self.entrada_no = (entrada_no or "").strip()

        self._usuario_actual = ""
        self._saco_actual = ""

        self._build_ui()
        self._load_initial_state()

    # =========================================================
    # UI
    # =========================================================
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 8, 10, 8)
        root.setSpacing(4)

        # ---------------- TOP BAR ----------------
        top_bar = QHBoxLayout()
        top_bar.setSpacing(8)

        self.btn_nuevo = QPushButton("Nuevo")
        self.btn_modificar = QPushButton("Modificar")
        self.btn_eliminar = QPushButton("Eliminar")
        self.btn_guardar = QPushButton("Guardar")
        self.btn_cancelar = QPushButton("Cancelar")
        self.btn_prod_editor = QPushButton("Producción Editor")

        self.btn_prev = QPushButton("⏪")
        self.btn_next = QPushButton("⏩")

        for b in [self.btn_nuevo, self.btn_modificar, self.btn_eliminar, self.btn_guardar, self.btn_cancelar]:
            b.setFixedHeight(30)

        self.btn_prev.setFixedSize(36, 30)
        self.btn_next.setFixedSize(36, 30)
        self.btn_prod_editor.setFixedHeight(30)

        self.btn_nuevo.clicked.connect(self.nuevo)
        self.btn_modificar.clicked.connect(self.modificar)
        self.btn_eliminar.clicked.connect(self.eliminar)
        self.btn_guardar.clicked.connect(self.guardar)
        self.btn_cancelar.clicked.connect(self.cancelar)
        self.btn_prod_editor.clicked.connect(self.abrir_production_editor)
        self.btn_prev.clicked.connect(self.go_prev_hoja)
        self.btn_next.clicked.connect(self.go_next_hoja)

        self.lbl_title = QLabel("Hoja de Entrada")
        self.lbl_title.setAlignment(Qt.AlignCenter)
        self.lbl_title.setStyleSheet("font-size: 18px; font-weight: 700;")

        top_bar.addWidget(self.btn_nuevo)
        top_bar.addWidget(self.btn_modificar)
        top_bar.addWidget(self.btn_eliminar)
        top_bar.addWidget(self.btn_guardar)
        top_bar.addWidget(self.btn_cancelar)

        top_bar.addStretch(1)
        top_bar.addWidget(self.lbl_title)
        top_bar.addStretch(1)

        top_bar.addWidget(self.btn_prev)
        top_bar.addWidget(self.btn_next)
        top_bar.addWidget(self.btn_prod_editor)

        root.addLayout(top_bar)

        # ---------------- CREATE WIDGETS ----------------
        self.fecha = QDateEdit()
        self.fecha.setCalendarPopup(True)
        self.fecha.setDisplayFormat("dd.MM.yyyy")
        self.fecha.setDate(QDate.currentDate())

        self.txt_numero_entrada = QLineEdit()
        self.txt_numero_entrada.setPlaceholderText("Número de entrada")
        self.txt_numero_entrada.setReadOnly(True)

        self.cmb_sucursal_destino = QComboBox()
        self.cmb_tipo_accion = QComboBox()
        self.cmb_tipo_accion.addItems([
            "PRODUCCIÓN",
            "TRANSFERENCIA",
            "BASURA",
            "AJUSTE ENTRADA"
        ])

        self.cmb_sucursal_origen = QComboBox()

        self.txt_barcode = QLineEdit()
        self.txt_barcode.setPlaceholderText("Escanea o escribe el código de barras")

        self.btn_add_barcode = QPushButton("Agregar")
        self.btn_add_barcode.setFixedWidth(62)
        self.btn_add_barcode.setFixedHeight(24)
        self.btn_add_barcode.clicked.connect(self.add_barcode_to_table)
        self.txt_barcode.returnPressed.connect(self.add_barcode_to_table)

        # ---------------- FORM PANEL ----------------
        card = QFrame()
        card.setObjectName("hojaEntradaCard")
        card.setStyleSheet("""
            QFrame#hojaEntradaCard {
                background: #eef3fb;
                border: 1px solid #cfd8e6;
                border-radius: 8px;
            }
        """)

        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(8, 6, 8, 6)
        card_layout.setSpacing(4)

        form = QHBoxLayout()
        form.setSpacing(10)

        left = QVBoxLayout()
        left.setSpacing(2)

        left.addWidget(self._field_box("Fecha", self.fecha))
        left.addWidget(self._field_box("Sucursal Destino", self.cmb_sucursal_destino))

        barcode_row = QHBoxLayout()
        barcode_row.setSpacing(6)
        barcode_row.addWidget(self._field_box("Barcode", self.txt_barcode), 1)
        barcode_row.addWidget(self.btn_add_barcode, 0)
        left.addLayout(barcode_row)

        right = QVBoxLayout()
        right.setSpacing(3)

        right.addWidget(self._field_box("N° Entrada", self.txt_numero_entrada))
        right.addWidget(self._field_box("Acción", self.cmb_tipo_accion))
        right.addWidget(self._field_box("Sucursal Origen", self.cmb_sucursal_origen))

        form.addLayout(left, 1)
        form.addLayout(right, 1)

        card_layout.addLayout(form)
        root.addWidget(card)

        # ---------------- DETAIL TABLE ----------------
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "No",
            "Saco",
            "Barcode",
            "Descripción",
            "Cantidad",
            "Kg",
            "Precio",
            "Total"
        ])
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(True)

        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        header.setSectionResizeMode(1, QHeaderView.Fixed)
        header.setSectionResizeMode(2, QHeaderView.Fixed)
        header.setSectionResizeMode(3, QHeaderView.Stretch)
        header.setSectionResizeMode(4, QHeaderView.Fixed)
        header.setSectionResizeMode(5, QHeaderView.Fixed)
        header.setSectionResizeMode(6, QHeaderView.Fixed)
        header.setSectionResizeMode(7, QHeaderView.Fixed)

        self.table.setColumnWidth(0, 46)
        self.table.setColumnWidth(1, 120)
        self.table.setColumnWidth(2, 150)
        self.table.setColumnWidth(4, 80)
        self.table.setColumnWidth(5, 70)
        self.table.setColumnWidth(6, 105)
        self.table.setColumnWidth(7, 105)

        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setMinimumHeight(360)
        self.table.verticalHeader().setDefaultSectionSize(24)
        self.table.horizontalHeader().setMinimumHeight(26)

        root.addWidget(self.table, 1)

        # ---------------- TOTALS TABLE ----------------
        self.table_totals = QTableWidget()
        self.table_totals.setColumnCount(8)
        self.table_totals.setRowCount(1)
        self.table_totals.verticalHeader().setVisible(False)
        self.table_totals.horizontalHeader().setVisible(False)
        self.table_totals.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table_totals.setSelectionMode(QTableWidget.NoSelection)
        self.table_totals.setFocusPolicy(Qt.NoFocus)
        self.table_totals.setShowGrid(True)
        self.table_totals.setFixedHeight(34)
        self.table_totals.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table_totals.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        for col in range(8):
            self.table_totals.setColumnWidth(col, self.table.columnWidth(col))

        self.table.horizontalHeader().sectionResized.connect(self._sync_totals_widths)

        root.addWidget(self.table_totals, 0)

        # ---------------- FOOTER ----------------
        footer = QHBoxLayout()
        footer.setSpacing(10)

        self.lbl_info_right = QLabel("Usuario: -    Saco: -")
        self.lbl_info_right.setStyleSheet("font-size: 11px; color: #555;")

        footer.addStretch(1)
        footer.addWidget(self.lbl_info_right)

        root.addLayout(footer)

        self.setStyleSheet(self.styleSheet() + """
            QLineEdit, QComboBox, QDateEdit {
                min-height: 24px;
                font-size: 11px;
                padding: 2px 5px;
                border: 1px solid #c9d3e0;
                border-radius: 4px;
                background: white;
            }

            QHeaderView::section {
                background: #e8eef7;
                border: 1px solid #d6deea;
                padding: 6px;
                font-size: 12px;
                font-weight: 600;
            }

            QPushButton {
                min-height: 30px;
                padding: 4px 10px;
                border: 1px solid #c9d3e0;
                border-radius: 6px;
                background: transparent;
                font-size: 12px;
                color: #222;
            }

            QPushButton:hover {
                background: rgba(255,255,255,0.35);
            }

            QTableWidget {
                background: white;
                alternate-background-color: #f7f9fc;
                gridline-color: #dfe5ee;
                font-size: 12px;
            }
        """)

    def _field_box(self, title, widget, label_width=115):
        wrap = QWidget()
        lay = QHBoxLayout(wrap)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)

        lbl = QLabel(title)
        lbl.setFixedWidth(label_width)
        lbl.setStyleSheet("font-size: 12px; font-weight: 600; color: #222;")

        lay.addWidget(lbl)
        lay.addWidget(widget, 1)
        return wrap

    # =========================================================
    # INITIAL LOAD
    # =========================================================
    def _load_initial_state(self):
        self._load_sucursales()

        # Informe’den gelirse
        if self.modo == "edit" and self.production_no:
            self.load_from_production(self.production_no)
            return

        # Normal açılışta son kayıt
        self._force_load_last()

    def _force_load_last(self):
        try:
            last_hoja = db.get_last_hoja_entrada() if hasattr(db, "get_last_hoja_entrada") else None

            if not last_hoja:
                self.lbl_title.setText("Hoja de Entrada")
                self.txt_numero_entrada.clear()
                self.table.setRowCount(0)
                self._update_totals()
                self.set_edit_mode(False)
                return

            self._load_from_hoja_data(last_hoja)
            self.production_no = str(last_hoja.get("production_no", "") or "").strip()
            self.entrada_no = str(last_hoja.get("numero", "") or "").strip()
            self._load_table_from_production(self.production_no)
            self.set_edit_mode(False)

        except Exception as e:
            QMessageBox.critical(self, "Hoja de Entrada", f"No se pudo cargar la última hoja:\n{e}")

    def _load_sucursales(self):
        self.cmb_sucursal_destino.clear()
        self.cmb_sucursal_origen.clear()

        sucursales = self._get_sucursales()

        self.cmb_sucursal_destino.addItem("", None)
        self.cmb_sucursal_origen.addItem("", None)

        for s in sucursales:
            sid = s.get("id")
            nombre = s.get("nombre", "")
            self.cmb_sucursal_destino.addItem(nombre, sid)
            self.cmb_sucursal_origen.addItem(nombre, sid)

    def _get_sucursales(self):
        try:
            db.init_db()
            with db.connect() as con:
                rows = con.execute("""
                    SELECT id, nombre
                    FROM sucursales
                    ORDER BY nombre
                """).fetchall()
                return [dict(r) for r in rows]
        except Exception:
            return []

    # =========================================================
    # MODES
    # =========================================================
    def prepare_new_mode(self):
        self.lbl_title.setText("Hoja de Entrada")
        self.fecha.setDate(QDate.currentDate())

        next_num = ""
        try:
            if hasattr(db, "get_next_hoja_entrada_numero"):
                next_num = db.get_next_hoja_entrada_numero()
        except Exception:
            next_num = ""

        self.txt_numero_entrada.setText(next_num)
        self.production_no = next_num
        self.entrada_no = next_num

        self.cmb_tipo_accion.setCurrentText("PRODUCCIÓN")
        self.cmb_sucursal_destino.setCurrentIndex(0)
        self.cmb_sucursal_origen.setCurrentIndex(0)
        self._usuario_actual = ""
        self._saco_actual = ""
        self.lbl_info_right.setText("Usuario: -    Saco: -")
        self.txt_barcode.clear()
        self.table.setRowCount(0)
        self._update_totals()
        self.set_edit_mode(True)

    def set_edit_mode(self, enabled: bool):
        self.fecha.setEnabled(enabled)
        self.txt_numero_entrada.setReadOnly(True)
        self.cmb_sucursal_destino.setEnabled(enabled)
        self.cmb_tipo_accion.setEnabled(enabled)
        self.cmb_sucursal_origen.setEnabled(enabled)
        self.txt_barcode.setReadOnly(not enabled)
        self.btn_add_barcode.setEnabled(enabled)

    # =========================================================
    # LOADERS
    # =========================================================
    def load_from_production(self, production_no: str):
        self.production_no = (production_no or "").strip()

        hoja = None
        try:
            if hasattr(db, "get_hoja_entrada_by_production_no"):
                hoja = db.get_hoja_entrada_by_production_no(self.production_no)
        except Exception:
            hoja = None

        if not hoja:
            QMessageBox.warning(
                self,
                "Hoja de Entrada",
                "Esta producción ya no tiene una Hoja de Entrada asociada."
            )
            return False

        self._load_from_hoja_data(hoja)

        numero_hoja = str(hoja.get("numero", "") or "").strip()
        self.txt_numero_entrada.setText(numero_hoja)
        self.entrada_no = numero_hoja

        self._load_table_from_production(self.production_no)
        self.set_edit_mode(False)
        return True

    def _load_from_hoja_data(self, data: dict):
        numero = str(data.get("numero", "") or "")
        self.lbl_title.setText(f"Hoja de Entrada · {numero}")
        self.txt_numero_entrada.setText(numero)

        self.production_no = str(data.get("production_no", "") or "").strip()
        self.entrada_no = numero

        fecha_txt = str(data.get("fecha", "") or "").strip()
        if fecha_txt:
            try:
                y, m, d = fecha_txt.split("-")
                self.fecha.setDate(QDate(int(y), int(m), int(d)))
            except Exception:
                pass

        self._set_combo_by_text(self.cmb_sucursal_destino, data.get("sucursal_destino", ""))
        self._set_combo_by_text(self.cmb_sucursal_origen, data.get("sucursal_origen", ""))
        self._set_combo_by_text(self.cmb_tipo_accion, data.get("accion", ""))

        self._usuario_actual = str(data.get("usuario", "") or "")
        self._saco_actual = str(data.get("saco_codigo", "") or "")
        self.lbl_info_right.setText(
            f"Usuario: {self._usuario_actual or '-'}    Saco: {self._saco_actual or '-'}"
        )

    def _set_fecha_from_db(self, created_at):
        txt = str(created_at or "").strip()
        if not txt:
            self.fecha.setDate(QDate.currentDate())
            return

        fecha_part = txt.split(" ")[0].strip()
        try:
            y, m, d = fecha_part.split("-")
            self.fecha.setDate(QDate(int(y), int(m), int(d)))
        except Exception:
            self.fecha.setDate(QDate.currentDate())

    def _set_combo_by_text(self, combo: QComboBox, text: str):
        text = (text or "").strip().upper()
        if not text:
            combo.setCurrentIndex(0)
            return

        for i in range(combo.count()):
            if (combo.itemText(i) or "").strip().upper() == text:
                combo.setCurrentIndex(i)
                return

    def _sync_totals_widths(self, logical_index, old_size, new_size):
        if hasattr(self, "table_totals"):
            self.table_totals.setColumnWidth(logical_index, new_size)

    def _format_money(self, value):
        try:
            return f"{float(value or 0):,.0f}".replace(",", ".")
        except Exception:
            return "0"

    def _get_money_value(self, item):
        if not item:
            return 0.0

        raw = item.data(Qt.UserRole)
        if raw not in (None, ""):
            try:
                return float(raw)
            except Exception:
                pass

        text = (item.text() or "").strip()
        if not text:
            return 0.0

        try:
            return float(text.replace(".", "").replace(",", "."))
        except Exception:
            return 0.0

    def _refresh_totals_row(self, cantidad, total_kg, total_precio):
        if not hasattr(self, "table_totals"):
            return

        self.table_totals.clearContents()
        self.table_totals.setRowCount(1)

        for col in range(8):
            item = QTableWidgetItem("")
            item.setFlags(Qt.ItemIsEnabled)
            self.table_totals.setItem(0, col, item)

        item_cant = QTableWidgetItem(str(cantidad))
        item_cant.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table_totals.setItem(0, 4, item_cant)

        item_kg = QTableWidgetItem(str(round(total_kg, 2)))
        item_kg.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table_totals.setItem(0, 5, item_kg)

        item_total = QTableWidgetItem(self._format_money(total_precio))
        item_total.setData(Qt.UserRole, float(total_precio or 0))
        item_total.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.table_totals.setItem(0, 7, item_total)

    # =========================================================
    # TOTALS
    # =========================================================
    def _update_totals(self):
        cantidad = self.table.rowCount()
        total_kg = 0.0
        total_precio = 0.0

        for row in range(self.table.rowCount()):
            item_total = self.table.item(row, 7)
            item_kg = self.table.item(row, 5)

            try:
                total_precio += self._get_money_value(item_total)
            except Exception:
                pass

            try:
                total_kg += float((item_kg.text() if item_kg else "0").replace(",", "."))
            except Exception:
                pass

        self._refresh_totals_row(cantidad, total_kg, total_precio)

    def _collect_form_data(self):
        numero = self.txt_numero_entrada.text().strip()
        return {
            "numero": numero,
            "fecha": self.fecha.date().toString("yyyy-MM-dd"),
            "sucursal_destino": self.cmb_sucursal_destino.currentText().strip(),
            "sucursal_origen": self.cmb_sucursal_origen.currentText().strip(),
            "accion": self.cmb_tipo_accion.currentText().strip(),
            "usuario": (self._usuario_actual or "").strip(),
            "estado": "",
            "saco_codigo": (self._saco_actual or "").strip(),
            "production_no": numero,
            "nota": "",
        }

    def _load_table_from_production(self, production_no):
        self.table.setRowCount(0)

        if not production_no:
            self._update_totals()
            return

        try:
            rows = db.get_production_labels(production_no) if hasattr(db, "get_production_labels") else []
        except Exception:
            rows = []

        self.table.setRowCount(len(rows))

        for row, r in enumerate(rows):
            barcode = str(r.get("barcode", "") or "")
            descripcion = str(r.get("descripcion", "") or "")
            saco = str(r.get("saco_codigo", "") or "")
            cantidad = 1

            try:
                kg = float(r.get("kg", 0) or 0)
            except Exception:
                kg = 0.0

            try:
                precio = float(r.get("precio", 0) or 0)
            except Exception:
                precio = 0.0

            total = cantidad * precio

            item_no = QTableWidgetItem(str(row + 1))
            item_no.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, 0, item_no)

            self.table.setItem(row, 1, QTableWidgetItem(saco))
            self.table.setItem(row, 2, QTableWidgetItem(barcode))
            self.table.setItem(row, 3, QTableWidgetItem(descripcion))

            item_cant = QTableWidgetItem(str(cantidad))
            item_cant.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, 4, item_cant)

            item_kg = QTableWidgetItem(str(kg))
            item_kg.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, 5, item_kg)

            item_precio = QTableWidgetItem(self._format_money(precio))
            item_precio.setData(Qt.UserRole, float(precio or 0))
            item_precio.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, 6, item_precio)

            item_total = QTableWidgetItem(self._format_money(total))
            item_total.setData(Qt.UserRole, float(total or 0))
            item_total.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row, 7, item_total)

        self._update_totals()

    def add_barcode_to_table(self):
        barcode = self.txt_barcode.text().strip()
        if not barcode:
            self.txt_barcode.setFocus()
            return

        try:
            db.init_db()
            with db.connect() as con:
                row = con.execute("""
                    SELECT
                        barcode,
                        COALESCE(descripcion, '') AS descripcion,
                        COALESCE(precio, 0) AS precio,
                        COALESCE(kg, 0) AS kg
                    FROM labels
                    WHERE barcode = %s
                    LIMIT 1
                """, (barcode,)).fetchone()

            if not row:
                QMessageBox.warning(self, "Barcode", f"No se encontró el código:\n{barcode}")
                self.txt_barcode.selectAll()
                self.txt_barcode.setFocus()
                return

            for r in range(self.table.rowCount()):
                item = self.table.item(r, 2)
                if item and (item.text() or "").strip() == barcode:
                    QMessageBox.information(self, "Barcode", f"Este código ya está en la lista.\n\n{barcode}")
                    self.txt_barcode.clear()
                    self.txt_barcode.setFocus()
                    return

            row_index = self.table.rowCount()
            self.table.insertRow(row_index)

            precio = float(row["precio"] or 0)
            kg = float(row["kg"] or 0)
            cantidad = 1
            total = cantidad * precio
            saco = self._saco_actual or ""

            item_no = QTableWidgetItem(str(row_index + 1))
            item_no.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row_index, 0, item_no)

            self.table.setItem(row_index, 1, QTableWidgetItem(str(saco)))
            self.table.setItem(row_index, 2, QTableWidgetItem(str(row["barcode"])))
            self.table.setItem(row_index, 3, QTableWidgetItem(str(row["descripcion"])))

            item_cant = QTableWidgetItem(str(cantidad))
            item_cant.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row_index, 4, item_cant)

            item_kg = QTableWidgetItem(str(kg))
            item_kg.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row_index, 5, item_kg)

            item_precio = QTableWidgetItem(self._format_money(precio))
            item_precio.setData(Qt.UserRole, float(precio or 0))
            item_precio.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row_index, 6, item_precio)

            item_total = QTableWidgetItem(self._format_money(total))
            item_total.setData(Qt.UserRole, float(total or 0))
            item_total.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.table.setItem(row_index, 7, item_total)

            self._update_totals()
            self.txt_barcode.clear()
            self.txt_barcode.setFocus()

        except Exception as e:
            QMessageBox.critical(self, "Barcode", f"No se pudo agregar el código.\n\n{e}")

    def go_prev_hoja(self):
        numero = self.txt_numero_entrada.text().strip()
        if not numero:
            return

        try:
            with db.connect() as con:
                row = con.execute("""
                    SELECT *
                    FROM hoja_entradas
                    WHERE id < (SELECT id FROM hoja_entradas WHERE numero = %s LIMIT 1)
                    ORDER BY id DESC
                    LIMIT 1
                """, (numero,)).fetchone()

            if row:
                data = dict(row)
                self._load_from_hoja_data(data)
                self.production_no = str(data.get("production_no", "") or "").strip()
                self._load_table_from_production(self.production_no)
                self.set_edit_mode(False)
        except Exception as e:
            print("prev error:", e)

    def go_next_hoja(self):
        numero = self.txt_numero_entrada.text().strip()
        if not numero:
            return

        try:
            with db.connect() as con:
                row = con.execute("""
                    SELECT *
                    FROM hoja_entradas
                    WHERE id > (SELECT id FROM hoja_entradas WHERE numero = %s LIMIT 1)
                    ORDER BY id ASC
                    LIMIT 1
                """, (numero,)).fetchone()

            if row:
                data = dict(row)
                self._load_from_hoja_data(data)
                self.production_no = str(data.get("production_no", "") or "").strip()
                self._load_table_from_production(self.production_no)
                self.set_edit_mode(False)
        except Exception as e:
            print("next error:", e)

    # =========================================================
    # ACTIONS
    # =========================================================
    def nuevo(self):
        self.modo = "new"
        self.prepare_new_mode()
        self.cmb_sucursal_destino.setFocus()

    def modificar(self):
        numero = self.txt_numero_entrada.text().strip()
        if not numero:
            QMessageBox.information(self, "Hoja de Entrada", "No hay registro cargado para modificar.")
            return

        self.set_edit_mode(True)
        QMessageBox.information(self, "Hoja de Entrada", "Modo edición activado.")

    def cancelar(self):
        numero = self.txt_numero_entrada.text().strip()

        if numero and hasattr(db, "get_hoja_entrada"):
            data = db.get_hoja_entrada(numero)
            if data:
                self._load_from_hoja_data(data)
                self.production_no = str(data.get("production_no", "") or "").strip()
                self._load_table_from_production(self.production_no)
                self.set_edit_mode(False)
                return

        self._force_load_last()

    def guardar(self):
        data = self._collect_form_data()

        if not data["numero"]:
            QMessageBox.warning(self, "Hoja de Entrada", "Debes ingresar un Número de Entrada.")
            self.txt_numero_entrada.setFocus()
            return

        try:
            existente = None
            if hasattr(db, "get_hoja_entrada"):
                existente = db.get_hoja_entrada(data["numero"])

            if existente:
                if not hasattr(db, "update_hoja_entrada"):
                    raise RuntimeError("db.update_hoja_entrada no existe.")
                db.update_hoja_entrada(data["numero"], data)
                QMessageBox.information(self, "Hoja de Entrada", f"Hoja actualizada correctamente.\n\nN° Entrada: {data['numero']}")
            else:
                if not hasattr(db, "save_hoja_entrada"):
                    raise RuntimeError("db.save_hoja_entrada no existe.")
                db.save_hoja_entrada(data)
                QMessageBox.information(self, "Hoja de Entrada", f"Hoja guardada correctamente.\n\nN° Entrada: {data['numero']}")

            self.entrada_no = data["numero"]
            self.set_edit_mode(False)

        except Exception as e:
            QMessageBox.critical(self, "Hoja de Entrada", f"No se pudo guardar.\n\n{e}")

    def eliminar(self):
        numero = self.txt_numero_entrada.text().strip()

        if not numero:
            QMessageBox.information(self, "Hoja de Entrada", "No hay Número de Entrada para eliminar.")
            return

        ans = QMessageBox.question(
            self,
            "Eliminar",
            f"¿Eliminar la Hoja de Entrada?\n\nN° Entrada: {numero}"
        )
        if ans != QMessageBox.Yes:
            return

        try:
            if not hasattr(db, "delete_hoja_entrada"):
                raise RuntimeError("db.delete_hoja_entrada no existe.")

            prev_row = None
            next_row = None

            with db.connect() as con:
                current_row = con.execute("""
                    SELECT id
                    FROM hoja_entradas
                    WHERE numero = %s
                    LIMIT 1
                """, (numero,)).fetchone()

                current_id = current_row["id"] if current_row else None

                if current_id is not None:
                    prev_row = con.execute("""
                        SELECT *
                        FROM hoja_entradas
                       WHERE id < %s
                        ORDER BY id DESC
                        LIMIT 1
                    """, (current_id,)).fetchone()

                    next_row = con.execute("""
                        SELECT *
                        FROM hoja_entradas
                        WHERE id > %s
                        ORDER BY id ASC
                        LIMIT 1
                    """, (current_id,)).fetchone()

            # 🔥 artık hoja ile bağlı production da burada silinir
            db.delete_hoja_entrada(numero)

            QMessageBox.information(
                self,
                "Hoja de Entrada",
                f"Hoja eliminada correctamente.\n\nN° Entrada: {numero}"
            )

            target_row = prev_row if prev_row else next_row

            if target_row:
                data = dict(target_row)
                self._load_from_hoja_data(data)
                prod_no = str(data.get("production_no", "") or "").strip()
                self.production_no = prod_no
                self.entrada_no = str(data.get("numero", "") or "").strip()
                self._load_table_from_production(prod_no)
                self.set_edit_mode(False)
            else:
                self._force_load_last()

        except Exception as e:
            QMessageBox.critical(self, "Hoja de Entrada", f"No se pudo eliminar.\n\n{e}")

    def abrir_production_editor(self):
        production_no = self.txt_numero_entrada.text().strip()

        if not production_no:
            QMessageBox.information(self, "Producción Editor", "No hay producción cargada para editar.")
            return

        self.production_editor_requested.emit(production_no)