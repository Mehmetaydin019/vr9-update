# pos_screen_qt.py
from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple

import db
import os
import tempfile
import win32print
import win32ui
from escpos.printer import Win32Raw
from PIL import Image, ImageDraw, ImageFont

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

REGIONES_JSON_PATH = os.path.join(BASE_DIR, "regiones_ciudades.json")
GIROS_TXT_PATH = os.path.join(BASE_DIR, "giros.txt")

def load_regiones_comunas() -> Dict[str, List[str]]:
    try:
        with open(REGIONES_JSON_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def load_giros() -> List[str]:
    try:
        with open(GIROS_TXT_PATH, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except Exception:
        return []

REGIONES_COMUNAS = load_regiones_comunas()
GIROS_LIST = load_giros()

# ---------------- Qt compat ----------------
QT_LIB = None
try:
    from PySide6.QtCore import Qt, QDate
    from PySide6.QtGui import QFont
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
        QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
        QHeaderView, QFrame, QRadioButton, QMessageBox, QDialog,
        QFormLayout, QGroupBox, QSpinBox, QAbstractSpinBox,
        QDateEdit, QComboBox,
    )
    QT_LIB = "pyside6"
    QT6 = True
except Exception:
    from PyQt6.QtCore import Qt, QDate
    from PyQt6.QtGui import QFont
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
        QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
        QHeaderView, QFrame, QRadioButton, QMessageBox, QDialog,
        QFormLayout, QGroupBox, QSpinBox, QAbstractSpinBox,
        QDateEdit, QComboBox,
    )
    QT_LIB = "pyqt6"
    QT6 = True


# ---------------- DB ----------------
def db_connect():
    return db.connect()


def ensure_ventas_espera_table():
    with db_connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS ventas_espera (
                id SERIAL PRIMARY KEY,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                usuario TEXT,
                sucursal TEXT,
                doc TEXT,
                rut TEXT,
                razon TEXT,
                cart_json TEXT NOT NULL
            )
        """)
        con.commit()


def save_venta_en_espera(usuario: str, sucursal: str, doc: str, rut: str, razon: str, cart: list):
    ensure_ventas_espera_table()

    cart_json = json.dumps(cart, ensure_ascii=False)

    with db_connect() as con:
        row = con.execute("""
            INSERT INTO ventas_espera (usuario, sucursal, doc, rut, razon, cart_json)
            VALUES (?, ?, ?, ?, ?, ?)
            RETURNING id
        """, (usuario, sucursal, doc, rut, razon, cart_json)).fetchone()
        con.commit()
        return int(row["id"] if isinstance(row, dict) else row[0])


def fetch_ventas_en_espera(usuario: str = ""):
    ensure_ventas_espera_table()

    with db_connect() as con:
        if usuario:
            rows = con.execute("""
                SELECT id, created_at, usuario, sucursal, doc, rut, razon
                FROM ventas_espera
                WHERE TRIM(UPPER(COALESCE(usuario, ''))) = TRIM(UPPER(?))
                ORDER BY id DESC
            """, (usuario,)).fetchall()
        else:
            rows = con.execute("""
                SELECT id, created_at, usuario, sucursal, doc, rut, razon
                FROM ventas_espera
                ORDER BY id DESC
            """).fetchall()

    return [dict(r) for r in rows]


def get_venta_en_espera(espera_id: int):
    ensure_ventas_espera_table()

    with db_connect() as con:
        row = con.execute("""
            SELECT *
            FROM ventas_espera
            WHERE id = ?
            LIMIT 1
        """, (espera_id,)).fetchone()

    return dict(row) if row else None


def delete_venta_en_espera(espera_id: int):
    ensure_ventas_espera_table()

    with db_connect() as con:
        con.execute("DELETE FROM ventas_espera WHERE id = ?", (espera_id,))
        con.commit()

def ensure_tables():
    return

def money(n: int) -> str:
    try:
        return f"{int(n):,}".replace(",", ".")
    except Exception:
        return str(n)

def safe_int(v, default=0):
    try:
        if isinstance(v, str):
            v = v.strip().replace(".", "").replace(",", "")
        return int(float(v))
    except Exception:
        return default

def safe_float(v, default=0.0):
    try:
        if isinstance(v, str):
            v = v.strip().replace(",", ".")
        return float(v)
    except Exception:
        return default

def parse_pct(v, default=0.0):
    try:
        if isinstance(v, str):
            v = v.strip().replace("%", "").replace(",", ".")
        return float(v)
    except Exception:
        return default

def calc_xfor_discounts(prices: List[int], promo_code: str) -> List[int]:
    """
    prices: aynı gruba ait ürün fiyatları
    return: her index için indirim tutarı
    """
    prices = [int(x or 0) for x in prices]
    indexed = list(enumerate(prices))
    indexed.sort(key=lambda x: x[1])  # ucuzdan pahalıya

    if promo_code == "2x1":
        group_size, pay_count = 2, 1
    elif promo_code == "3x1":
        group_size, pay_count = 3, 1
    elif promo_code == "3x2":
        group_size, pay_count = 3, 2
    elif promo_code == "4x3":
        group_size, pay_count = 4, 3
    else:
        return [0] * len(prices)

    discounts = [0] * len(prices)

    i = 0
    while i + group_size <= len(indexed):
        block = indexed[i:i + group_size]
        free_count = group_size - pay_count

        # en ucuzlar bedava
        for idx_in_block, price in block[:free_count]:
            discounts[idx_in_block] += price

        i += group_size

    return discounts


def calc_second_pct_discounts(prices: List[int], pct: float) -> List[int]:
    """
    Her 2 ürünün 2.'sine pct indirim.
    En ucuz ürüne indirim mantığıyla çalışır.
    """
    prices = [int(x or 0) for x in prices]
    indexed = list(enumerate(prices))
    indexed.sort(key=lambda x: x[1])  # ucuzdan pahalıya

    discounts = [0] * len(prices)

    # her çiftte bir ürüne indirim
    pair_count = len(indexed) // 2
    for i in range(pair_count):
        idx_, price = indexed[i]
        discounts[idx_] += int(round(price * (pct / 100.0)))

    return discounts


def fetch_label_by_barcode(barcode: str) -> Optional[dict]:
    barcode = (barcode or "").strip()
    if not barcode:
        return None

    def _attach_discount_info(base_row: dict) -> dict:
        try:
            with db_connect() as con:
                drow = con.execute("""
                    SELECT
                        desc_pct,
                        desc_val,
                        desc_final_price,
                        desc_active
                    FROM stock_batch_lines
                    WHERE barcode = ?
                """, (barcode,)).fetchone()

            base_price = int(base_row.get("precio", 0) or 0)

            # default değerler
            base_row["precio_original"] = base_price
            base_row["desc_pct"] = 0
            base_row["desc_val"] = 0
            base_row["desc_final_price"] = None
            base_row["desc_active"] = False
            base_row["precio_venta"] = base_price

            if drow:
                d = dict(drow)

                desc_active = bool(d.get("desc_active", False))

                try:
                    desc_final = int(d.get("desc_final_price")) if d.get("desc_final_price") else None
                except Exception:
                    desc_final = None

                base_row["desc_pct"] = float(d.get("desc_pct", 0) or 0)
                base_row["desc_val"] = int(d.get("desc_val", 0) or 0)
                base_row["desc_final_price"] = desc_final
                base_row["desc_active"] = desc_active

                if desc_active and desc_final and desc_final > 0:
                    base_row["precio_venta"] = desc_final
                else:
                    base_row["precio_venta"] = base_price

        except Exception:
            base_price = int(base_row.get("precio", 0) or 0)
            base_row["precio_original"] = base_price
            base_row["desc_pct"] = 0
            base_row["desc_val"] = 0
            base_row["desc_final_price"] = None
            base_row["desc_active"] = False
            base_row["precio_venta"] = base_price

        return base_row

    # labels
    try:
        with db_connect() as con:
            row = con.execute("""
                SELECT barcode, saco_codigo, saco_kg, genero, categoria, producto, talla, precio, descripcion, kg
                FROM labels
                WHERE barcode=?
            """, (barcode,)).fetchone()
            if row:
                return _attach_discount_info(dict(row))
    except Exception as e:
        raise Exception(f"DB_LABELS_ERROR: {e}")

    # items
    try:
        with db_connect() as con:
            row = con.execute("""
                SELECT barcode, producto, descripcion, categoria, genero, saco as saco_codigo, price as precio
                FROM items
                WHERE barcode=?
            """, (barcode,)).fetchone()
            if row:
                d = dict(row)
                d["precio"] = d.get("precio", d.get("price", 0))
                return _attach_discount_info(d)
    except Exception as e:
        raise Exception(f"DB_ITEMS_ERROR: {e}")

    # quick codes
    try:
        row = db.fetch_quick_code(barcode)
        if row:
            d = {
                "barcode": row.get("codigo", ""),
                "producto": row.get("producto_base", ""),
                "descripcion": row.get("descripcion", ""),
                "categoria": row.get("categoria", ""),
                "genero": row.get("genero", "General"),
                "saco_codigo": "",
                "precio": int(row.get("precio", 0) or 0),
                "kg": float(row.get("kg", 0) or 0),
            }
            return _attach_discount_info(d)
    except Exception as e:
        raise Exception(f"DB_QUICKCODE_ERROR: {e}")

    return None

def insert_venta(usuario, sucursal, doc, rut, razon, giro, direccion, comuna, region, total, promo, medio_pago, items):
    with db_connect() as con:
        fecha = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        total_int = int(total)
        promo_int = int(promo)

        mp = str(medio_pago or "").strip().lower()

        efectivo = total_int if mp in ("efectivo", "cash") else 0
        debito = total_int if mp in ("debito", "débito", "tarjeta debito", "tarjeta débito") else 0
        credito = total_int if mp in ("credito", "crédito", "tarjeta credito", "tarjeta crédito") else 0
        transferencia = total_int if mp in ("transferencia", "transfer") else 0

        row = con.execute("""
            INSERT INTO ventas (
                fecha, sucursal, usuario, doc, rut, razon, total, promocion, medio_pago,
                efectivo, debito, credito, transferencia
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            RETURNING id
        """, (
            fecha,
            sucursal,
            usuario,
            doc,
            rut,
            razon,
            total_int,
            promo_int,
            str(medio_pago),
            efectivo,
            debito,
            credito,
            transferencia
        )).fetchone()

        venta_id = row["id"] if isinstance(row, dict) else row[0]

        for it in items:

            con.execute("""
                INSERT INTO venta_items (
                    venta_id, codigo, producto, cantidad, precio, desc_pct, desc_val, valor,
                    sucursal, saco, genero, producto_base, categoria, kg
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                venta_id,
                it.get("codigo", ""),
                it.get("descripcion", ""),
                int(it.get("cant", 1)),
                int(it.get("precio", 0)),
                float(it.get("desc_pct", 0.0)),
                int(it.get("desc_val", 0)),
                int(it.get("valor", 0)),
                sucursal,
                it.get("saco", "") or "",
                it.get("genero", "") or "",
                it.get("producto_base", "") or "",
                it.get("categoria", "") or "",
                float(it.get("kg", 0) or 0),
            ))

        con.commit()
        return venta_id

def fetch_venta_with_items(venta_id):
    con = connect()

    try:
        v = con.execute("""
            SELECT id, fecha, doc, rut, razon, total,
                   promocion AS promo, medio_pago, sucursal, usuario
            FROM ventas
            WHERE id = %s
        """, (int(venta_id),)).fetchone()

        if not v:
            return None, []

        cliente = None
        rut_val = (v["rut"] or "").strip() if "rut" in v.keys() else ""
        if rut_val:
            cliente = con.execute("""
                SELECT giro, direccion, comuna, region
                FROM clientes
                WHERE rut = %s
                LIMIT 1
            """, (rut_val,)).fetchone()

        venta = dict(v)
        venta["giro"] = cliente["giro"] if cliente and "giro" in cliente.keys() and cliente["giro"] else ""
        venta["direccion"] = cliente["direccion"] if cliente and "direccion" in cliente.keys() and cliente["direccion"] else ""
        venta["comuna"] = cliente["comuna"] if cliente and "comuna" in cliente.keys() and cliente["comuna"] else ""
        venta["region"] = cliente["region"] if cliente and "region" in cliente.keys() and cliente["region"] else ""

        rows = con.execute("""
            SELECT codigo, producto AS descripcion, cantidad, precio, valor
            FROM venta_items
            WHERE venta_id = %s
            ORDER BY id ASC
        """, (int(venta_id),)).fetchall()

        items = [dict(r) for r in rows]

        return venta, items

    finally:
        con.close()

# ==================== BOLETA IMAGE RENDER ====================
LOGO_PATH = os.path.join(BASE_DIR, "assets", "lacasaba_logo.png")
FONT_REGULAR = os.path.join(BASE_DIR, "assets", "fonts", "Cambria-Regular.ttf")
FONT_BOLD = os.path.join(BASE_DIR, "assets", "fonts", "Cambria-Bold.ttf")

RECEIPT_IMG_WIDTH = 575
LEFT_MARGIN = 2
RIGHT_MARGIN = 2

DOC_OPER_GAP = 28
ITEMS_BOTTOM_GAP = 30

HEADER_LOGO_W = 480
HEADER_LOGO_H = 220

HEADER_EMPRESA_SIZE = 38
HEADER_RUT_SIZE = 30
HEADER_GIRO_SIZE = 26
HEADER_DIR_SIZE = 26

OPER_SIZE = 28

DOC_TITLE_SIZE = 24
DOC_META_SIZE = 26
DOC_LABEL_SIZE = 26

CLIENT_TITLE_SIZE = 28
CLIENT_TEXT_SIZE = 24

DETALLE_TITLE_SIZE = 30
DETALLE_HEADER_SIZE = 26
ITEM_DESC_SIZE = 26
ITEM_CODE_SIZE = 26
ITEM_TOTAL_SIZE = 26

TOTALS_NORMAL_SIZE = 32
TOTALS_TOTAL_SIZE = 48

FOOTER_SIZE = 26

TXT_EMPRESA = "IMPORTADORA LA CASABA SPA"
TXT_RUT = "RUT: 78.325.343-7"
TXT_GIRO = "VENTA AL POR MENOR PRODUCTOS DE TEXTILES Y CALZADO"
TXT_DIRECCION = "Arturo Prat 414, CURICO"

TXT_DOC_BOLETA = "BOLETA ELECTRONICA"
TXT_DOC_FACTURA = "FACTURA ELECTRONICA"
TXT_FECHA = "Fecha:"
TXT_LABEL_HORA = "Hora:"
TXT_CLIENTE_TITLE = "DATOS DE CLIENTE"
TXT_LABEL_USUARIO = "Usuario"
TXT_LABEL_PAGO = "Metodo de pago"
TXT_LABEL_REF = "Ref."
TXT_DETALLE_TITLE = "DETALLE DE COMPRA"
TXT_TABLA_COL1 = ""
TXT_TABLA_COL2 = "PRODUCTO"
TXT_TABLA_COL3 = "VALOR"
TXT_SUBTOTAL = "Subtotal"
TXT_DESCUENTO = "Descuento"
TXT_PROMOCION = "Promocion"
TXT_IVA = "IVA (19%)"
TXT_TOTAL = "TOTAL"
TXT_FOOTER_1 = "NO SE ACEPTAN CAMBIOS NI DEVOLUCIONES"
TXT_FOOTER_2 = "ART. 14 LEY 19.496"

SHOW_CLIENTE_ONLY_FOR_FACTURA = True
SHOW_PROMOCION = True
SHOW_ITEM_CODE = True


def _fmt_clp(n: int) -> str:
    try:
        return f"{int(n):,}".replace(",", ".")
    except Exception:
        return str(n)

def _safe_int(value, default=0):
    try:
        return int(str(value).strip())
    except Exception:
        return default


def _fmt_fecha_hora(fecha_sql: str):
    try:
        dt = datetime.strptime(str(fecha_sql)[:19], "%Y-%m-%d %H:%M:%S")
        return dt.strftime("%d/%m/%Y"), dt.strftime("%H:%M")
    except Exception:
        return str(fecha_sql)[:10], str(fecha_sql)[11:16]


def get_default_printer():
    return win32print.GetDefaultPrinter()


def _font(path: str, size: int):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _text_width(draw, text, font):
    bbox = draw.textbbox((0, 0), text, font=font)
    return bbox[2] - bbox[0]

def _draw_center(draw, text, y, font, width=RECEIPT_IMG_WIDTH):
    text_w = _text_width(draw, text, font)
    x = (width - text_w) // 2
    draw.text((x, y), text, fill="black", font=font)

def _draw_lr(draw, left_text, right_text, y, font_left, font_right=None, width=RECEIPT_IMG_WIDTH):
    if font_right is None:
        font_right = font_left

    draw.text((LEFT_MARGIN, y), str(left_text), fill="black", font=font_left)

    bbox = draw.textbbox((0, 0), str(right_text), font=font_right)
    text_w = bbox[2] - bbox[0]
    x = width - RIGHT_MARGIN - text_w

    draw.text((x, y), str(right_text), fill="black", font=font_right)

def _center_text(draw, text, y, font, width=RECEIPT_IMG_WIDTH):
    tw = _text_width(draw, text, font)
    x = (width - tw) // 2
    draw.text((x, y), text, fill="black", font=font)


def _lr_text(draw, left, right, y, font_left, font_right=None, width=RECEIPT_IMG_WIDTH):
    if font_right is None:
        font_right = font_left
    draw.text((LEFT_MARGIN, y), left, fill="black", font=font_left)
    rw = _text_width(draw, right, font_right)
    x = width - RIGHT_MARGIN - rw
    draw.text((x, y), right, fill="black", font=font_right)


def _wrap_text(draw, text, font, max_width):
    text = str(text or "").strip()
    if not text:
        return []
    words = text.split()
    lines = []
    current = ""
    for word in words:
        test = word if not current else current + " " + word
        if _text_width(draw, test, font) <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def _draw_separator(draw, y, width=RECEIPT_IMG_WIDTH):
    draw.line((5, y, width - 5, y), fill="black", width=3)


def _tmp_image(width, height):
    return Image.new("L", (width, height), 255)


def _save_temp_image(img):
    fd, path = tempfile.mkstemp(suffix=".png")
    os.close(fd)
    img.save(path)
    return path


def render_header_image():
    width = RECEIPT_IMG_WIDTH
    height = 430

    img = _tmp_image(width, height)
    draw = ImageDraw.Draw(img)

    f_empresa = _font(FONT_BOLD, HEADER_EMPRESA_SIZE)
    f_rut = _font(FONT_BOLD, HEADER_RUT_SIZE)
    f_giro = _font(FONT_REGULAR, HEADER_GIRO_SIZE)
    f_dir = _font(FONT_REGULAR, HEADER_DIR_SIZE)

    y = 8

    if os.path.exists(LOGO_PATH):
        logo = Image.open(LOGO_PATH).convert("RGBA")
        logo = logo.resize((HEADER_LOGO_W, HEADER_LOGO_H))
        img.paste(logo, ((width - HEADER_LOGO_W) // 2, y), logo)
        y += HEADER_LOGO_H + 20

    _draw_center(draw, TXT_EMPRESA, y, f_empresa)
    y += 36

    _draw_center(draw, TXT_RUT, y, f_rut)
    y += 30

    giro_lines = [
        "VENTA AL POR MENOR DE PRODUCTOS TEXTILES,",
        "PRENDAS DE VESTIR Y CALZADO",
        "EN PUESTOS DE VENTA Y MERCADOS"
    ]

    for line in giro_lines:
        _draw_center(draw, line, y, f_giro)
        y += 24

    _draw_center(draw, TXT_DIRECCION, y, f_dir)
    y += 26

    _draw_separator(draw, y)
    y += 0

    return _save_temp_image(img)

def render_doc_oper_image(venta: dict):
    width = RECEIPT_IMG_WIDTH
    height = 135

    img = _tmp_image(width, height)
    draw = ImageDraw.Draw(img)

    f_title = _font(FONT_BOLD, DOC_TITLE_SIZE)
    f_meta = _font(FONT_REGULAR, DOC_META_SIZE)
    f_label = _font(FONT_REGULAR, OPER_SIZE)

    fecha_txt, hora_txt = _fmt_fecha_hora(str(venta.get("fecha", "")))
    doc = str(venta.get("doc", "BOLETA")).upper().strip()
    doc_title = TXT_DOC_FACTURA if doc == "FACTURA" else TXT_DOC_BOLETA
    doc_num = f"N° {int(venta.get('id', 0)):08d}"

    y = 0
    _draw_lr(draw, doc_title, doc_num, y, f_title, f_title)
    y += 28

    _draw_lr(draw, f"Fecha: {fecha_txt}", f"{TXT_LABEL_HORA} {hora_txt}", y, f_meta, f_meta)
    y += 36

    _draw_separator(draw, y)
    y += 10

    usuario_txt = f"{TXT_LABEL_USUARIO}: {str(venta.get('usuario', '') or '').strip()}"
    ref_txt = f"{TXT_LABEL_REF}: {venta.get('id', '')}"
    _draw_lr(draw, usuario_txt, ref_txt, y, f_label, f_label)
    y += DOC_OPER_GAP

    medio_txt = str(venta.get("medio_pago", "") or "")
    if ":" in medio_txt:
        medio_txt = medio_txt.split(":")[0].strip()

    draw.text((LEFT_MARGIN, y), f"{TXT_LABEL_PAGO}: {medio_txt}", fill="black", font=f_label)

    return _save_temp_image(img)

def render_cliente_image(venta: dict):
    doc = str(venta.get("doc", "BOLETA")).upper().strip()
    if SHOW_CLIENTE_ONLY_FOR_FACTURA and doc != "FACTURA":
        return None

    width = RECEIPT_IMG_WIDTH
    height = 215

    img = _tmp_image(width, height)
    draw = ImageDraw.Draw(img)

    f_title = _font(FONT_BOLD, CLIENT_TITLE_SIZE)
    f_text = _font(FONT_REGULAR, CLIENT_TEXT_SIZE)

    rut_cliente = str(venta.get("rut", "") or "").strip()
    razon_cliente = str(venta.get("razon", "") or "").strip()
    giro_cliente = str(venta.get("giro", "") or "").strip()
    dir_cliente = str(venta.get("direccion", "") or "").strip()
    comuna_cliente = str(venta.get("comuna", "") or "").strip()
    region_cliente = str(venta.get("region", "") or "").strip()

    y = 1
    _draw_separator(draw, y)
    y += 10

    draw.text((LEFT_MARGIN, y), TXT_CLIENTE_TITLE, fill="black", font=f_title)
    y += 32

    draw.text((LEFT_MARGIN, y), f"R.U.T.: {rut_cliente}", fill="black", font=f_text)
    y += 28

    draw.text((LEFT_MARGIN, y), f"Razón Social: {razon_cliente}", fill="black", font=f_text)
    y += 28

    giro_full = f"Giro: {giro_cliente}".strip()

    max_width = RECEIPT_IMG_WIDTH - LEFT_MARGIN - RIGHT_MARGIN
    words = giro_full.split()
    lines = []
    current = ""

    for word in words:
        test = word if not current else current + " " + word
        bbox = draw.textbbox((0, 0), test, font=f_text)
        text_w = bbox[2] - bbox[0]
        if text_w <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word

    if current:
        lines.append(current)

    for line in lines:
        draw.text((LEFT_MARGIN, y), line, fill="black", font=f_text)
        y += 28

    draw.text((LEFT_MARGIN, y), f"Dirección: {dir_cliente}", fill="black", font=f_text)
    y += 28

    draw.text((LEFT_MARGIN, y), f"Comuna: {comuna_cliente}    Región: {region_cliente}", fill="black", font=f_text)
    y += 10

    return _save_temp_image(img)

def render_items_image(items: list):
    width = RECEIPT_IMG_WIDTH

    row_h = 30
    code_h = 24
    top_h = 78
    bottom_h = 18

    height = top_h + bottom_h + sum(
        row_h + (code_h if SHOW_ITEM_CODE and str(it.get("codigo", "") or "").strip() else 0) + 16
        for it in items
    )

    img = _tmp_image(width, height)
    draw = ImageDraw.Draw(img)

    f_title = _font(FONT_BOLD, DETALLE_TITLE_SIZE)
    f_head = _font(FONT_BOLD, DETALLE_HEADER_SIZE)
    f_desc = _font(FONT_REGULAR, ITEM_DESC_SIZE)
    f_code = _font(FONT_REGULAR, ITEM_CODE_SIZE)
    f_qty = _font(FONT_REGULAR, ITEM_TOTAL_SIZE)
    f_total = _font(FONT_REGULAR, ITEM_TOTAL_SIZE)

    y = 0
    _draw_separator(draw, y)
    y += 12

    _draw_center(draw, TXT_DETALLE_TITLE, y, f_title)
    y += 40

    # Header: CNT | PRODUCTO | VALOR
    cnt_x = LEFT_MARGIN
    prod_x = LEFT_MARGIN + 30

    draw.text((cnt_x, y), TXT_TABLA_COL1, fill="black", font=f_head)
    draw.text((prod_x, y), TXT_TABLA_COL2, fill="black", font=f_head)

    valor_header_w = _text_width(draw, TXT_TABLA_COL3, f_head)
    valor_x = width - RIGHT_MARGIN - valor_header_w
    draw.text((valor_x, y), TXT_TABLA_COL3, fill="black", font=f_head)

    y += 36
    _draw_separator(draw, y)
    y += 12

    for it in items:
        codigo = str(it.get("codigo", "") or "").strip()
        desc = str(it.get("descripcion", "") or "").strip()
        cant = f"{_safe_int(it.get('cantidad', 1) or 1)}x "
        valor = _fmt_clp(_safe_int(it.get("valor", 0) or 0))

        # cantidad solda
        draw.text((cnt_x, y), cant, fill="black", font=f_qty)

        # ürün açıklaması daha geniş alan
        draw.text((prod_x, y), desc[:30], fill="black", font=f_desc)

        # valor sağda
        valor_w = _text_width(draw, valor, f_total)
        draw.text((width - RIGHT_MARGIN - valor_w, y), valor, fill="black", font=f_total)

        y += row_h

        if SHOW_ITEM_CODE and codigo:
            draw.text((prod_x, y), codigo, fill="black", font=f_code)
            y += 40

    y += ITEMS_BOTTOM_GAP
    _draw_separator(draw, y)

    return _save_temp_image(img)

def render_totals_image(subtotal, descuento, promo, neto, iva, total):
    width = RECEIPT_IMG_WIDTH
    height = 300
    img = _tmp_image(width, height)
    draw = ImageDraw.Draw(img)
    f_normal = _font(FONT_BOLD, TOTALS_NORMAL_SIZE)
    f_total = _font(FONT_BOLD, TOTALS_TOTAL_SIZE)

    y = 0
    _draw_separator(draw, y)
    y += 10

    for label, value in [
        (TXT_SUBTOTAL, subtotal),
        (TXT_DESCUENTO, descuento),
        (TXT_PROMOCION, promo),
        ("Neto", neto),
        (TXT_IVA, iva),
    ]:
        if label == TXT_PROMOCION and not SHOW_PROMOCION:
            continue
        _lr_text(draw, label, value, y, f_normal, f_normal)
        y += 38

    _draw_separator(draw, y)
    y += 22
    _lr_text(draw, TXT_TOTAL, total, y, f_total, f_total)
    return _save_temp_image(img)

def render_footer_image():
    width = RECEIPT_IMG_WIDTH
    height = 170
    img = _tmp_image(width, height)
    draw = ImageDraw.Draw(img)
    f_main = _font(FONT_BOLD, FOOTER_SIZE)
    y = 12
    _draw_separator(draw, y)
    y += 10
    for text, font, step in [
        (TXT_FOOTER_1, f_main, 30),
        (TXT_FOOTER_2, f_main, 30),
    ]:
        _center_text(draw, text, y, font, width)
        y += 36

    _draw_separator(draw, y)
    y += 10

    return _save_temp_image(img)


def print_boleta(venta: dict, items: list):
    printer_name = get_default_printer()
    p = Win32Raw(printer_name)

    subtotal = 0
    total_lineas = 0
    for it in items:
        cant = int(it.get("cantidad", 1) or 1)
        precio = int(it.get("precio", 0) or 0)
        valor = int(it.get("valor", 0) or 0)
        subtotal += cant * precio if precio > 0 else valor
        total_lineas += valor

    promo = int(venta.get("promo", 0) or 0)
    promo = max(0, min(total_lineas, promo))
    total_final = max(0, total_lineas - promo)
    descuento_total = max(0, subtotal - total_lineas)
    iva = int(round(total_final * 19 / 119)) if total_final > 0 else 0
    neto = max(0, total_final - iva)

    temp_files = []
    try:
        builders = [
            lambda: render_header_image(),
            lambda: render_doc_oper_image(venta),
            lambda: render_cliente_image(venta),
            lambda: render_items_image(items),
            lambda: render_totals_image(
                _fmt_clp(subtotal),
                _fmt_clp(descuento_total),
                _fmt_clp(promo),
                _fmt_clp(neto),
                _fmt_clp(iva),
                _fmt_clp(total_final),
            ),
            lambda: render_footer_image(),
        ]
        for builder in builders:
            path = builder()
            if path:
                temp_files.append(path)
                try:
                    p.set(align="center")
                except Exception:
                    pass
                p.image(path)
                p.text("\n")
        p.cut()
    finally:
        try:
            p.close()
        except Exception:
            pass
        for path in temp_files:
            try:
                if path and os.path.exists(path):
                    os.remove(path)
            except Exception:
                pass

# ======== CIERRE / DETALLE VENTAS (password) ========
CIERRE_PASSWORD = "1905"   # <-- buradan değiştir (istersen)

def parse_medio_pago_txt(txt: str) -> dict:
    """
    medio_pago örnekleri:
      "Efectivo:2.499"
      "Efectivo:2.499 + Debito:10.000 + Credito:5.000"
    """
    out = {"Efectivo": 0, "Debito": 0, "Credito": 0, "Transfer": 0}
    if not txt:
        return out
    parts = [p.strip() for p in str(txt).split("+")]
    for p in parts:
        if ":" not in p:
            continue
        k, v = [x.strip() for x in p.split(":", 1)]
        k = k.replace("Débito", "Debito").replace("Crédito", "Credito")
        if k in out:
            out[k] += safe_int(v, 0)
    return out


def fetch_cierre_usuario(usuario: str, fecha_yyyy_mm_dd: str) -> dict:
    """
    Sadece seçili usuario + gün için özet döndürür.
    """
    resumen = {
        "Efectivo": 0,
        "Debito": 0,
        "Credito": 0,
        "Transfer": 0,
        "Promo": 0,
        "TotalVentas": 0,
        "TotalCobrado": 0,
    }

    with db_connect() as con:
        rows = con.execute("""
            SELECT total, promocion AS promo, medio_pago
            FROM ventas
            WHERE DATE(fecha) = ?
              AND TRIM(UPPER(COALESCE(usuario, ''))) = TRIM(UPPER(?))
        """, (fecha_yyyy_mm_dd, usuario)).fetchall()

    for r in rows:
        total = safe_int(r["total"], 0)
        promo = safe_int(r["promo"], 0)
        medio = r["medio_pago"] or ""

        resumen["TotalVentas"] += total
        resumen["Promo"] += promo

        mp = parse_medio_pago_txt(medio)
        for k in ("Efectivo", "Debito", "Credito", "Transfer"):
            resumen[k] += mp.get(k, 0)

    resumen["TotalCobrado"] = (
        resumen["Efectivo"] +
        resumen["Debito"] +
        resumen["Credito"] +
        resumen["Transfer"]
    )
    return resumen

# ---------------- Payment Dialog ----------------
@dataclass
class PaymentLine:
    medio: str
    monto: int

class PagoDialog(QDialog):
    def __init__(self, parent, sucursal: str, total: int, doc: str, rut: str, razon: str, usuario: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Pago")
        self.setFixedSize(720, 720)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowMaximizeButtonHint)

        self.sucursal = (sucursal or "").strip()
        self.usuario = (usuario or "").strip()
        self.total = int(total)
        self.doc = doc
        self.rut = rut
        self.razon = razon

        self.result_payments: List[PaymentLine] = []
        self.result_promo: int = 0
        self.result_medio_txt: str = ""

        root = QVBoxLayout(self)
        root.setSpacing(10)

        title = QLabel("Opciones de Pago")
        title.setFont(QFont("Segoe UI", 16, 700))
        root.addWidget(title)

        info = QLabel(f"Sucursal: {self.sucursal}   |   Documento: {doc}")
        info.setStyleSheet("color:#475569; font-weight:700;")
        root.addWidget(info)

        resumen = QFrame()
        resumen.setObjectName("ResumenCard")
        rlay = QGridLayout(resumen)
        rlay.setHorizontalSpacing(16)
        rlay.setVerticalSpacing(8)

        self.lbl_total = QLabel(f"TOTAL: {money(self.total)} CLP")
        self.lbl_total.setObjectName("BigNumber")
        self.lbl_pagado = QLabel("PAGADO: 0 CLP")
        self.lbl_pagado.setObjectName("BigNumber")
        self.lbl_restante = QLabel(f"RESTANTE: {money(self.total)} CLP")
        self.lbl_restante.setObjectName("BigNumber")
        self.lbl_vuelto = QLabel("VUELTO: 0 CLP")
        self.lbl_vuelto.setObjectName("BigNumber")

        rlay.addWidget(self.lbl_total, 0, 0, 1, 2)
        rlay.addWidget(self.lbl_pagado, 1, 0)
        rlay.addWidget(self.lbl_restante, 1, 1)
        rlay.addWidget(self.lbl_vuelto, 2, 0, 1, 2)
        root.addWidget(resumen)

        promo_box = QGroupBox("Promoción / Gift Card")
        promo_form = QFormLayout(promo_box)
        self.sp_promo = QSpinBox()
        self.sp_promo.setRange(0, 10_000_000)
        self.sp_promo.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
        self.sp_promo.setFixedWidth(220)
        self.sp_promo.valueChanged.connect(self._recalc)
        promo_form.addRow("Promo (CLP)", self.sp_promo)
        root.addWidget(promo_box)

        box = QGroupBox("Pagos (puedes combinar: Efectivo + Débito)")
        grid = QGridLayout(box)
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)

        def mk_spin():
            sp = QSpinBox()
            sp.setRange(0, 10_000_000)
            sp.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
            sp.setFixedWidth(240)
            sp.valueChanged.connect(self._recalc)
            return sp

        self.sp_efectivo = mk_spin()
        self.sp_debito = mk_spin()
        self.sp_credito = mk_spin()
        self.sp_transfer = mk_spin()

        self.btn_auto_ef = QPushButton("Auto")
        self.btn_auto_deb = QPushButton("Auto")
        self.btn_auto_cred = QPushButton("Auto")
        self.btn_auto_tr = QPushButton("Auto")
        for b in (self.btn_auto_ef, self.btn_auto_deb, self.btn_auto_cred, self.btn_auto_tr):
            b.setFixedWidth(90)

        self.btn_auto_ef.clicked.connect(lambda: self._auto_fill("Efectivo"))
        self.btn_auto_deb.clicked.connect(lambda: self._auto_fill("Debito"))
        self.btn_auto_cred.clicked.connect(lambda: self._auto_fill("Credito"))
        self.btn_auto_tr.clicked.connect(lambda: self._auto_fill("Transfer"))

        def row(r, label, sp, btn):
            lab = QLabel(label)
            lab.setStyleSheet("font-weight:900; color:#0f172a;")
            grid.addWidget(lab, r, 0)
            grid.addWidget(sp, r, 1)
            grid.addWidget(btn, r, 2)

        row(0, "Efectivo (CLP)", self.sp_efectivo, self.btn_auto_ef)
        row(1, "Débito (CLP)", self.sp_debito, self.btn_auto_deb)
        row(2, "Crédito (CLP)", self.sp_credito, self.btn_auto_cred)
        row(3, "Transfer (CLP)", self.sp_transfer, self.btn_auto_tr)

        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 0)
        grid.setColumnStretch(2, 0)

        root.addWidget(box)

        btns = QHBoxLayout()
        btns.addStretch(1)
        self.btn_cancel = QPushButton("Cancelar")
        self.btn_emit = QPushButton("EMITIR")
        self.btn_emit.setObjectName("PrimaryGreen")
        self.btn_cancel.clicked.connect(self.reject)
        self.btn_emit.clicked.connect(self._emit)
        btns.addWidget(self.btn_cancel)
        btns.addWidget(self.btn_emit)
        root.addLayout(btns)

        self._apply_style()
        self._auto_fill("Efectivo")
        self._recalc()

    def _apply_style(self):
        self.setStyleSheet("""
            QDialog { background:#f8fafc; }
            QLabel { color:#0f172a; }
            QGroupBox {
                border:1px solid #e2e8f0;
                border-radius:18px;
                margin-top:10px;
                font-weight:900;
                padding:10px;
                background:#ffffff;
            }
            QGroupBox::title { subcontrol-origin: margin; left: 10px; padding:0 6px; }
            QSpinBox {
                min-height:40px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                padding:6px 12px;
                background:#ffffff;
                font-size:18px;
                font-weight:900;
            }
            QFrame#ResumenCard{
                background:#ffffff;
                border:1px solid #e2e8f0;
                border-radius:16px;
                padding:10px;
            }
            QLabel#BigNumber{
                font-size:18px;
                font-weight:900;
            }
            QPushButton{
                min-height:36px;
                padding:8px 12px;
                border-radius:12px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:900;
            }
            QPushButton#PrimaryGreen{
                background:#16a34a;
                border:1px solid #16a34a;
                color:white;
            }
        """)

    def _total_a_pagar(self) -> int:
        promo = int(self.sp_promo.value())
        promo = max(0, min(self.total, promo))
        return max(0, self.total - promo)

    def _paid_sum(self) -> int:
        return (
            int(self.sp_efectivo.value())
            + int(self.sp_debito.value())
            + int(self.sp_credito.value())
            + int(self.sp_transfer.value())
        )

    def _auto_fill(self, medio: str):
        total_a_pagar = self._total_a_pagar()
        for sp in (self.sp_efectivo, self.sp_debito, self.sp_credito, self.sp_transfer):
            sp.blockSignals(True)
        try:
            self.sp_efectivo.setValue(0)
            self.sp_debito.setValue(0)
            self.sp_credito.setValue(0)
            self.sp_transfer.setValue(0)
            if medio == "Efectivo":
                self.sp_efectivo.setValue(total_a_pagar)
            elif medio == "Debito":
                self.sp_debito.setValue(total_a_pagar)
            elif medio == "Credito":
                self.sp_credito.setValue(total_a_pagar)
            elif medio == "Transfer":
                self.sp_transfer.setValue(total_a_pagar)
        finally:
            for sp in (self.sp_efectivo, self.sp_debito, self.sp_credito, self.sp_transfer):
                sp.blockSignals(False)
        self._recalc()

    def _recalc(self):
        promo = int(self.sp_promo.value())
        promo = max(0, min(self.total, promo))
        pago = self._paid_sum()
        total_a_pagar = max(0, self.total - promo)

        restante = total_a_pagar - pago
        vuelto = 0
        if restante < 0:
            vuelto = -restante
            restante = 0

        self.lbl_total.setText(f"TOTAL: {money(self.total)} CLP")
        self.lbl_pagado.setText(f"PAGADO: {money(pago)} CLP")
        self.lbl_restante.setText(f"RESTANTE: {money(restante)} CLP")
        self.lbl_vuelto.setText(f"VUELTO: {money(vuelto)} CLP")

    def _emit(self):
        promo = int(self.sp_promo.value())
        promo = max(0, min(self.total, promo))

        if self.doc == "FACTURA":
            if not (self.rut or "").strip() or not (self.razon or "").strip():
                QMessageBox.warning(self, "Factura", "Factura için RUT ve Razón Social gerekli.")
                return

        pago_lines: List[PaymentLine] = []
        if self.sp_efectivo.value() > 0:
            pago_lines.append(PaymentLine("Efectivo", int(self.sp_efectivo.value())))
        if self.sp_debito.value() > 0:
            pago_lines.append(PaymentLine("Debito", int(self.sp_debito.value())))
        if self.sp_credito.value() > 0:
            pago_lines.append(PaymentLine("Credito", int(self.sp_credito.value())))
        if self.sp_transfer.value() > 0:
            pago_lines.append(PaymentLine("Transfer", int(self.sp_transfer.value())))

        if not pago_lines:
            QMessageBox.warning(self, "Pago", "En az 1 ödeme tutarı gir.")
            return

        total_a_pagar = max(0, self.total - promo)
        pagado = sum(p.monto for p in pago_lines)
        if pagado < total_a_pagar:
            QMessageBox.warning(self, "Pago", f"Ödeme eksik. Restante: {money(total_a_pagar - pagado)} CLP")
            return

        self.result_payments = pago_lines
        self.result_promo = promo
        self.result_medio_txt = " + ".join([f"{p.medio}:{money(p.monto)}" for p in pago_lines])
        self.accept()

class PasswordDialog(QDialog):
    def __init__(self, parent=None, title="Acceso"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFixedSize(360, 170)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowMaximizeButtonHint)

        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        lbl = QLabel("Ingrese contraseña:")
        lbl.setStyleSheet("font-weight:900;")
        lay.addWidget(lbl)

        self.ed = QLineEdit()
        self.ed.setEchoMode(QLineEdit.EchoMode.Password)
        self.ed.setFixedHeight(36)
        lay.addWidget(self.ed)

        btns = QHBoxLayout()
        btns.addStretch(1)
        b_cancel = QPushButton("Cancelar")
        b_ok = QPushButton("OK")
        b_ok.setObjectName("Primary")
        b_cancel.clicked.connect(self.reject)
        b_ok.clicked.connect(self.accept)
        btns.addWidget(b_cancel)
        btns.addWidget(b_ok)
        lay.addLayout(btns)

        self.setStyleSheet("""
            QDialog { background:#f8fafc; }
            QLineEdit {
                border-radius:12px; border:1px solid #cbd5e1;
                padding:8px 10px; background:#fff; font-weight:800;
            }
            QPushButton{
                min-height:34px; padding:8px 12px; border-radius:12px;
                border:1px solid #cbd5e1; background:#ffffff; font-weight:900;
            }
            QPushButton#Primary{ background:#2563eb; border:1px solid #2563eb; color:white; }
        """)

    def password(self) -> str:
        return (self.ed.text() or "").strip()


class DetalleVentasDialog(QDialog):
    def __init__(self, parent, usuario: str):
        super().__init__(parent)
        self.setWindowTitle("Detalle Ventas (Usuario)")
        self.setFixedSize(520, 420)
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowMaximizeButtonHint)

        today = QDate.currentDate().toString("yyyy-MM-dd")
        data = fetch_cierre_usuario(usuario, today)

        tarjeta_total = data["Debito"] + data["Credito"]

        root = QVBoxLayout(self)
        root.setSpacing(10)

        t = QLabel(f"Detalle Ventas - {usuario}")
        t.setFont(QFont("Segoe UI", 14, 900))
        root.addWidget(t)

        sub = QLabel(f"Fecha: {today}")
        sub.setStyleSheet("color:#475569; font-weight:800;")
        root.addWidget(sub)

        card = QFrame()
        card.setObjectName("Card")
        g = QGridLayout(card)
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(10)

        def row(r, label, val, bold=False):
            l = QLabel(label)
            v = QLabel(money(val))
            if bold:
                l.setStyleSheet("font-weight:900; font-size:14px;")
                v.setStyleSheet("font-weight:900; font-size:14px;")
            else:
                l.setStyleSheet("font-weight:800;")
                v.setStyleSheet("font-weight:900;")
            g.addWidget(l, r, 0)
            g.addWidget(v, r, 1, alignment=Qt.AlignmentFlag.AlignRight)

        row(0, "Efectivo", data["Efectivo"])
        row(1, "Débito", data["Debito"])
        row(2, "Crédito", data["Credito"])
        row(3, "Tarjeta Total (Débito + Crédito)", tarjeta_total, bold=True)
        row(4, "Transfer", data["Transfer"])
        row(5, "Promoción (GiftCard)", data["Promo"])
        g.addWidget(QFrame(), 6, 0, 1, 2)  # spacer

        row(7, "TOTAL COBRADO", data["TotalCobrado"], bold=True)

        root.addWidget(card)

        foot = QLabel(f"Total Ventas (sin promo): {money(data['TotalVentas'])}   |   Promo: {money(data['Promo'])}")
        foot.setStyleSheet("color:#0f172a; font-weight:800;")
        root.addWidget(foot)

        b = QHBoxLayout()
        b.addStretch(1)
        btn_close = QPushButton("Cerrar")
        btn_close.clicked.connect(self.close)
        b.addWidget(btn_close)
        root.addLayout(b)

        self.setStyleSheet("""
            QDialog { background:#f8fafc; }
            QFrame#Card {
                background:#ffffff; border:1px solid #e2e8f0;
                border-radius:16px; padding:10px;
            }
            QLabel { color:#0f172a; }
            QPushButton{
                min-height:34px; padding:8px 12px; border-radius:12px;
                border:1px solid #cbd5e1; background:#ffffff; font-weight:900;
            }
        """)

class NuevoClienteDialog(QDialog):

    def __init__(self, parent=None, rut=""):
        super().__init__(parent)

        self.setWindowTitle("Nuevo Cliente")
        self.setFixedSize(400,350)

        layout = QFormLayout(self)

        self.ed_rut = QLineEdit(rut)
        self.ed_razon = QLineEdit()
        self.cb_giro = QComboBox()
        self.ed_direccion = QLineEdit()
        self.cb_region = QComboBox()
        self.cb_comuna = QComboBox()


        self.cb_region.currentIndexChanged.connect(self._update_comunas)

        layout.addRow("RUT", self.ed_rut)
        layout.addRow("Razón Social", self.ed_razon)
        layout.addRow("Giro", self.cb_giro)
        layout.addRow("Dirección", self.ed_direccion)
        layout.addRow("Región", self.cb_region)
        layout.addRow("Comuna", self.cb_comuna)

        btn = QPushButton("Guardar")
        btn.clicked.connect(self._save)

        layout.addRow(btn)

        self.cb_giro.addItems(GIROS_LIST)
        self.cb_region.addItems(sorted(REGIONES_COMUNAS.keys()))
        self._update_comunas()

        self.result_data = None

    def _update_comunas(self):
        region = self.cb_region.currentText().strip()
        self.cb_comuna.clear()

        comunas = REGIONES_COMUNAS.get(region, [])
        if comunas:
            self.cb_comuna.addItems(comunas)

    def _save(self):

        rut = self.ed_rut.text().strip()
        razon = self.ed_razon.text().strip()

        if not rut or not razon:
            QMessageBox.warning(self,"Cliente","RUT y Razón Social obligatorios")
            return

        self.result_data = dict(
            rut=rut,
            razon_social=razon,
            giro=self.cb_giro.currentText(),
            direccion=self.ed_direccion.text(),
            region=self.cb_region.currentText(),
            comuna=self.cb_comuna.currentText()
        )

        self.accept()

# ---------------- Historial Dialog ----------------
class HistorialDialog(QDialog):
    def __init__(self, parent, default_usuario: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Historial Ventas")
        self.resize(920, 560)

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        f = QHBoxLayout()
        f.setSpacing(10)

        f.addWidget(QLabel("Fecha:"))
        self.dt_fecha = QDateEdit()
        self.dt_fecha.setCalendarPopup(True)
        self.dt_fecha.setDisplayFormat("dd.MM.yyyy")
        self.dt_fecha.setDate(QDate.currentDate())
        self.dt_fecha.setFixedWidth(140)
        f.addWidget(self.dt_fecha)

        f.addWidget(QLabel("usuario:"))
        self.cb_usuario = QComboBox()
        self.cb_usuario.setFixedWidth(200)
        f.addWidget(self.cb_usuario)

        self.btn_buscar = QPushButton("Buscar")
        self.btn_buscar.setObjectName("Primary")
        f.addWidget(self.btn_buscar)

        f.addStretch(1)
        layout.addLayout(f)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["ID", "Fecha", "Usuario", "Doc", "Total", "Pago"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)

        hh = self.table.horizontalHeader()
        if QT6:
            hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
            hh.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table, 1)

        btn_layout = QHBoxLayout()
        self.btn_print = QPushButton("Reimprimir")
        self.btn_close = QPushButton("Cerrar")
        btn_layout.addWidget(self.btn_print)
        btn_layout.addStretch(1)
        btn_layout.addWidget(self.btn_close)
        layout.addLayout(btn_layout)

        self.btn_close.clicked.connect(self.close)
        self.btn_buscar.clicked.connect(self._reload)
        self.btn_print.clicked.connect(self._reprint_selected)

        self._apply_style()
        self._load_usuarios(default_usuario=default_usuario)
        self._reload()

    def _apply_style(self):
        self.setStyleSheet("""
            QDialog { background:#f8fafc; }
            QLabel { color:#0f172a; font-weight:800; }
            QDateEdit, QComboBox {
                min-height:32px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                padding:6px 10px;
                background:#ffffff;
                font-weight:700;
            }
            QTableWidget {
                border:1px solid #e2e8f0;
                border-radius:12px;
                background:#ffffff;
                font-size:14px;
                font-weight:700;
            }
            QHeaderView::section {
                background:#f8fafc;
                padding:8px;
                font-weight:900;
                border:0px;
                border-bottom:1px solid #e2e8f0;
            }
            QPushButton{
                min-height:34px;
                padding:8px 12px;
                border-radius:12px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:900;
            }
            QPushButton#Primary{
                background:#2563eb;
                border:1px solid #2563eb;
                color:white;
            }
        """)

    def _load_usuarios(self, default_usuario: str = ""):
        usuarios = []
        try:
            with db_connect() as con:
                rows = con.execute("""
                    SELECT DISTINCT usuario
                    FROM ventas
                    WHERE usuario IS NOT NULL AND trim(usuario) <> ''
                    ORDER BY usuario
                """).fetchall()

            usuarios = [str(r["usuario"]) for r in rows]
        except Exception:
            usuarios = []

        self.cb_usuario.clear()
        self.cb_usuario.addItem("TODOS")
        for u in usuarios:
            self.cb_usuario.addItem(u)

        if default_usuario:
            idx = self.cb_usuario.findText(default_usuario)
            if idx >= 0:
                self.cb_usuario.setCurrentIndex(idx)

    def _reload(self):
        fecha = self.dt_fecha.date().toString("yyyy-MM-dd")
        usuario = self.cb_usuario.currentText().strip()

        q = """
            SELECT id, fecha, usuario, doc, total, medio_pago
            FROM ventas
            WHERE DATE(fecha) = ?
        """
        params = [fecha]

        if usuario and usuario != "TODOS":
            q += " AND TRIM(UPPER(COALESCE(usuario, ''))) = TRIM(UPPER(?))"
            params.append(usuario)

        q += " ORDER BY id DESC LIMIT 500"

        try:
            with db_connect() as con:
                rows = con.execute(q, params).fetchall()
        except Exception as e:
            QMessageBox.critical(self, "DB", f"Historial yüklenemedi:\n{e}")
            return

        self.table.setRowCount(0)
        for r, row in enumerate(rows):
            self.table.insertRow(r)
            self.table.setItem(r, 0, QTableWidgetItem(str(row["id"])))
            self.table.setItem(r, 1, QTableWidgetItem(str(row["fecha"])))
            self.table.setItem(r, 2, QTableWidgetItem(str(row["usuario"])))
            self.table.setItem(r, 3, QTableWidgetItem(str(row["doc"])))
            self.table.setItem(r, 4, QTableWidgetItem(money(row["total"])))
            self.table.setItem(r, 5, QTableWidgetItem(str(row["medio_pago"] or "")))

        for r in range(self.table.rowCount()):
            for c in (0, 4):
                it = self.table.item(r, c)
                if it:
                    it.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)

    def _reprint_selected(self):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Historial", "Lütfen bir satış seç.")
            return
        venta_id = safe_int(self.table.item(row, 0).text(), 0)
        if venta_id <= 0:
            QMessageBox.warning(self, "Historial", "Venta ID okunamadı.")
            return

        parent = self.parent()
        if parent and hasattr(parent, "reimprimir_venta"):
            parent.reimprimir_venta(venta_id)
        else:
            QMessageBox.information(self, "Historial", f"Reimprimir ID: {venta_id} (parent handler yok)")

class VentasEsperaDialog(QDialog):
    def __init__(self, parent, default_usuario: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Ventas en espera")
        self.resize(760, 480)

        self.selected_id = None

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        top = QHBoxLayout()
        top.addWidget(QLabel("Usuario:"))

        self.cb_usuario = QComboBox()
        self.cb_usuario.setFixedWidth(220)
        top.addWidget(self.cb_usuario)

        self.btn_buscar = QPushButton("Buscar")
        self.btn_buscar.setObjectName("Primary")
        top.addWidget(self.btn_buscar)

        top.addStretch(1)
        layout.addLayout(top)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["ID", "Fecha", "Usuario", "Sucursal", "Doc", "Cliente"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.cellDoubleClicked.connect(self._accept_selected)

        hh = self.table.horizontalHeader()
        if QT6:
            hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
            hh.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)

        layout.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.btn_recuperar = QPushButton("Recuperar")
        self.btn_cerrar = QPushButton("Cerrar")
        bottom.addWidget(self.btn_recuperar)
        bottom.addStretch(1)
        bottom.addWidget(self.btn_cerrar)
        layout.addLayout(bottom)

        self.btn_buscar.clicked.connect(self._reload)
        self.btn_recuperar.clicked.connect(self._accept_selected)
        self.btn_cerrar.clicked.connect(self.close)

        self._apply_style()
        self._load_usuarios(default_usuario)
        self._reload()

    def _apply_style(self):
        self.setStyleSheet("""
            QDialog { background:#f8fafc; }
            QLabel { color:#0f172a; font-weight:800; }
            QComboBox {
                min-height:32px;
                border-radius:10px;
                border:1px solid #cbd5e1;
                padding:6px 10px;
                background:#ffffff;
                font-weight:700;
            }
            QTableWidget {
                border:1px solid #e2e8f0;
                border-radius:12px;
                background:#ffffff;
                font-size:14px;
                font-weight:700;
            }
            QHeaderView::section {
                background:#f8fafc;
                padding:8px;
                font-weight:900;
                border:0px;
                border-bottom:1px solid #e2e8f0;
            }
            QPushButton{
                min-height:34px;
                padding:8px 12px;
                border-radius:12px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:900;
            }
            QPushButton#Primary{
                background:#2563eb;
                border:1px solid #2563eb;
                color:white;
            }
        """)

    def _load_usuarios(self, default_usuario: str = ""):
        usuarios = []
        try:
            rows = fetch_ventas_en_espera("")
            usuarios = sorted({str(r.get("usuario", "") or "").strip() for r in rows if str(r.get("usuario", "") or "").strip()})
        except Exception:
            usuarios = []

        self.cb_usuario.clear()
        self.cb_usuario.addItem("TODOS")
        for u in usuarios:
            self.cb_usuario.addItem(u)

        if default_usuario:
            idx = self.cb_usuario.findText(default_usuario)
            if idx >= 0:
                self.cb_usuario.setCurrentIndex(idx)

    def _reload(self):
        usuario = self.cb_usuario.currentText().strip()
        if usuario == "TODOS":
            usuario = ""

        try:
            rows = fetch_ventas_en_espera(usuario)
        except Exception as e:
            QMessageBox.critical(self, "DB", f"No se pudo cargar ventas en espera:\n{e}")
            return

        self.table.setRowCount(0)
        for r, row in enumerate(rows):
            self.table.insertRow(r)
            cliente = str(row.get("razon", "") or "").strip() or str(row.get("rut", "") or "").strip()

            self.table.setItem(r, 0, QTableWidgetItem(str(row.get("id", ""))))
            self.table.setItem(r, 1, QTableWidgetItem(str(row.get("created_at", ""))))
            self.table.setItem(r, 2, QTableWidgetItem(str(row.get("usuario", ""))))
            self.table.setItem(r, 3, QTableWidgetItem(str(row.get("sucursal", ""))))
            self.table.setItem(r, 4, QTableWidgetItem(str(row.get("doc", ""))))
            self.table.setItem(r, 5, QTableWidgetItem(cliente))

    def _accept_selected(self, *args):
        row = self.table.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Ventas en espera", "Seleccione una venta en espera.")
            return

        self.selected_id = int(self.table.item(row, 0).text())
        self.accept()


# ---------------- Main POS Window ----------------
class POSWindow(QMainWindow):
    """
    Columns:
      0 Código
      1 Descripcion
      2 Cant.
      3 Precio
      4 Desc %
      5 Desc $
      6 Valor
    """
    def __init__(self, usuario: str = "", sucursal: str = "", sucursal_id=None):
        super().__init__()
        #ensure_tables()
        self.usuario = (usuario or "").strip()
        self.sucursal = (sucursal or "").strip()
        self.sucursal_id = sucursal_id
        self.display_name = self.usuario or "POS"
        self.setMinimumSize(1200, 720)

        self.cart: List[Dict[str, Any]] = []

        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)
        main.setContentsMargins(12, 4, 12, 12)
        main.setSpacing(6)

        top = QHBoxLayout()
        top.setSpacing(10)

        sucursal_txt = self.sucursal if self.sucursal else "SIN SUCURSAL"
        lbl = QLabel(f"VR9 POS  |  {self.display_name}  |  {sucursal_txt}")
        lbl.setFont(QFont("Segoe UI", 13, 700))
        top.addWidget(lbl)

        top.addStretch(1)

        btn_detalle = QPushButton("Detalle Ventas")
        btn_detalle.setFixedHeight(32)
        btn_detalle.setFixedWidth(132)
        btn_detalle.clicked.connect(self._open_detalle_ventas)
        top.addWidget(btn_detalle)

        btn_close = QPushButton("Cerrar")
        btn_close.setObjectName("Danger")
        btn_close.setFixedHeight(32)
        btn_close.setFixedWidth(86)
        btn_close.clicked.connect(self.close)
        top.addWidget(btn_close)

        main.addLayout(top)

        scan = QFrame()
        scan.setObjectName("Card")
        scan_l = QHBoxLayout(scan)
        scan_l.setContentsMargins(10, 8, 10, 8)
        scan_l.setSpacing(10)

        self.ent_scan = QLineEdit()
        self.ent_scan.setFixedHeight(38)
        self.ent_scan.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.ent_scan.setPlaceholderText("Escanear / escribir barcode y Enter...")
        self.ent_scan.setStyleSheet("padding-left:12px; padding-right:12px;")
        self.ent_scan.returnPressed.connect(self._on_scan)

        btn_add = QPushButton("Agregar")
        btn_add.setObjectName("Primary")
        btn_add.setFixedHeight(32)
        btn_add.setFixedWidth(102)
        btn_add.clicked.connect(self._on_scan)

        scan_l.addWidget(self.ent_scan, 1)
        scan_l.addWidget(btn_add, 0)
        main.addWidget(scan)

        body = QHBoxLayout()
        body.setSpacing(12)

        left = QFrame()
        left.setObjectName("Card")
        left_l = QVBoxLayout(left)
        left_l.setContentsMargins(12, 12, 12, 10)
        left_l.setSpacing(8)

        hdr = QHBoxLayout()
        t = QLabel("Carrito")
        t.setFont(QFont("Segoe UI", 12, 700))
        hdr.addWidget(t)
        hdr.addStretch(1)
        left_l.addLayout(hdr)

        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels(["Código", "Descripcion", "Cant.", "Precio", "Desc %", "Desc $", "Valor"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(self.table.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(self.table.SelectionMode.SingleSelection)

        self.table.setStyleSheet("""
        QTableWidget::item:selected {
            background-color: #2563eb;
            color: white;
        }
        """)

        self.table.setEditTriggers(
            self.table.EditTrigger.SelectedClicked |
            self.table.EditTrigger.EditKeyPressed |
            self.table.EditTrigger.AnyKeyPressed
        )

        self._updating_table = False
        self.table.cellChanged.connect(self._on_cell_changed)

        hh = self.table.horizontalHeader()
        if QT6:
            hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Fixed)
            hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
            hh.setSectionResizeMode(2, QHeaderView.ResizeMode.Fixed)
            hh.setSectionResizeMode(3, QHeaderView.ResizeMode.Fixed)
            hh.setSectionResizeMode(4, QHeaderView.ResizeMode.Fixed)
            hh.setSectionResizeMode(5, QHeaderView.ResizeMode.Fixed)
            hh.setSectionResizeMode(6, QHeaderView.ResizeMode.Fixed)

        self.table.setColumnWidth(0, 170)
        self.table.setColumnWidth(2, 70)
        self.table.setColumnWidth(3, 110)
        self.table.setColumnWidth(4, 90)
        self.table.setColumnWidth(5, 110)
        self.table.setColumnWidth(6, 120)

        left_l.addWidget(self.table, 1)

        subtotal_layout = QHBoxLayout()
        self.lbl_qty = QLabel("Cantidad: 0")
        self.lbl_qty.setStyleSheet("font-weight:800;")

        self.lbl_total_boleta = QLabel("Total Boleta: 0 CLP")
        self.lbl_total_boleta.setStyleSheet("font-weight:900; font-size:14px;")

        subtotal_layout.addWidget(self.lbl_qty)
        subtotal_layout.addStretch(1)
        subtotal_layout.addWidget(self.lbl_total_boleta)
        left_l.addLayout(subtotal_layout)

        body.addWidget(left, 3)

        right = QFrame()
        right.setObjectName("Card")
        r = QVBoxLayout(right)
        r.setContentsMargins(12, 12, 12, 12)
        r.setSpacing(10)

        title_actions = QLabel("Acciones")
        title_actions.setFont(QFont("Segoe UI", 12, 700))
        r.addWidget(title_actions)

        doc_box = QGroupBox("Documento")
        doc_l = QVBoxLayout(doc_box)
        self.rb_boleta = QRadioButton("BOLETA")
        self.rb_factura = QRadioButton("FACTURA")
        self.rb_boleta.setChecked(True)
        doc_l.addWidget(self.rb_boleta)
        doc_l.addWidget(self.rb_factura)
        r.addWidget(doc_box)

        fac_box = QGroupBox("Factura (si aplica)")
        fac_form = QFormLayout(fac_box)
        fac_form.setContentsMargins(8, 10, 8, 8)
        fac_form.setHorizontalSpacing(16)
        fac_form.setVerticalSpacing(8)
        fac_form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        fac_form.setFormAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)

        self.ed_rut = QLineEdit()
        self.ed_razon = QLineEdit()

        self.ed_rut.setPlaceholderText("RUT")
        self.ed_razon.setPlaceholderText("Razón Social")

        self.ed_rut.setFixedHeight(34)
        self.ed_razon.setFixedHeight(34)
        self.ed_rut.setMinimumWidth(190)
        self.ed_razon.setMinimumWidth(235)
        
      
        rut_row = QHBoxLayout()
        rut_row.setSpacing(8)

        self.btn_buscar_cliente = QPushButton("🔎")
        self.btn_buscar_cliente.setFixedHeight(34)
        self.btn_buscar_cliente.setFixedWidth(44)
        self.btn_buscar_cliente.clicked.connect(self._buscar_cliente)

        rut_row.addWidget(self.ed_rut, 1)
        rut_row.addWidget(self.btn_buscar_cliente)

        fac_form.addRow("RUT:", rut_row)
        fac_form.addRow("Razón Social:", self.ed_razon)

        r.addWidget(fac_box)

        btns = QVBoxLayout()
        self.btn_remove = QPushButton("🗑 Quitar seleccionado")
        self.btn_clear = QPushButton("🧹 Vaciar carrito")
        self.btn_apply_offers = QPushButton("🏷 Aplicar Ofertas")
        self.btn_pay = QPushButton("💳 Cobrar / Emitir")
        self.btn_history = QPushButton("📜 Historial (reimprimir)")
        self.btn_hold = QPushButton("⏸ En Espera")
        self.btn_recover = QPushButton("📥 Recuperar")
        self.btn_pay.setObjectName("Primary")

        self.btn_remove.clicked.connect(self._remove_selected)
        self.btn_clear.clicked.connect(self._clear_cart)
        self.btn_apply_offers.clicked.connect(self._apply_offers)
        self.btn_pay.clicked.connect(self._pay_and_save)
        self.btn_history.clicked.connect(self._open_history)
        self.btn_hold.clicked.connect(self._hold_sale)
        self.btn_recover.clicked.connect(self._recover_sale)
        

        btns.addWidget(self.btn_remove)
        btns.addWidget(self.btn_clear)
        btns.addWidget(self.btn_apply_offers)
        btns.addWidget(self.btn_pay)
        btns.addWidget(self.btn_history)
        btns.addWidget(self.btn_hold)
        btns.addWidget(self.btn_recover)
        r.addLayout(btns)

        r.addStretch(1)
        body.addWidget(right, 1)

        main.addLayout(body)

        self._apply_style()
        self.ent_scan.setFocus()
        self._refresh_table()

    def _apply_style(self):
        self.setStyleSheet("""
            QMainWindow { background:#f1f5f9; }
            QLabel { color:#0f172a; }
            QFrame#Card {
                background:#ffffff;
                border:1px solid #e2e8f0;
                border-radius:16px;
            }
            QLineEdit {
                min-height:34px;
                border-radius:12px;
                border:1px solid #cbd5e1;
                padding:6px 12px;
                background:#ffffff;
                font-size:13px;
                font-weight:700;
            }
            QTableWidget {
                border:1px solid #e2e8f0;
                border-radius:12px;
                background:#ffffff;
                font-size:16px;
                font-weight:700;
            }
            QHeaderView::section {
                background:#f8fafc;
                padding:8px;
                font-weight:900;
                border:0px;
                border-bottom:1px solid #e2e8f0;
            }
            QGroupBox {
                border:1px solid #e2e8f0;
                border-radius:14px;
                margin-top:8px;
                padding:10px;
                background:#ffffff;
                font-weight:900;
            }
            QGroupBox::title { subcontrol-origin: margin; left:10px; padding:0 6px; }
            QPushButton{
                min-height:34px;
                padding:4px 12px;
                border-radius:12px;
                border:1px solid #cbd5e1;
                background:#ffffff;
                font-weight:900;
            }
            QPushButton#Primary{
                background:#2563eb;
                border:1px solid #2563eb;
                color:white;
            }
            QPushButton#Danger{
                background:#ef4444;
                border:1px solid #ef4444;
                color:white;
            }
        """)

    def _make_item(self, text: str, editable: bool) -> QTableWidgetItem:
        it = QTableWidgetItem(text)
        flags = it.flags()
        if editable:
            it.setFlags(flags | Qt.ItemFlag.ItemIsEditable)
        else:
            it.setFlags(flags & ~Qt.ItemFlag.ItemIsEditable)
        return it

    def _refresh_table(self):
        self._updating_table = True
        try:
            self.table.setRowCount(0)
            for row_idx, it in enumerate(self.cart):
                self.table.insertRow(row_idx)

                self.table.setItem(row_idx, 0, self._make_item(str(it.get("codigo", "")), editable=False))
                self.table.setItem(row_idx, 1, self._make_item(str(it.get("descripcion", "")), editable=False))
                self.table.setItem(row_idx, 2, self._make_item(str(int(it.get("cant", 1))), editable=True))
                self.table.setItem(row_idx, 3, self._make_item(str(int(it.get("precio", 0))), editable=True))

                pct = float(it.get("desc_pct", 0.0) or 0.0)
                pct_txt = f"{round(pct)}%"
                self.table.setItem(row_idx, 4, self._make_item(pct_txt, editable=True))

                self.table.setItem(row_idx, 5, self._make_item(str(int(it.get("desc_val", 0))), editable=True))
                self.table.setItem(row_idx, 6, self._make_item(str(int(it.get("valor", 0))), editable=False))
        finally:
            self._updating_table = False

        self._recalc_total()

    def _recalc_row(self, idx: int):
        if idx < 0 or idx >= len(self.cart):
            return

        it = self.cart[idx]

        cant = max(1, safe_int(it.get("cant", 1), 1))
        precio = max(0, safe_int(it.get("precio", 0), 0))

        normal_pct = max(0.0, safe_float(it.get("desc_pct_original", it.get("desc_pct", 0.0)), 0.0))
        oferta_pct = max(0.0, safe_float(it.get("oferta_pct", 0.0), 0.0))
        oferta_extra_desc = max(0, safe_int(it.get("oferta_extra_desc", 0), 0))

        desc_manual = bool(it.get("desc_manual", False))
        desc_val_manual = max(0, safe_int(it.get("desc_val", 0), 0)) if desc_manual else 0

        base = cant * precio

        # 1) normal yüzde indirim
        pct_discount = int(round(base * (normal_pct / 100.0)))
        net_after_pct = base - pct_discount
        if net_after_pct < 0:
            net_after_pct = 0

        # 2) oferta indirimi
        oferta_discount_pct = int(round(net_after_pct * (oferta_pct / 100.0)))
        oferta_discount = oferta_discount_pct + oferta_extra_desc

        if oferta_discount > net_after_pct:
            oferta_discount = net_after_pct

        net_after_oferta = net_after_pct - oferta_discount
        if net_after_oferta < 0:
            net_after_oferta = 0

        # 3) manuel indirim
        val = net_after_oferta - desc_val_manual
        if val < 0:
            val = 0

        total_discount = base - val
        effective_pct = 0.0
        if base > 0:
            effective_pct = round((total_discount / base) * 100, 2)

        # manuel desc yoksa Desc $ kolonunda toplam indirim gözüksün
        if not desc_manual:
            it["desc_val"] = total_discount

        it["cant"] = cant
        it["precio"] = precio
        it["desc_pct_original"] = normal_pct
        it["desc_pct"] = effective_pct
        it["oferta_pct"] = oferta_pct
        it["oferta_desc_val"] = oferta_discount
        it["oferta_extra_desc"] = oferta_extra_desc
        it["valor"] = int(val)

    def _recalc_total(self):
        total = sum(int(x.get("valor", 0) or 0) for x in self.cart)
        cantidad = sum(int(x.get("cant", 0) or 0) for x in self.cart)
        self.lbl_qty.setText(f"Cantidad: {cantidad}")
        self.lbl_total_boleta.setText(f"Total Boleta: {money(total)} CLP")

    def _on_cell_changed(self, row: int, column: int):
        if self._updating_table:
            return
        if row < 0 or row >= len(self.cart):
            return
        if column not in (2, 3, 4, 5):
            return

        try:
            txt = self.table.item(row, column).text() if self.table.item(row, column) else ""

            if column == 2:
                self.cart[row]["cant"] = max(1, safe_int(txt, 1))

            elif column == 3:
                self.cart[row]["precio"] = max(0, safe_int(txt, 0))

            elif column == 4:
                self.cart[row]["desc_pct_original"] = max(0.0, parse_pct(txt, 0.0))
                # % değişince manuel flag otomatik değişmesin (istersen burada False yaparız)

            elif column == 5:
                v = max(0, safe_int(txt, 0))
                self.cart[row]["desc_val"] = v
                # kullanıcı 0'dan büyük yazdıysa manual = True, 0 ise manual = False
                self.cart[row]["desc_manual"] = (v > 0)

            self._recalc_row(row)

            self._updating_table = True
            try:
                self.table.item(row, 2).setText(str(self.cart[row]["cant"]))
                self.table.item(row, 3).setText(str(self.cart[row]["precio"]))

                pct = float(self.cart[row].get("desc_pct", 0.0) or 0.0)
                pct_txt = f"{round(pct)}%"
                self.table.item(row, 4).setText(pct_txt)

                self.table.item(row, 5).setText(str(self.cart[row]["desc_val"]))
                self.table.item(row, 6).setText(str(self.cart[row]["valor"]))
            finally:
                self._updating_table = False

            self._recalc_total()

        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def _on_scan(self):
        code = (self.ent_scan.text() or "").strip()
        self.ent_scan.clear()

        if not code:
            self.ent_scan.setFocus()
            return

        try:
            d = fetch_label_by_barcode(code)
        except Exception as e:
            err = str(e)

            if err.startswith("DB_") or "timeout" in err.lower() or "connection" in err.lower():
                QMessageBox.critical(
                    self,
                    "Sin conexión",
                    "No se pudo conectar al servidor o la base de datos no responde.\n\n"
                    f"Barcode ingresado: {code}\n\n"
                    f"Detalle:\n{err}"
                )
            else:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"No se pudo buscar el producto.\n\nDetalle:\n{err}"
                )

            self.ent_scan.setFocus()
            return

        if not d:
            QMessageBox.warning(
                self,
                "No encontrado",
                f"Barcode no existe en DB.\n\nIngresado: {code}\nDB: PostgreSQL"
            )
            self.ent_scan.setFocus()
            return

        precio_base = safe_int(d.get("precio", 0))
        precio_venta = safe_int(d.get("precio_venta", d.get("precio", 0)))

        desc_pct = float(d.get("desc_pct", 0) or 0)
        desc_val = int(d.get("desc_val", 0) or 0)

        descripcion = (d.get("descripcion") or d.get("producto") or "").strip() or "Producto"

        item = {
            "codigo": d.get("barcode", code),
            "descripcion": descripcion,
            "cant": 1,
            "precio": precio_base,
            "desc_pct": desc_pct,
            "desc_pct_original": desc_pct,
            "desc_val": desc_val,
            "valor": precio_venta,
            "saco": d.get("saco_codigo", "") or "",
            "genero": d.get("genero", "") or "",
            "producto_base": d.get("producto", "") or "",
            "categoria": d.get("categoria", "") or "",
            "desc_manual": False,
            "oferta_pct": 0.0,
            "oferta_nombre": "",
            "oferta_desc_val": 0,
            "kg": float(d.get("kg", 0) or 0),
        }

        self.cart.append(item)
        self._refresh_table()
        self.ent_scan.setFocus()

    def _remove_selected(self):
        r = self.table.currentRow()
        if r < 0 or r >= len(self.cart):
            return
        del self.cart[r]
        self._refresh_table()

    def _clear_cart(self):
        if not self.cart:
            return
        if QMessageBox.question(self, "POS", "Carrito boşaltılsın mı?") != QMessageBox.Yes:
            return
        self.cart = []
        self._refresh_table()

    def _hold_sale(self):
        if not self.cart:
            QMessageBox.information(self, "En Espera", "Carrito boş.")
            return

        doc = "BOLETA" if self.rb_boleta.isChecked() else "FACTURA"
        rut = (self.ed_rut.text() or "").strip()
        razon = (self.ed_razon.text() or "").strip()

        try:
            espera_id = save_venta_en_espera(
                usuario=self.usuario,
                sucursal=self.sucursal,
                doc=doc,
                rut=rut,
                razon=razon,
                cart=self.cart,
            )
        except Exception as e:
            QMessageBox.critical(self, "En Espera", f"No se pudo guardar en espera:\n{e}")
            return

        self.cart = []
        self._refresh_table()
        self.ed_rut.clear()
        self.ed_razon.clear()
        self.rb_boleta.setChecked(True)
        self.ent_scan.setFocus()

        QMessageBox.information(
            self,
            "En Espera",
            f"Venta enviada a espera correctamente.\n\nID espera: {espera_id}"
        )


    def _recover_sale(self):
        dlg = VentasEsperaDialog(self, default_usuario=self.usuario)
        if dlg.exec() != QDialog.Accepted:
            return

        espera_id = dlg.selected_id
        if not espera_id:
            return

        try:
            row = get_venta_en_espera(espera_id)
        except Exception as e:
            QMessageBox.critical(self, "Recuperar", f"No se pudo leer la venta en espera:\n{e}")
            return

        if not row:
            QMessageBox.warning(self, "Recuperar", "La venta en espera no existe.")
            return

        try:
            cart = json.loads(row.get("cart_json", "[]") or "[]")
        except Exception:
            cart = []

        if not isinstance(cart, list):
            cart = []

        self.cart = cart
        self._refresh_table()

        doc = str(row.get("doc", "") or "").strip().upper()
        if doc == "FACTURA":
            self.rb_factura.setChecked(True)
        else:
            self.rb_boleta.setChecked(True)

        self.ed_rut.setText(str(row.get("rut", "") or ""))
        self.ed_razon.setText(str(row.get("razon", "") or ""))

        try:
            delete_venta_en_espera(espera_id)
        except Exception as e:
            QMessageBox.warning(self, "Recuperar", f"Se recuperó la venta, pero no se pudo borrar de espera:\n{e}")

        self.ent_scan.setFocus()

        QMessageBox.information(
            self,
            "Recuperar",
            "Venta recuperada correctamente."
        )

    def _apply_offers(self):
        if not self.cart:
            QMessageBox.information(self, "Ofertas", "Carrito boş.")
            return

        hoy = datetime.now().strftime("%Y-%m-%d")

        # önce tüm teklif alanlarını sıfırla
        for it in self.cart:
            it["oferta_pct"] = 0.0
            it["oferta_nombre"] = ""
            it["oferta_desc_val"] = 0
            it["oferta_extra_desc"] = 0

        # gruplar:
        # aynı oferta için aynı saco/categoria/producto bazında gruplayacağız
        grouped: Dict[tuple, List[int]] = {}

        for idx, it in enumerate(self.cart):
            saco = (it.get("saco") or "").strip().upper()
            categoria = (it.get("categoria") or "").strip()
            producto = (it.get("producto_base") or "").strip()

            oferta = db.get_matching_oferta(
                saco=saco,
                categoria=categoria,
                producto=producto,
                fecha_iso=hoy
            )

            if not oferta:
                continue

            tipo = str(oferta.get("tipo_oferta", "PCT") or "PCT").strip().upper()
            valor = str(oferta.get("valor_oferta", "") or "").strip()
            pct = safe_float(oferta.get("descuento_pct", 0), 0.0)

            osaco = (oferta.get("saco") or "TODOS").strip().upper()
            ocat = (oferta.get("categoria") or "TODOS").strip()
            oprod = (oferta.get("producto") or "TODOS").strip()

            it["oferta_nombre"] = f"{tipo} / {valor} / {osaco} / {ocat} / {oprod}"

            if tipo == "PCT":
                it["oferta_pct"] = pct

            elif tipo in ("XFOR", "SECOND_PCT"):
                # grup kampanyalarını sonra topluca işleyeceğiz
                key = (tipo, valor, saco, categoria, producto)
                grouped.setdefault(key, []).append(idx)

        # önce yüzde kampanyaları hesapla
        for i in range(len(self.cart)):
            self._recalc_row(i)

        # şimdi grup kampanyalarını uygula
        for key, idx_list in grouped.items():
            tipo, valor, saco, categoria, producto = key

            prices = []
            for idx in idx_list:
                it = self.cart[idx]
                # her satırı miktar kadar açıyoruz
                cant = max(1, safe_int(it.get("cant", 1), 1))
                precio = max(0, safe_int(it.get("precio", 0), 0))

                for _ in range(cant):
                    prices.append(precio)

            if not prices:
                continue

            extra_discounts_flat: List[int] = []

            if tipo == "XFOR":
                extra_discounts_flat = calc_xfor_discounts(prices, valor)

            elif tipo == "SECOND_PCT":
                pct = 0.0
                try:
                    pct = float(str(valor).replace("%", "").strip())
                except Exception:
                    pct = 0.0
                extra_discounts_flat = calc_second_pct_discounts(prices, pct)

            if not extra_discounts_flat:
                continue

            # flat indirimleri tekrar satırlara dağıt
            pointer = 0
            for idx in idx_list:
                it = self.cart[idx]
                cant = max(1, safe_int(it.get("cant", 1), 1))
                row_extra = 0

                for _ in range(cant):
                    if pointer < len(extra_discounts_flat):
                        row_extra += int(extra_discounts_flat[pointer] or 0)
                    pointer += 1

                it["oferta_extra_desc"] = row_extra
                self._recalc_row(idx)

        self._refresh_table()

        QMessageBox.information(
            self,
            "Ofertas",
            "Ofertas aplicadas correctamente."
        )

    def _pay_and_save(self):
        if not self.cart:
            QMessageBox.information(self, "POS", "Carrito boş.")
            return

        if not self.sucursal:
            QMessageBox.critical(
                self,
                "Error",
                "Sucursal no definida.\nNo se puede registrar la venta."
            )
            return

        doc = "BOLETA" if self.rb_boleta.isChecked() else "FACTURA"
        rut = (self.ed_rut.text() or "").strip()
        razon = (self.ed_razon.text() or "").strip()
        giro = (self.ed_giro.text() or "").strip() if hasattr(self, "ed_giro") else ""
        direccion = (self.ed_direccion.text() or "").strip() if hasattr(self, "ed_direccion") else ""
        comuna = (self.ed_comuna.text() or "").strip() if hasattr(self, "ed_comuna") else ""
        region = (self.ed_region.text() or "").strip() if hasattr(self, "ed_region") else ""

        total = sum(int(x.get("valor", 0) or 0) for x in self.cart)
        if total <= 0:
            QMessageBox.warning(self, "POS", "Total 0 olamaz.")
            return

        dlg = PagoDialog(
            self,
            sucursal=self.sucursal,
            total=total,
            doc=doc,
            rut=rut,
            razon=razon,
            usuario=self.usuario,
        )
        if dlg.exec() != QDialog.Accepted:
            return

        try:
            venta_id = insert_venta(
                usuario=self.usuario,
                sucursal=self.sucursal,
                doc=doc,
                rut=rut,
                razon=razon,
                giro=giro,
                direccion=direccion,
                comuna=comuna,
                region=region,
                total=total,
                promo=dlg.result_promo,
                medio_pago=dlg.result_medio_txt or "N/A",
                items=self.cart,
            )
        except Exception as e:
            QMessageBox.critical(self, "DB", f"Venta kaydedilemedi:\n{e}")
            return

        # ✅ yazdır (default printer)
        try:

            venta, items = fetch_venta_with_items(venta_id)
            if venta:
                print_boleta(venta, items)
        except Exception as e:
            # yazdırma olmazsa satış bozulmasın, sadece uyarı ver
            QMessageBox.warning(self, "Impresión", f"Venta guardada ✅ (ID:{venta_id})\n\nPero no se pudo imprimir:\n{e}")

        QMessageBox.information(self, "OK", f"Venta guardada ✅\nID: {venta_id}")

        self.cart = []
        self._refresh_table()
        self.ed_rut.clear()
        self.ed_razon.clear()
        self.ent_scan.setFocus()

    def _open_detalle_ventas(self):
        # şifre sor
        pd = PasswordDialog(self, title="Detalle Ventas - Acceso")
        if pd.exec() != QDialog.Accepted:
            return
        if pd.password() != CIERRE_PASSWORD:
            QMessageBox.warning(self, "Acceso", "Contraseña incorrecta.")
            return

        dlg = DetalleVentasDialog(self, usuario=self.usuario)
        dlg.exec()

    def _buscar_cliente(self):
        rut = (self.ed_rut.text() or "").strip()

        if not rut:
            QMessageBox.information(self, "Cliente", "Primero ingresa un RUT.")
            return

        try:
            cliente = db.get_cliente_by_rut(rut)
        except Exception as e:
            QMessageBox.critical(self, "Cliente", f"No se pudo buscar cliente:\n{e}")
            return

        if cliente:
            self.ed_razon.setText(cliente.get("razon_social", ""))
            return

        dlg = NuevoClienteDialog(self, rut=rut)

        if dlg.exec():
            data = dlg.result_data
            try:
                db.upsert_cliente(**data)
            except Exception as e:
                QMessageBox.critical(self, "Cliente", f"No se pudo guardar cliente:\n{e}")
                return

            self.ed_razon.setText(data["razon_social"])

    def _open_history(self):
        dlg = HistorialDialog(self, default_usuario=self.usuario)
        dlg.exec()

    def reimprimir_venta(self, venta_id: int):
        venta, items = fetch_venta_with_items(venta_id)
 
        if not venta:
            QMessageBox.warning(
                self,
                "Reimprimir",
                f"No se encontró la venta.\n\nID: {venta_id}"
            )
            return

        try:
            print_boleta(venta, items)

            QMessageBox.information(
                self,
                "Reimprimir",
                "Boleta reimpresa correctamente. ✅"
            )

        except Exception as e:
            QMessageBox.critical(
                self,
                "Error de impresión 🛑",
                f"No se pudo reimprimir.\n\nDetalle:\n{e}"
            )


def open_pos_qt(usuario: str = "", sucursal_id=None, sucursal_nombre: str = ""):
    app = QApplication.instance() or QApplication([])
    w = POSWindow(
        usuario=usuario,
        sucursal_id=sucursal_id,
        sucursal=sucursal_nombre
    )
    w.show()
    app.exec()