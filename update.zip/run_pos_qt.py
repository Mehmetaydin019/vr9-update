import sys
from pos_screen_qt import open_pos_qt

if __name__ == "__main__":
    usuario = sys.argv[1] if len(sys.argv) > 1 else ""
    open_pos_qt(usuario)